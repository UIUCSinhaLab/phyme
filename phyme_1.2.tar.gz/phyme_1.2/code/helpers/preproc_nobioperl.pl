#!/usr/bin/perl -w 

## This program takes as input fasta files of promoters, each fasta file 
## corresponding to a different species. It then creates input files 
## for PhyME in a directory that is also specified as argument.

## usage: <scriptname> <outputdirname> <speciesfile1> <speciesfile2> ... <speciesfile_n>
## <speciesfile1> is taken as reference species

use strict;

my $minblklen =  10; ## aligned blocks will be at least this long
my $minpid = 70;     ## aligned blocks will be at least this identical (%)

my $ROOTDIR = "/home/lonnrot/saurabh/research/distribution/phyme/";

$ENV{'LAGAN_DIR'} = "$ROOTDIR/code/lib/mlagan/";
warn "Set \$LAGAN_DIR to $ENV{'LAGAN_DIR'}\n";

my $laganscript = "$ROOTDIR/code/lib/mlagan/lagan.pl";
my $extractlaganblocksscript = "$ROOTDIR/code/helpers/extract_lagan_blks.py";
if ($#ARGV < 1) {
    print "usage: <scriptname> <dirname> <speciesfile1> <speciesfile2> ... <speciesfile_n>\n";
    die;
}

my $odname = $ARGV[0];
if (!mkdir($odname)) {
    warn "Couldnt create directory $odname ... directory exists\n";
}
my %hash_seq;
my %hash_desc;
my %hash_filename;

for (my $i=1; $i<=$#ARGV; $i++) {
    my $speciesfile = $ARGV[$i];
    my $speciesid = $i-1;
    my ($ids,$seqs) = &ReadFasta($speciesfile);
    for (my $j=0; $j<=$#$ids; $j++) {
	my $id = $$ids[$j];
	my $seq = $$seqs[$j];
	#warn "$id $seq\n";
	$hash_seq{$speciesid}{$id} = $seq;
	$hash_desc{$speciesid}{$id} = $id;
	$hash_filename{$speciesid} = $speciesfile;
    }
}

foreach (keys %{$hash_seq{0}}) {
    my $seqname = $_;
    my $seqfile = "$odname/$seqname.fna";
    my $blkfile = "$odname/$seqname.blk";
    
    open(SEQ,">$seqfile") or die "Couldnt open $seqfile for write\n";
    open(BLK,">$blkfile") or die "Couldnt open $blkfile for write\n";
    close (BLK);

    my $seq1 = $hash_seq{0}{$seqname};
    my $desc1 = $hash_desc{0}{$seqname};
    print SEQ ">SPECIES_0 ". $seqname . " " . $hash_filename{0} ."\n$seq1\n";
    foreach (keys %hash_seq) {
	my $spc = $_;
	if ($spc == 0) {
	    next;
	}
	my $seq2 = $hash_seq{$spc}{$seqname};
	if (!defined($seq2)) {
	    next;
	}
	print SEQ ">SPECIES_$spc ". $seqname . " " . $hash_filename{$spc} ."\n$seq2\n";
	my $desc2 = $hash_desc{$spc}{$seqname};
	open(F1,">__file1__") or die "Couldnt open __file1__ for write\n";
	open(F2,">__file2__") or die "Couldnt open __file2__ for write\n";
	print F1 ">$desc1\n$seq1\n"; close(F1);
	print F2 ">$desc2\n$seq2\n"; close(F2);

	## run lagan    
	my $mfafilename = "__file12__.mfa";
	Process("$laganscript __file1__ __file2__ -order \"-mt 1 -ms -2 -gs -6 -gc 0\" -mfa -out $mfafilename >& __laganlog__");
	#Process("$laganscript __file1__ __file2__ -mfa -out $mfafilename >& __laganlog__");
	Process("rm anchs.final __laganlog__ __file1__ __file2__");
        ## extract blocks
	my $blkfilename = "__file12__.blk";
	Process("python $extractlaganblocksscript $mfafilename $minblklen $minpid > $blkfilename");
	Process("rm $mfafilename");
 
	## append to blk file
	Process("echo \">SPECIES_$spc ". $seqname . " " . $hash_filename{$spc} ."\" >> $blkfile");
	Process("cat $blkfilename >> $blkfile");
	Process("rm $blkfilename");
    }
    close (SEQ);
}
	
sub Process {
    my $command = shift;
    print "Executing: $command\n";
    system($command);
}

sub ReadFasta {
    my $fn = shift;
    open(IN, "<$fn") or die "Couldnt read fasta file $fn\n";
    my $id = ''; my $seq = ''; my $havereadsomething = 0;
    my @ids; my @seqs;
    while (<IN>) {
	chomp;
	my $line = $_;
	if ($line =~ /^\s*$/) { next; }
	if ($line =~ /^\s*\#/) { next; }
	if ($line =~ /^>/) {
	    if ($havereadsomething == 1) {
		if ($id eq '') {
		    die "Error reading Fasta File\n";
		}
		if ($seq eq '') {
		    die "Error reading Fasta File\n";
		}
		push @ids, $id;
		push @seqs, $seq;
	    }
	    $havereadsomething = 1;
	    $line =~ /^>(\S+)/;
	    $id = $1;
	    $seq = '';
	    next;
	}
	$seq .= $line;
    }
    close (IN);
    # also store the last read sequence
    if ($havereadsomething == 1) {
	if ($id eq '') {
	    die "Error reading Fasta File\n";
	}
	if ($seq eq '') {
	    die "Error reading Fasta File\n";
	}
	push @ids, $id;
	push @seqs, $seq;
    }
    
    return (\@ids,\@seqs);
}
	    
