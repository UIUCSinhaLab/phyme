/*****************************************************************
        Copyright by Rockefeller University,
can not be reproduced or distributed without written permission of
copyright holder.  

Written by Saurabh Sinha, Mathieu Blanchette, and Martin Tompa.

The PhyME program implements an algorithm to find
motifs in sets of orthologous sequences, as described in the
following paper:
"PhyME: A probabilistic algorithm for finding motifs in sets of 
orthologous sequences"
by Saurabh Sinha , Mathieu Blanchette  and Martin Tompa.
BMC Bioinformatics 2004, 5:170     doi:10.1186/1471-2105-5-170
Published 28 October 2004.

******************************************************************/
#include "sequence.h"
#include "util.h"

WindowIterator::WindowIterator()
{
  _seq = NULL; 
  _window_size = -1;
  _shift_size = -1;
  _current = -1; 
}

MSWindowIterator::MSWindowIterator()
{
  _seqs = NULL; _numS = 0;
  _window_size = -1;
  _shift_size = -1;
  _currentbegins = NULL; _currentends = NULL;
  _nextalignedcolumn = NULL; _alignedwithpos = NULL; _alignedwithspc = NULL;
}

MSWindowIterator::~MSWindowIterator()
{
  if (_currentbegins) {
    delete [] _currentbegins;
    _currentbegins = NULL;
  }

  if (_currentends) {
    delete [] _currentends;
    _currentends = NULL;
  }

  if (_nextalignedcolumn) {
    delete [] _nextalignedcolumn;
    _nextalignedcolumn = NULL;
  }

  if (_alignedwithpos) {
    for (int i=0; i<_numS; i++) 
      if (_alignedwithpos[i])
	delete [] _alignedwithpos[i];
    delete [] _alignedwithpos;
    _alignedwithpos = NULL;
  }
  if (_alignedwithspc) {
    for (int i=0; i<_numS; i++) 
      if (_alignedwithspc[i])
	delete [] _alignedwithspc[i];
    delete [] _alignedwithspc;
    _alignedwithspc = NULL;
  }
}

WindowIterator::WindowIterator(Sequence *seq)
{
  _seq = seq;
  _window_size = -1;
  _shift_size = -1;
  _current = -1;
}

MSWindowIterator::MSWindowIterator(Sequence **seqs, int numSequences)
{
  _seqs = seqs;
  _numS = numSequences;
  _window_size = -1;
  _shift_size = -1;
  _currentbegins = new int[_numS];
  _currentends = new int [_numS];

  if (_seqs[0]==NULL || _seqs[0]->Length() < 0) {
    printf("Error: cannot create window iterator\n");
    exit(1);
  }

  int length = _seqs[0]->Length();
  _nextalignedcolumn = new int[length];  
  _alignedwithpos = new int*[length];         // worry about this
  _alignedwithspc = new int*[length];         // worry about this
  for (int i=0; i<length; i++) {
    _nextalignedcolumn[i] = -1;
    _alignedwithpos[i] = NULL;
    _alignedwithspc[i] = NULL;
  }

  struct AlignmentNode *ndlist = _seqs[0]->_alignments->GetAlignmentNodeList(_seqs[0],0,length-1);
  int curptr = 0;
  for (struct AlignmentNode *ptr = ndlist; ptr!=NULL; ptr = ptr->_next) {
    int otherSpcIndex = ptr->_otherSeq->GetSpeciesIndex();
    int l1 = ptr->_l1; int r1 = ptr->_r1;
    while (curptr < ptr->_l1 && curptr < length) {
      if (_nextalignedcolumn[curptr] < 0) {
	_nextalignedcolumn[curptr] = ptr->_l1;
      }
      curptr++;
    }
    while (curptr <= ptr->_r1 && curptr < length) {
      _nextalignedcolumn[curptr] = curptr;
      if (_alignedwithpos[curptr]==NULL) {
	_alignedwithpos[curptr] = new int[_numS+1];
	_alignedwithspc[curptr] = new int[_numS+1];
	_alignedwithpos[curptr][0] = -1;
	_alignedwithspc[curptr][0] = -1;
      }
      int endoflist = 0;
      while (_alignedwithpos[curptr][endoflist] >= 0) endoflist++;
      if (endoflist >= _numS) {
	printf("Error: end of list encountered in _alignedwithpos\n");
	exit(1);
      }
      _alignedwithpos[curptr][endoflist] = ptr->_l2 + (curptr-ptr->_l1);
      _alignedwithpos[curptr][endoflist+1] = -1;
      _alignedwithspc[curptr][endoflist] = otherSpcIndex;
      _alignedwithspc[curptr][endoflist+1] = -1;
      curptr++;
    }
  }
  while (curptr < length) {
    if (_nextalignedcolumn[curptr] < 0) {
      _nextalignedcolumn[curptr] = length;
    }
    curptr++;
  }
}

MSWindowIteratorFixedShift::MSWindowIteratorFixedShift(Sequence **seqs, int numSequences, bool ReferenceSequenceOnly)
  :MSWindowIterator(seqs,numSequences)
{
  _ref_seq_only = ReferenceSequenceOnly;
}

MSWindowIteratorAlignmentPunctuated::MSWindowIteratorAlignmentPunctuated(Sequence **seqs, int numSequences)
{
  printf("Error: MSWindowIteratorAlignmentPunctuated not supported yet\n");
  exit(1);
}

bool WindowIterator::Begin(int window_size, int shift_size)
{
  if (_seq == NULL) {
    printf("WindowIterator called on null sequence\n");
    exit(1);
  }
  if (window_size > _seq->Length()) {
    char seqname[1024]; _seq->Name(seqname); 
    printf("Error: Cannot create windows larger than sequence \"%s\" of length %d\n",seqname,_seq->Length());
    return false;
  }
  _window_size = window_size;
  _shift_size = shift_size;
  _current = 0;
  return true;
}

bool MSWindowIterator::Begin(int window_size, int shift_size)
{
  if (_seqs[0] == NULL) {
    printf("WindowIterator called on null sequence\n");
    exit(1);
  }
  if (window_size > _seqs[0]->Length()) {
    char seqname[1024]; _seqs[0]->Name(seqname); 
    printf("Error: Cannot create windows larger than sequence \"%s\" of length %d\n",seqname,_seqs[0]->Length());
    return false;
  }
  _window_size = window_size;
  _shift_size = shift_size;
  
  int length = _seqs[0]->Length();
  return true;
}

bool MSWindowIteratorFixedShift::Begin(int window_size, int shift_size)
{
  if (!this->MSWindowIterator::Begin(window_size, shift_size)) return false;
  _currentbegins[0] = 0;
  ComputeEndsGivenBegins();
  return true;
}

bool MSWindowIteratorAlignmentPunctuated::Begin(int window_size, int shift_size)
{
  return false;  // not supported
}

bool WindowIterator::End()
{
  return (_current + _window_size - 1 >= _seq->Length());
}

bool MSWindowIterator::End()
{
  return  (_currentends[0] >= _seqs[0]->Length());
}

void WindowIterator::Next()
{
  _current += _shift_size;
}

void MSWindowIteratorFixedShift::Next()
{
    int length = _seqs[0]->Length();

    int beginat = _currentbegins[0];
    beginat += _shift_size;
    if (beginat >= length) {
      _currentbegins[0] = beginat;
      _currentends[0] = beginat +_window_size-1;
      return;   // this will be the last iteration, shouldnt reach here anyway
    }
    _currentbegins[0] = beginat;

    ComputeEndsGivenBegins();
}

void MSWindowIteratorAlignmentPunctuated::Next()
{
  printf("Error: MSWindowIteratorAlignmentPunctuated not supported yet\n");
  exit(1);
}

Window *WindowIterator::Current()
  // OBSOLETE
{
  Window *win = new Window(_seq,_current,_current+_window_size-1);
  if (_seq->_alignments == NULL) return win;
  else {
    printf("Error: Single sequence window iterator incompatible with alignment information\n");
    exit(1);
  }
}

void WindowIterator::CurrentWindowList(vector<Window *> *&wl, int min_window_length)
{
  int start = _current;
  int ptr = _current;
  while (ptr <= _current+_window_size-1) {
    if (_seq->CharAt(ptr) == '$') {
      if (ptr > start && ptr-start > min_window_length) {
	Window *window = new Window(_seq,start,ptr-1);
	if (window->Length() >= min_window_length)
	   wl->push_back(window);
	else delete window;
      }
      start = ptr+1;
    }
    ptr++;
  }
  if (ptr > start && ptr-start > min_window_length) {
    Window *window = new Window(_seq,start,ptr-1);
    if (window->Length() >= min_window_length)
       wl->push_back(window);
    else delete window;
  }    
}

void MSWindowIteratorFixedShift::CurrentWindowList(vector<Window *> *&wl, int min_window_length)
{
  Window *win = new Window(_seqs[0],_currentbegins[0],_currentends[0]);
  if (win->Length() < min_window_length) {
    delete win;
    return;
  }
  wl->push_back(win);

  int *otherlefts = new int[_numS];
  for (int i=0; i<_numS; i++) otherlefts[i] = -1;
  struct AlignmentNode *ndlist = _seqs[0]->_alignments->GetAlignmentNodeList(_seqs[0],_currentbegins[0],_currentends[0]);
  for (struct AlignmentNode *ptr = ndlist; ptr != NULL; ptr = ptr->_next) {
    Window *owin = new Window(ptr->_otherSeq, ptr->_l2, ptr->_r2);
    win->AlignWindow(owin,ptr->_l1-_currentbegins[0]);
    delete owin;

    int otherSpeciesIndex = ptr->_otherSeq->GetSpeciesIndex();
    int otherSpeciesSeqIndex = -1;
    for (int i=0; i<_numS; i++) {
      if (_seqs[i]->GetSpeciesIndex()==otherSpeciesIndex) {
	otherSpeciesSeqIndex = i;
	break;
      }
    }
    if (otherSpeciesSeqIndex < 0) {
      printf("Error: Couldnt find sequence matching species index during processing of alignments\n");
      exit(1);
    }
    if (!_ref_seq_only) {
      int otherright = ptr->_l2 - 1;
      int otherleft = otherlefts[otherSpeciesSeqIndex];
      if (otherleft >= 0 && otherright >= otherleft) {
	 Window *enclosed_window = new Window(_seqs[otherSpeciesSeqIndex],otherleft,otherright);
	 if (enclosed_window->Length() >= min_window_length) 
	    wl->push_back(enclosed_window);
	 else delete enclosed_window;
      }
#ifdef _INCLUDE_FLANKS
      else if (otherleft == -1 && otherright >= 0) {
	 Window *enclosed_window = new Window(_seqs[otherSpeciesSeqIndex],0,otherright);
	 if (enclosed_window->Length() >= min_window_length) 
	   wl->push_back(enclosed_window);
	 else delete enclosed_window;
      }	
#endif
    }
    otherlefts[otherSpeciesSeqIndex] = ptr->_r2+1;
  }

#ifdef _INCLUDE_FLANKS
  for (int i=0; i<_numS; i++) {
    if (i==0) continue; // ignore the reference species
    int otherleft = otherlefts[i];
    int otherright = _seqs[i]->Length()-1;
    if (otherright < otherleft) continue;
    if (otherleft < 0) otherleft = 0;
    Window *right_window = new Window(_seqs[i],otherleft,otherright);
    if (right_window->Length() >= min_window_length) 
      wl->push_back(right_window);
    else delete right_window;
  }
#endif

  return ;
}

void MSWindowIteratorFixedShift::CurrentWindowListEW(vector<Window *> *&wl, int min_window_length)
  // same as above, except that homologous windows are of equal length
{
  printf("Error: CurrentWindowListEW not supported yet\n");
  exit(1);
}

void MSWindowIteratorAlignmentPunctuated::CurrentWindowList(vector<Window *> *&wl, int min_window_length)
{
  printf("Error: MSWindowIteratorAlignmentPunctuated not supported yet\n");
  exit(1);
}

void MSWindowIteratorFixedShift::ComputeEndsGivenBegins()
{
  int length = _seqs[0]->Length();

  int endat = _currentbegins[0]+_window_size-1;
  if (endat > length-1) {
    _currentends[0] = length;
    return;
  } 

  _currentends[0] = endat;
}

void MSWindowIteratorAlignmentPunctuated::ComputeEndsGivenBegins()
{
  printf("Error: MSWindowIteratorAlignmentPunctuated not supported yet\n");
  exit(1);
}


