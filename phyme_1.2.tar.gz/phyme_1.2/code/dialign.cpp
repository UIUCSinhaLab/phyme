/*****************************************************************
        Copyright by Rockefeller University,
can not be reproduced or distributed without written permission of
copyright holder.  

Written by Saurabh Sinha, Mathieu Blanchette, and Martin Tompa.

The PhyME program implements an algorithm to find
motifs in sets of orthologous sequences, as described in the
following paper:
"PhyME: A probabilistic algorithm for finding motifs in sets of 
orthologous sequences"
by Saurabh Sinha , Mathieu Blanchette  and Martin Tompa.
BMC Bioinformatics 2004, 5:170     doi:10.1186/1471-2105-5-170
Published 28 October 2004.

******************************************************************/
#include "sequence.h"
#include <string.h>
#include <stdio.h>
#include <ctype.h>

#define DIALIGN_LINELEN 100000

Sequence **ReadDialignOutput(char *fname, int &numSequences)
{
  char **sequences = new char *[MAX_ALIGNED_SEQUENCES];
  int *seq_lengths = new int[MAX_ALIGNED_SEQUENCES];
  char **seq_names = new char *[MAX_ALIGNED_SEQUENCES];
  numSequences = 0;

  char line[DIALIGN_LINELEN];
  char *sequence = NULL;
  int last_seq_len = 0;
  char name[DIALIGN_LINELEN];

  // Read the sequences
  bool first_sequence_encountered = false;
  FILE *fp = fopen(fname,"r");
  while(fgets(line,DIALIGN_LINELEN-1,fp)) {
    if (line[0]=='#') continue;
    if (line[0]!='>' && !first_sequence_encountered) continue;
    if (line[0]=='>' && !first_sequence_encountered) first_sequence_encountered = true;

    // chomp
    int last_pos = strlen(line)-1;
    if (line[last_pos]=='\n' || line[last_pos]=='\r') line[last_pos] = 0;

    if (line[0]=='>') {
      if (sequence!=NULL) {
	sequences[numSequences] = new char[last_seq_len+1];
	strcpy(sequences[numSequences],sequence);
	seq_names[numSequences] = new char[strlen(name)+1];
	strcpy(seq_names[numSequences],name);
	seq_lengths[numSequences] = last_seq_len;
	delete [] sequence;

	strcpy(name,line);
	numSequences++;
      }

      strcpy(name,line);
      sequence = new char[Sequence::MAX_SEQ_LENGTH+1];
      sequence[0] = 0;
      continue;
    }
      
    // concatenate
    strcat(sequence,line);
    last_seq_len = strlen(sequence);
  }
  fclose(fp);

  if (sequence) {
    sequences[numSequences] = new char[last_seq_len+1];
    strcpy(sequences[numSequences],sequence);
    seq_names[numSequences] = new char[strlen(name)+1];
    strcpy(seq_names[numSequences],name);
    seq_lengths[numSequences] = last_seq_len;
    delete [] sequence;
    sequence = NULL;
    numSequences++;
  }

  // Trim the sequences and create Sequence objects from them
  Sequence **seqs = new Sequence*[numSequences];
  char **tsequences = new char*[numSequences];
  int *tlen = new int[numSequences];  
  int **indexintseq = new int*[numSequences];
  for (int i=0; i<numSequences; i++) {
    tsequences[i] = new char[seq_lengths[i]+1];
    indexintseq[i] = new int[seq_lengths[i]];
    int j=0;
    for (int l=0; l<seq_lengths[i]; l++) {
      if (sequences[i][l]=='-') continue;
      indexintseq[i][l] = j;
      tsequences[i][j++] = toupper(sequences[i][l]);
    }
    tsequences[i][j] = 0;
    tlen[i] = j;
    seqs[i] = new Sequence(tsequences[i],tlen[i],seq_names[i]);
    seqs[i]->SetSpeciesIndex(i);
  }
  
  for (int i=0; i<numSequences; i++) delete [] tsequences[i];
  delete [] tsequences;
  delete [] tlen;

  // Create the alignment object
  Alignment *alignments = new Alignment(numSequences);
  bool *insideAlignment = new bool[numSequences]; 
  int *start = new int[numSequences];
  for (int i=0; i<numSequences; i++) {
    for (int j=0; j<numSequences; j++) {
      insideAlignment[j] = false;
      start[j] = -1;
    }
    for (int l=0; l<seq_lengths[i]; l++) {
      if (!isupper(sequences[i][l])) {
	// check if any of the other sequences was inside an alignment so far
	for (int j=0; j<numSequences; j++) {
	  if (j==i) continue;
	  if (insideAlignment[j]) { // this alignment ends at the previous position
	    alignments->AddAlignmentNode(new AlignmentNode(seqs[i],indexintseq[i][start[j]],indexintseq[i][l-1],seqs[j],indexintseq[j][start[j]],indexintseq[j][l-1]));
	    insideAlignment[j] = false;
	  }
	}
	insideAlignment[i] = false;
      }
      else {
	// Else it is an upper case in sequence i; two cases possible:
	if (insideAlignment[i]) {
	  for (int j=0; j<numSequences; j++) {
	    if (j==i) continue;
	    if (insideAlignment[j]) {
	      if (l>=seq_lengths[j] || !isupper(sequences[j][l])) {
		insideAlignment[j] = false;
		alignments->AddAlignmentNode(new AlignmentNode(seqs[i],indexintseq[i][start[j]],indexintseq[i][l-1],seqs[j],indexintseq[j][start[j]],indexintseq[j][l-1]));
	      }
	    }
	    else {
	      if (l<seq_lengths[j] && isupper(sequences[j][l])) {
		insideAlignment[j] = true;
		start[j] = l;
	      }
	    }
	  }
	}
	else {
	  insideAlignment[i] = true;
	  for (int j=0; j<numSequences; j++) {
	    if (j==i) continue;
	    if (insideAlignment[j]) {
	      printf("Error: non-reference sequence inside alignment when reference sequence is not\n");
	      exit(1);
	    }
	    if (l>=seq_lengths[j]) continue;
	    if (!isupper(sequences[j][l])) continue;
	    insideAlignment[j] = true;
	    start[j] = l;
	  }
	}
      }
    }
  }

  // alignments->Print();

  delete [] start;
  delete [] insideAlignment;
  for (int i=0; i<numSequences; i++) {
    delete [] indexintseq[i];
    delete [] seq_names[i];
    delete [] sequences[i];
  }
  delete [] indexintseq;
  delete [] seq_lengths;
  delete [] seq_names;
  delete [] sequences;

  seqs[0]->_alignments = alignments;
  return seqs;
}


