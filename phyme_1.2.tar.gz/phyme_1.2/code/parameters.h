/*****************************************************************
        Copyright by Rockefeller University,
can not be reproduced or distributed without written permission of
copyright holder.  

Written by Saurabh Sinha, Mathieu Blanchette, and Martin Tompa.

The PhyME program implements an algorithm to find
motifs in sets of orthologous sequences, as described in the
following paper:
"PhyME: A probabilistic algorithm for finding motifs in sets of 
orthologous sequences"
by Saurabh Sinha , Mathieu Blanchette  and Martin Tompa.
BMC Bioinformatics 2004, 5:170     doi:10.1186/1471-2105-5-170
Published 28 October 2004.

******************************************************************/
#ifndef _parameters_h_
#define _parameters_h_

#include "typedefs.h"
#include "sequence.h"

#include <vector>
using namespace std;

#ifndef MARKOV_ORDER
#define MARKOV_ORDER 2
#endif

#ifndef CONTEXT_SIZE
#define CONTEXT_SIZE 10
#endif

#define BKG_FORWARD_ONLY 1
#define DEFAULT_BOTH_ORIENTATIONS true
#define ALMOSTONE 0.9
#define MOTIF_COUNT_THRESHOLD 1.0
#define DEFAULT_MOTIF_OCCURRENCE_THRESHOLD 0.1
#define SMALL_MOTIF_OCCURRENCE_THRESHOLD 0.01
#define MS_MOTIF_COUNT_THRESHOLD 2.0
#define PROBABILITY_CACHE_SIZE 25000
#define abs(x) (x>0?x:-x)

#define FLATARRAY 0
#define TREE 1                              // these are types of phylogeny 

extern WtMx *global_background;

#include "tree.h"

class Parameters {
 protected:
  vector<Window*>*_windows;
  WtMxCollection *_wmc;
  WtMx           *_bkgwm;
  int            *_wm_len;                 // for speedup
  int            _numWM;                   // this is needed because _wmc may be modified after 
                                           // this object has been used
                                           // but before it has been destroyed 
  bool           **_free_emission_probabilities;
  bool           _free_transition_probabilities;
  
  int            _initialbias;
  bool           _is_trained;
  bool           _is_initialized;
  
  DTYPE          _free_energy;
  DTYPE          _free_energy_differential;// Fb - F
  DTYPE          _free_energy_perlength;
  int            _num_iterations;
  int            _max_iterations; 

  int            _numSpecies;              // to be used for multiple species
  bool           _revComp;                 // is a rc matrix also there ?

  struct Phylogeny {                       // this structure will have all the phylogenetic information 
    char  _type;                           // is this a flat array of mu's or a tree ? 
                                           // (0 for array, 1 for tree)
    float *_mu;                            // needed by the parameters object to compute probabilities
    Tree  *_tree;                          // -ditto-
    int   _numSpecies;                     

    Phylogeny();
    ~Phylogeny();
    DTYPE  ComputeProbability(WtMx *wm, int index, bool reverse_orientation, char *arrayofindex);
    DTYPE  ComputeProbabilityGivenAncestor(WtMx *wm, int index,  int orientation, int ancestor, char *arrayofchar, int *history = NULL);
    // The above is only for FLATARRAY phylogeny
    DTYPE  ComputeProbabilityOfTreeGivenParent(WtMx *wm, int index,  int orientation, int ancestor, char *hashofchar, Tree::Node *root, int *history = NULL);
    void   ComputeProbabilityOfTreeGivenParentHelper(WtMx *wm, int index, int orientation, char *hashofchar, Tree::Node *root, int *history = NULL);
    DTYPE  ComputeProbabilityOfTreeGivenRoot(WtMx *wm, int index,  int orientation, int ancestor, char *arrayofchar, Tree::Node *root, int *history = NULL);
    // The above are only for TREE phylogeny
    DTYPE  ComputeProbabilityFromCache(DDTYPE *u, bool rev_orientation, int index);
    DTYPE  ComputeFirstPartialDerivative(DDTYPE *u, bool rev_orientation, int index, int beta) ;
    DTYPE  ComputeSecondPartialDerivative(DDTYPE *u, bool rev_orientation, int index, int beta, int gamma) ;
    void   ComputeFTermsAndCacheThem(DDTYPE *u, bool rev_orientation, int index, int beta) ;
    void   ComputeFTermsAndCacheThem(DDTYPE *u, bool rev_orientation, int index, int beta, Tree::Node *nd) ;
    void   ComputeFTermsAndCacheThem(DDTYPE *u, bool rev_orientation, int index, int beta, int gamma) ;
    void   ComputeFTermsAndCacheThem(DDTYPE *u, bool rev_orientation, int index, int beta, int gamma, Tree::Node *nd);

	 
    private:
    int IndexToChIndex(int index, int spc_index);
  };
    
  static struct Phylogeny  *_phy;          // to allow for multiple sequences

  static const float SMALL_FLOAT = 1E-10; // when is a number too small to divide by 
  static const double SMALL_DOUBLE = 1E-200;
  static const float INF_FREE_ENERGY = 1000000;

  char ReverseChar(char ch);                  // utility function

  struct probabilitycache {                   // may be associated with entire sequence or a particular window
    DTYPE  **_prob;                           // prob[j][k] is for (j==wm)(k==position in seq)
    int _start;
    int _length;
    WtMx **_wms;
    int _numWM;
    Window *_associatedCurrentWindow;         // if cache is for a particular window, which one is it

    probabilitycache();                       // regular constructor
    probabilitycache(const probabilitycache &pc);   // copy constructor
    probabilitycache& operator=(const probabilitycache &pc);   // copy constructor
    ~probabilitycache();                      // destructor
    void Destroy();
    private:
    void Copy(const probabilitycache &pc);
  };

  static const float ALMOST_ONE = ALMOSTONE;           // used to initialize parameters to an extreme point
  static const float CONTEXT_WIDTH_FACTOR = CONTEXT_SIZE;        // used to create background context
  
 public:
  static struct probabilitycache *_currentwindowcache; // the vector of caches of subsequence probabilities for associated windows

  Parameters();
  void   FreeEmissionProbabilities(int wmindex, int offset = -1);
  void   FixEmissionProbabilities(int wmindex, int offset = -1);
  bool   IsEmissionProbabilityFree(int wmindex, int offset = -1);
  void   FixTransitionProbabilities();
  bool   IsTransitionProbabilityFree();
  float  Free_Energy_Differential();
  float  Free_Energy();
  void   Scale_Free_Energy_Differential(float scalefactor);

  int    InitialBias();
  bool   IsTrained();
  bool   IsInitialized();
  int    NumIterations();
  void   SetTrainingIterations(int numIter);
  DTYPE  EvaluateFreeEnergyBackground(bool both_orientations=DEFAULT_BOTH_ORIENTATIONS);
  static WtMx *TrainWtMx(Window *context);
  void   TrainBackground(Window *context=NULL);
  int    BackgroundIndex();
  int    BackgroundIndex(WtMxCollection *wmc);
  void   SetBackground(float *bkg);
  void   GetBackground(float *&bkg);
  void   SetBackground(WtMx  *bkg);
  void   GetBackground(WtMx  *&bkg);
  void   CacheBackgroundProbabilities();
  void   PrintBackground(FILE *fp);
  int    NumWM();
  void   PrintWM(FILE *fp, int i);
  void   PrintPID(FILE *fp);
  DTYPE  PID();

  static int GetMarkovOrder() { return MARKOV_ORDER; }
  static int GetBackgroundOrientation() { 
#ifdef BKG_FORWARD_ONLY 
	return BKG_FORWARD_ONLY;
#else
 	return 0;
#endif 
  }
  static float  GetAlmostOne() { return ALMOST_ONE; }
  static float  GetContextWidthFactor() { return CONTEXT_WIDTH_FACTOR; }

  static void SetPhylogeny(float *mu, int numSpecies);
  static void SetPhylogeny(Tree *tree, int numSpecies);
  static const void *GetPhylogeny(int &numSpecies,char type = FLATARRAY);
  static char GetPhylogenyType();
  // return a void pointer, caller should cast it back to float * or Tree *
    
  struct probabilitycache *CacheWindowBackgroundProbabilities(Window *win, WtMx *wm);
  static void CacheSubsequenceProbabilities(Sequence *seq, WtMxCollection *wmc, int start, int cache_length, bool lookAtAlignments = true);
  static void DeleteCacheSubsequenceProbabilities(Sequence *seq);

  static DTYPE  ComputeSequenceProbability(Window *win, int start, int stop, WtMx *wm, bool both_orientations=DEFAULT_BOTH_ORIENTATIONS);


  virtual void Initialize(vector<Window *> *wl, WtMxCollection *wmc, Parameters *init) = 0;
  virtual void Initialize(vector<Window *> *wl, WtMxCollection *wmc, int initialbias = -1) = 0;  
  virtual void Train(bool differential=true) = 0;
  virtual void Print(FILE *fp, bool verbose = false) = 0;
  virtual void PrintProbabilities(FILE *fp, bool verbose=false) = 0;
  virtual void PrintAverageCounts(FILE *fp, bool verbose=false) = 0;
  virtual char *CreateSequence(int length, int seed, bool verbose=false) = 0;
  virtual void MaskOccurrences(int wmindex, float threshold) = 0;
  virtual void PrintOccurrences(FILE *fp, int wmindex, float threshold, int context = 5) = 0;

  void    SetNumSpecies(int numSp);
  void    SetRevComp();

};

#include <hash_map.h>
using namespace std;
struct eqInt {
  bool operator()(int l, int r) const
  {
    return l==r;
  }
};
typedef hash_map<int,DTYPE,hash<int>,eqInt> map_type;

// HMM with no history of last planted motif 
class Parameters_H0 : public Parameters {
  float  *_pi;                       // probability parameters 
  float  *_oldpi;                    // values from previous iteration of optimization

  DTYPE  **_Ai;                      // 
  DTYPE  **_Ail_window;              // 
  DTYPE  *_alpha;                    // forward variables
  DTYPE  *_beta;                     // backward variables
  DTYPE  *_c;                        // scaling factors
  DTYPE  **_cij;                     // Product_i^j {c}
  DTYPE  *_fringe_corrections;       // the fringe correction factors
  int    _max_window_length;         // used for an optimization, set in Initialize()
  Window *_currentWindow;            // as above, used for an optimization

  map_type  **_Eiks;         // i (motif) k (motif position) s (column)

  int    _max_sites;

  static const float THRESHOLD = 1e-4;           // used to terminate training
  static const float RELENT_THRESHOLD = 0.00001; // used to decide upon perturbing parameters
  static const int CHECK_ITERATION_THRESHOLD = 20;
  static const int MAX_TRAINING_ITERATIONS = 1000;
  static const float CHECK_FEN_THRESHOLD = 0.1;

  DTYPE  EvaluateFreeEnergy();
  DTYPE  FringeCorrectionFactor(int index);  // multiply Ail by this factor to get correct value; index is the window index in the vector
  void   PrepareForUpdate();
  void   InitializeEiks();
  void   PrepareForUpdateEiks();
  bool   UpdateEmissionProbabilities();
  void   UpdateTransitionProbabilities();
  bool   Update();                           // update the parameter values
  void   Revert();                           // to go back to previous parameter values
  void   Forward();                          // Forward algorithm (Baum-Welch)
  void   Backward();                         // Backward algorithm (Baum-Welch)
  void   Copy(const Parameters_H0 &p);       // helper member for copy constructor and assignment operator
  void   Destroy();                          // helper member for copy constructor, assignment, and destructor
  DTYPE  Norm_of_parameter_difference();     

  int    ArrayOfCharToIndex(char *arrayofchar);
  int    ArrayOfCharToIndex(char chindex, int seqindex);
  void   IndexToArrayOfChar(int index, char *arrayofchar);
  void   ReverseArrayOfChar(char *arrayofchar);
  DDTYPE GradF(DDTYPE *u, int beta, int n, int wmindex, int offset);
  DDTYPE HessianF(DDTYPE *u, int beta, int alpha, int n, int wmindex, int offset);

  void    ExtractSequenceWithContext(int l, int mlength, int context, Sequence *seq, int windowstart, char *sequence);

  static const float  INF_LEAST_SQUARES = 1000000;
  static const int    MAX_NEWTON_ITERATIONS = 1000;
  static const DDTYPE  LAMBDA_THRESHOLD = 1e-10;       // at least one singular value must be greater than this
  static const DDTYPE  LEAST_SQUARES_THRESHOLD = 1e-5;

#define sqr(x) x*x
 public:
  Parameters_H0();                                     // constructor
  ~Parameters_H0();                                    // destructor
  Parameters_H0(const Parameters_H0 &p);               // copy constructor
  Parameters_H0& operator=(const Parameters_H0 &p);    // assignment operator
  Parameters_H0(WtMxCollection *wmc, int extreme);     // create a dummy set of parameters to begin training from
                                                       // if extreme >= 0, paramters biased to w_i; else uniform

  virtual void Initialize(vector<Window *> *wl, WtMxCollection *wmc, Parameters *init);
  virtual void Initialize(vector<Window *> *wl, WtMxCollection *wmc, int initialbias = -1);
  virtual void Train(bool differential=true);
  void TrainWithFixedParameters(bool differential=true);
  virtual void Print(FILE *fp, bool verbose = false);
  virtual void PrintProbabilities(FILE *fp, bool verbose=false);
  virtual void PrintAverageCounts(FILE *fp, bool verbose=false);
  void PrintProfile(FILE *prof, FILE *dict, float occurrence_threshold = DEFAULT_MOTIF_OCCURRENCE_THRESHOLD);
  virtual char*CreateSequence(int length, int seed, bool verbose=false);
  virtual void MaskOccurrences(int wmindex, float threshold);
  virtual void PrintOccurrences(FILE *fp, int wmindex, float threshold, int context = 5);

  DTYPE   ComputeAverageCount(int i);
  DTYPE   ComputeExpectedAverageCount(int i,DTYPE  *&expectations);
  DTYPE   ComputeVarianceOfCount(int i, DTYPE  *expectations);

#ifdef _CYCLIC_WINDOWS
  float   **GetLastMotifs();
  void    DeleteSpaceForLastMotifs(float **initial);
#endif

  int     MaximumLeftOverlap(AlignmentNode *al, float occurrence_threshold = DEFAULT_MOTIF_OCCURRENCE_THRESHOLD);
  int     MaximumRightOverlap(AlignmentNode *al, float occurrence_threshold = DEFAULT_MOTIF_OCCURRENCE_THRESHOLD);


  void    SetParameters(DTYPE  *p);
  DTYPE   GetParameter(int index);
  void    SetMaxSites(int maxSites);
  static  float GetThreshold() { return THRESHOLD; }

};

#endif









