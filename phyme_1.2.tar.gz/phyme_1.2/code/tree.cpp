/*****************************************************************
        Copyright by Rockefeller University,
can not be reproduced or distributed without written permission of
copyright holder.  

Written by Saurabh Sinha, Mathieu Blanchette, and Martin Tompa.

The PhyME program implements an algorithm to find
motifs in sets of orthologous sequences, as described in the
following paper:
"PhyME: A probabilistic algorithm for finding motifs in sets of 
orthologous sequences"
by Saurabh Sinha , Mathieu Blanchette  and Martin Tompa.
BMC Bioinformatics 2004, 5:170     doi:10.1186/1471-2105-5-170
Published 28 October 2004.

******************************************************************/
#include "tree.h"

void NodeInfo::Print()
{
  printf("f:\n");
  for (int i=0; i<4; i++) {
    printf("%.6f ",f[i]);
  }
  printf("\n");

  printf("f_b:\n");
  for (int i=0; i<4; i++) {
    for (int j=0; j<4; j++) {
      printf("%.6f ",f_b[i][j]);
    }
    printf("\n");
  }

  printf("f_b_g:\n");
  for (int i=0; i<4; i++) {
    for (int j=0; j<4; j++) {
      for (int k=0; k<4; k++) {
	printf("%.6f ",f_b_g[i][j][k]);
      }
      printf("\n");
    }
  }
  return;
}

void Tree::Node::Print(FILE *fp) const
{  
  if (children.empty()) {
    fprintf(fp,"%s:%.2f ",name,mu);
    return;
  }
  fprintf(fp,"(");
  for (list<struct Node *>::const_iterator it = children.begin(); it != children.end(); it++) {
    Tree::Node *child = (*it);
    child->Print(fp);
  }
  fprintf(fp,"):%.2f",mu);
}

void Tree::Node::AssignSpeciesIndices()
{
  if (children.empty()) {
    int speciesIndex;
    char *ptr = strstr(name,"SPECIES");
    if (!ptr) {
      printf("Error: Couldnt assing species index ... name %s is not of the form SPECIES_x\n",name);
    }
    sscanf(ptr,"SPECIES_%d",&speciesIndex);
    spc_index = speciesIndex;
    return;
  }
  for (list<struct Node *>::iterator it = children.begin(); it != children.end(); it++) {
    Tree::Node *child = (*it);
    child->AssignSpeciesIndices();
  }
  return;
}

void Tree::Node::CacheNodeInfo(int index,int rev_orientation,int beta)
{
  int hash_index = (index<<1) + (rev_orientation?1:0);
  CachedArrays *cachedarrays = &(cache[hash_index]);
  for (int alpha=0; alpha <= 3; alpha++) {
    cachedarrays->f[alpha] = nodeInfo->f[alpha];
    cachedarrays->f_b[alpha][beta] = nodeInfo->f_b[alpha][beta];
    cachedarrays->LCache1[alpha] = nodeInfo->LCache1[alpha];
    cachedarrays->LCache3[alpha][beta] = nodeInfo->LCache3[alpha][beta];
    for (int x = 0; x < numChildren; x++) cachedarrays->LCache2[alpha][x] = nodeInfo->LCache2[alpha][x];
  }
  return;
}

void Tree::Node::LoadNodeInfo(int index,bool rev_orientation,int beta,int gamma)
{
  int hash_index = (index<<1) + (rev_orientation?1:0);
  CachedArrays *cachedarrays = &(cache[hash_index]);
  for (int alpha=0; alpha <= 3; alpha++) {
    nodeInfo->f[alpha] = cachedarrays->f[alpha];
    nodeInfo->f_b[alpha][beta] = cachedarrays->f_b[alpha][beta];
    nodeInfo->f_b[alpha][gamma] = cachedarrays->f_b[alpha][gamma];
    nodeInfo->LCache1[alpha] = cachedarrays->LCache1[alpha];
    nodeInfo->LCache3[alpha][beta] = cachedarrays->LCache3[alpha][beta];
    nodeInfo->LCache3[alpha][gamma] = cachedarrays->LCache3[alpha][gamma];
    for (int x = 0; x < numChildren; x++) nodeInfo->LCache2[alpha][x] = cachedarrays->LCache2[alpha][x];    
  }
  return;
}

void Tree::Print(FILE *fp) const
{  
  fprintf(fp,"(");
  for (list<struct Node *>::iterator it = root->children.begin(); it != root->children.end(); it++) {
    Tree::Node *child = (*it);
    child->Print(fp);
  }
  fprintf(fp,")");
}

void Tree::ReadTree(FILE *fp)
  // assigns root to a valid node.
{
  if (fp == NULL) {
    printf("Error: Phylogeny tree file could not be opened\n");
    exit(1);
  }

  lineid = 0;
  root = ReadTreeHelper(fp,0);
}

void Tree::get_comment(FILE *f)
{
  char line[10000];
  char c;
  do
    {
      c=fgetc(f);
      if (c=='\n' || c=='\r') {lineid++;}
    } while (c==' ' || c=='\n' || c=='\t' || c=='\r');
  
  if (c=='/') 
    {
      char foo;
      fscanf(f,"%[^\n\r]%c",line,&foo);
      
      lineid++;
      
      get_comment(f);
    }
  else
    {
      ungetc(c,f);
     
    }
}

Tree::Node *Tree::ReadTreeHelper(FILE *f, int depth)
  // this piece came from MB's Footprinter
{
  char c;

  Tree::Node* here=new Tree::Node;

  Tree::Node* child;

  get_comment(f);
  c=fgetc(f);

  if (c=='(')
    {
      do
	{
	  get_comment(f);
	  child=ReadTreeHelper(f,depth+1);
	  here->children.push_back(child);
	  get_comment(f);
	  c=fgetc(f);
	  if (c=='\n' || c=='\r') lineid++;
	  
	  if (c!=',' && c!=')') 
	    {
	      char line[10000];
	      printf("ERROR: Wrong format in the tree file, at line %d\n",lineid+1);
	      exit(1);
	    }
 	} while (c!=')');
     
      get_comment(f);
      
      float bl;
      if (!fscanf(f,":%f",&bl)) here->mu=1;
      else here->mu=bl;
      
    }
  else
    {
      ungetc(c,f);
      get_comment(f);
      float bl;
      int x=fscanf(f,"%[^:, \n\r\t()]",here->name);
      get_comment(f);
      int isbl=0;
      isbl=fscanf(f,": %f",&bl);
      get_comment(f);
      if (x>=1) 
	{
	  if (isbl) here->mu=bl;
	  else here->mu=1;
	  for (int ii=0;here->name[ii]!='\0';ii++)
	    here->name[ii]=toupper(here->name[ii]);
	  
	}
      if (x==0)
	{
	  
	  char line[10000];
	  printf("ERROR: Wrong format in the tree file, at line %d\n",lineid+1);
	  exit(1);
	} 
      int i=0;
      while (here->name[i]!=0) 
	{
	  
	  i++;
	}
      here->name[i]=0;
     
      if (x==1) 
	{
	  get_comment(f);
	  char d=fgetc(f);
	  if (d=='\n' || d=='\r') {lineid++;}
	  if (d!=',' && d!=')' && d!='(') 
	    {
	      char line[10000];
	      printf("ERROR: Wrong format in the tree file, at line %d\n",lineid+1);
	      exit(1);
	    } 
	  if (d=='\n' || d=='\r') {lineid--;}
	  ungetc(d,f);
	  
	}
    }
  
  here->numChildren = here->children.size();
  if (here->children_array != NULL) {
    delete here->children_array;
    here->children_array = NULL;
  }
  here->children_array = new struct Tree::Node*[here->numChildren];
  int nc = 0;
  for (list<struct Tree::Node*>::iterator it = here->children.begin(); it != here->children.end(); it++) {
    struct Tree::Node *chld = (*it);
    here->children_array[nc++] = chld;
  }
  if (here->children.empty()) here->no_children = true;
  else here->no_children = false;
  return here;
}

