/*****************************************************************
        Copyright by Rockefeller University,
can not be reproduced or distributed without written permission of
copyright holder.  

Written by Saurabh Sinha, Mathieu Blanchette, and Martin Tompa.

The PhyME program implements an algorithm to find
motifs in sets of orthologous sequences, as described in the
following paper:
"PhyME: A probabilistic algorithm for finding motifs in sets of 
orthologous sequences"
by Saurabh Sinha , Mathieu Blanchette  and Martin Tompa.
BMC Bioinformatics 2004, 5:170     doi:10.1186/1471-2105-5-170
Published 28 October 2004.

******************************************************************/
#include "parameters.h"
#include <math.h>
#include <stdexcept>
#include "mynewmat.h"
#include "util.h"

void Parameters_H0::Train(bool differential)
{
  if (!_is_initialized) {
    printf("Training attempted without initialization\n");
    _is_trained = false;
    return;
  }

  DTYPE freeEnergyBackground =  EvaluateFreeEnergyBackground();

  DTYPE  previousFreeEnergy = INF_FREE_ENERGY;
  _free_energy = EvaluateFreeEnergy();

  int count = 0;
  do {
    count++;
    previousFreeEnergy = _free_energy;
    if (!Update()) {
      _free_energy = 100000;
      break;
    }
      ;
    _free_energy = EvaluateFreeEnergy();
    _free_energy_differential = freeEnergyBackground - _free_energy;
#ifdef _PRINTTRAINING
    printf("%.4f ",_free_energy_differential);
#endif
    if (count > CHECK_ITERATION_THRESHOLD && _free_energy_differential < CHECK_FEN_THRESHOLD) break;
    if (count > MAX_TRAINING_ITERATIONS) break;    
    if (_max_iterations > 0 && count > _max_iterations) break;
    if (previousFreeEnergy < _free_energy) break;
  } while (previousFreeEnergy - _free_energy > THRESHOLD);

#ifdef _PRINTTRAINING
  printf("\n");
#endif
  _num_iterations = count;        // record how many iterations were needed

  if (differential) {
    _free_energy_differential = freeEnergyBackground - _free_energy;
    if (_free_energy_differential < 0) _free_energy_differential = 0;
  }
  else _free_energy_differential = 0;

  int numSpecific = 0;
  int numTotal = 0;
  for (int i=0; i<_windows->size(); i++) {
    Window *win = (*_windows)[i];
    numSpecific += win->NumSpecificCharacters();
    numTotal += win->Length();
  }

#ifdef _NORMALIZE_SPACERS
  if (numSpecific == 0) _free_energy_differential = 0;
  else _free_energy_differential *= float(numTotal)/float(numSpecific);
#endif

  _free_energy_perlength = _free_energy_differential / float(numTotal);

  _is_trained = true;
}

void Parameters_H0::TrainWithFixedParameters(bool differential)
{
  if (!_is_initialized) {
    printf("Training attempted without initialization\n");
    _is_trained = false;
    return;
  }

  DTYPE freeEnergyBackground =  EvaluateFreeEnergyBackground();

  // PrepareForUpdate();
  _free_energy = EvaluateFreeEnergy();
  _num_iterations = 0;        // record how many iterations were needed

  if (differential) {
    _free_energy_differential = freeEnergyBackground - _free_energy;
    if (_free_energy_differential < 0) _free_energy_differential = 0;
  }
  else _free_energy_differential = 0;

  int numSpecific = 0;
  int numTotal = 0;
  for (int i=0; i<_windows->size(); i++) {
    Window *win = (*_windows)[i];
    numSpecific += win->NumSpecificCharacters();
    numTotal += win->Length();
  }

#ifdef _NORMALIZE_SPACERS
  if (numSpecific == 0) _free_energy_differential = 0;
  else _free_energy_differential *= float(numTotal)/float(numSpecific);
#endif

  _free_energy_perlength = _free_energy_differential / float(numTotal);

  _is_trained = true;
}

void Parameters_H0::Initialize(vector<Window *> *wl, WtMxCollection *wmc, int initialbias)
{
  _initialbias = initialbias;
  if (initialbias < 0) 
    Initialize(wl,wmc,(Parameters *)NULL);
  else {
    Parameters_H0 seed(wmc, initialbias);
    Initialize(wl,wmc,&seed);
  }                          
}

void Parameters_H0::Initialize(vector<Window *> *wl, WtMxCollection *wmc, Parameters *initseed)
{
  int i;

  Destroy();                      // destroy whatever initialization that may already have occurred

  _windows = wl;
  _wmc = wmc;
  _numWM = _wmc->Size()+1;
  _wm_len = new int[_numWM];

  Parameters_H0 *init = (Parameters_H0 *)initseed;
  int bkgIndex =  BackgroundIndex(_wmc);     
  TrainBackground();
                                  // create the record for which weight matrices are free to be trained
  _free_emission_probabilities = new bool *[_numWM];
  int max_wm_len = -1;
  for (i=0; i<_numWM; i++) {
    WtMx *w;
    if (i==bkgIndex) 
      w = _bkgwm;
    else
      w = _wmc->WM(i);

    int wm_len = w->Length();
    _wm_len[i] = wm_len;
    if (wm_len > max_wm_len) max_wm_len = wm_len;

    _free_emission_probabilities[i] = new bool[wm_len];
    for (int j=0; j<w->Length(); j++) {
      _free_emission_probabilities[i][j] = false;
    }
  }
  if (max_wm_len < 0) {
    printf("Error: maximum wm length < 0\n");
    exit(1);
  }

  _pi = new float[_numWM];
  _oldpi = new float[_numWM];
  for (i=0; i<_numWM; i++) {
    if (init==NULL) {
      _pi[i] = 1/float(_numWM);   // initialize to the uniform distribution
    }
    else {                        // initialize to the parameters in init 
      _pi[i] = init->_pi[i];
    }
    _oldpi[i] = _pi[i]; 
  }

  _max_sites = -1;
  _max_window_length = -1;
  int numWindows = wl->size();
  _Ai = new DTYPE  *[numWindows];

  _fringe_corrections = new DTYPE [numWindows];
  for (int wi=0; wi<numWindows; wi++) {
    Window *window = (*wl)[wi];
    int length = window->Length();
    
    _Ai[wi] = new DTYPE  [_numWM];
    for (i=0; i<_numWM; i++) {
      _Ai[wi][i] = 0;
    }
    
    if (_max_window_length < length) _max_window_length = length;
    _fringe_corrections[wi] = -1.0;
  }
  if (_max_window_length < 0) {
    printf("Error: maximum window length < 0\n");
    exit(1);
  }
  
  _Eiks = new map_type *[_numWM];
  for (int i=0; i<_numWM; i++) {
    if (i==BackgroundIndex(_wmc)) {
      _Eiks[i] = NULL;
      continue;
    }
    int wm_len_i = _wmc->WM(i)->Length();
    _Eiks[i] = new map_type[wm_len_i];
  }
  
  _Ail_window = new DTYPE *[_numWM];
  for (i=0; i<_numWM; i++) {
    _Ail_window[i] = new DTYPE[_max_window_length];
  }
  
  _alpha = new DTYPE [_max_window_length];
  _beta = new DTYPE [_max_window_length];
  _c = new DTYPE [_max_window_length];
  _cij = new DTYPE  *[_max_window_length];
  for (i=0; i<_max_window_length; i++) {
    _c[i] = 1;
    _cij[i] = new DTYPE[max_wm_len];
  }

  _is_initialized = true;
}


DTYPE  Parameters_H0::EvaluateFreeEnergy()
{
  if (!_is_initialized) {
    printf("Error: EvaluateFreeEnergy attempted without complete initialization\n");
    exit(1);
  }

  int bkgIndex = BackgroundIndex();
  WtMx **wm = new WtMx *[_numWM];
  for (int i=0; i<_numWM; i++) {
    if (i!=bkgIndex) {
      wm[i] = _wmc->WM(i);
    }
    else {
      wm[i] = _bkgwm;
    }
  }

  InitializeEiks();
                                      // evaluate the logP
  DTYPE  logP = 0;
  int numWindows = _windows->size();
  for (int wi=0; wi<numWindows; wi++) {
    Window *window = _currentWindow = (*_windows)[wi];
    Forward();                        // update alpha, c and cij
    Backward();                       // update beta
    PrepareForUpdate();               // update Ail

    int length = window->Length();
    DTYPE  tmplogP = 0;
    for (int i=0; i<length; i++) {
      tmplogP += (-(log(_c[i])));
    }
                                     // also add the fringe occurrences
    DTYPE  term = 1.;
    for (int i=0; i<_numWM; i++) {
      if (i==bkgIndex || _wm_len[i]==1) continue;
      for (int k=1; k<_wm_len[i]; k++) {
	if (length-k-1 < 0) continue;
	if (window->AmbiguousCharAt(length-1-k+1)) continue;
	DTYPE  scale_factor = _cij[length-1-k+1][k-1];
	DTYPE  factor = _alpha[length-1-k]*scale_factor*_pi[i]*ComputeSequenceProbability(window,length-1-k+1,length-1,wm[i]);
	term += factor;
      }
    }
    _fringe_corrections[wi] = 1/term; 
    tmplogP += log(term);
    
    logP += tmplogP;                // tmplogP is the contribution from the current window

    PrepareForUpdateEiks();
  }
                                    // Clean up
  delete [] wm;
  
  return -logP;    
}

DTYPE  Parameters_H0::FringeCorrectionFactor(int index)
{
  if (!_is_initialized) {
    printf("Error: FringeCorrectionFactor attempted without complete initialization\n");
    exit(1);
  }
  
  if (index >=  _windows->size()) {
    printf("Error: FringeCorrectionFactor attempted on non-existing window\n");
    exit(1);
  }

  if (_fringe_corrections[index] > -0.5) {   // before being computed, this is at -1.
    return _fringe_corrections[index];
  }
  else {
    printf("Error: FringeCorrectionFactor doesnt have required information %d %f\n",index,_fringe_corrections[index]);
    exit(1);
  }
}

void Parameters_H0::Forward()
{
  int i;
  int bkgIndex = BackgroundIndex();  // the background matrix corresponds to last index
  WtMx **wm = new WtMx *[_numWM];
  int max_wm_length = 0;
  for (i=0; i<_numWM; i++) {
    if (i!=bkgIndex) {
      wm[i] = _wmc->WM(i);
    }
    else {
      wm[i] = _bkgwm;
    }
    if (_wm_len[i] > max_wm_length) max_wm_length = _wm_len[i];
  }

  Window *window = _currentWindow;
  int length = window->Length();

                                       // Clear up previous information
  for (int l=0; l<length; l++) {
    _alpha[l] = 0;
    _c[l] = 0;
  }

                                       // Base conditions (l==0) :-
  if (window->AmbiguousCharAt(0)) {    // 'N' or 'X' at position 0, alpha[0] = 1
    _alpha[0] = 1;
  }
  else {                               // usual case: a known nucleotide at position 0
    DTYPE  sum = 0;
    for (i=0; i<_numWM; i++) {
      if (_wm_len[i]==1) {
	sum += _pi[i]*ComputeSequenceProbability(window,0,0,wm[i]);
      }
    }
    _alpha[0] = sum;
  }
                                       // Scale the _alpha  
  _c[0] = _alpha[0];;
  if (_c[0] < SMALL_FLOAT) _c[0] = 1;
  else _c[0] = 1/_c[0];
  _cij[0][0] = _c[0];
  _alpha[0] *= _c[0];
                                       // Recurrences :-
  for (int l=1; l<length; l++) {       // compute alpha[l]
    if (window->AmbiguousCharAt(l)) {  // 'N' or 'X' here - propagate the previous alpha
      _alpha[l] = _alpha[l-1];
    }
    else {                             // usual case: known nucleotude at this position
      DTYPE  sum = 0;
      for (int i=0; i<_numWM; i++) {
	int wm_len_i = _wm_len[i];
	if (l-wm_len_i+1<0)
	  continue;
	if (l-wm_len_i+1==0) {
	  DTYPE  scale_factor = _cij[0][l-1];
	  sum += scale_factor*_pi[i]*ComputeSequenceProbability(window,0,l,wm[i]);
	  continue;
	}
	DTYPE  scale_factor = (wm_len_i>1?_cij[l-wm_len_i+1][wm_len_i-2]:1);
	sum += _alpha[l-wm_len_i]*scale_factor*_pi[i]*ComputeSequenceProbability(window,l-wm_len_i+1,l,wm[i]);
      }
      _alpha[l] = sum;
    }                       
                                       // Scale the _alphas
    _c[l] = _alpha[l];
    if (_c[l] < SMALL_FLOAT) _c[l] = 1;
    else _c[l] = 1/_c[l];
    for (int i=max(0,l-max_wm_length+1); i<=l-1; i++) {
      _cij[i][l-i] = _cij[i][l-i-1]*_c[l];
    }
    _cij[l][0] = _c[l];
    _alpha[l] *= _c[l];
  }

                                      // Clean up
  delete [] wm;
}

void Parameters_H0::Backward()
{
  int i;
  int bkgIndex = BackgroundIndex(); // the background matrix corresponds to last index
  WtMx **wm = new WtMx *[_numWM];
  for (i=0; i<_numWM; i++) {
    if (i!=bkgIndex) {
      wm[i] = _wmc->WM(i);
    }
    else {
      wm[i] = _bkgwm;
    }
  }

  Window *window = _currentWindow;
  int length = window->Length();
  
                                    // Clear up previous information
  for (int l=0; l<length; l++) {
    _beta[l] = 0;
  }
                                    // Base conditions :-
  if (window->AmbiguousCharAt(length-1)) {   // 'N' or 'X' here
    _beta[length-1] = 1*_c[length-1];
  }
  else {                            // usual case: known nucleotide at this position
    DTYPE  sum = 0;
    for (int i=0; i<_numWM; i++) {
      sum += _pi[i]*ComputeSequenceProbability(window,length-1,length-1,wm[i]);
    }
    _beta[length-1] = sum*_c[length-1];
  }
                                    // Recurrences :-
  for (int l=length-2; l>=1; l--) { // need beta only for length-1 .. 1
    if (window->AmbiguousCharAt(l)) {// 'N' or 'X' here, propagate the previous _beta
      _beta[l] = _c[l]*_beta[l+1];
      continue;
    }
                                    // usual case: known nucleotide at this position
    DTYPE  sum = 0;
    for (i=0; i<_numWM; i++) {      // any wm_i (including the background) may start at position l
      int wm_len_i = _wm_len[i];
      if (l+wm_len_i<length) {     // wm_i starts and ends before length - 1, so there is a following beta also
	DTYPE  scale_factor = (wm_len_i>1?_cij[l+1][wm_len_i-2]:1);
	sum += scale_factor*_pi[i]*ComputeSequenceProbability(window,l,l+wm_len_i-1,wm[i])
	  *_beta[l+wm_len_i];
      }
      else {                        // wm_i starts here but either it doesnt end, or ends at last position
	DTYPE  scale_factor = _cij[l+1][length-2-l];
	sum += scale_factor*_pi[i]*ComputeSequenceProbability(window,l,length-1,wm[i]);
      }
    }
    _beta[l] = sum*_c[l];
  }
                                   // Clean up
  delete [] wm;
}

void Parameters_H0::PrepareForUpdate()
{
  int i;
  int bkgIndex = BackgroundIndex(); // the background matrix corresponds to last index
  WtMx **wm = new WtMx *[_numWM];
  for (i=0; i<_numWM; i++) {
    if (i!=bkgIndex) {
      wm[i] = _wmc->WM(i);
    }
    else {
      wm[i] = _bkgwm;
    }
  }

  Window *window = _currentWindow;
  int length = window->Length();

  int wi = window->GetIndex();
  if ((*_windows)[wi] != window) {
    printf("Error: Couldnt retrieve index of window correctly\n");
    exit(1);
  }
                                    // Clear up previous information
  for (i=0; i<_numWM; i++) {
    _Ai[wi][i] = -1;
  }
  
  /*********** Note: **********************
  Ail computed here is actually $\sum_{P|Xil(P)=1} Pr[P,S|\theta]*(\prod c[l])$,
  which is approximately but not exactly equal to $\sum_{P|Xil(P)=1} Pr[P,S|\theta]/Pr[S|\theta]$
  This difference does not matter in the computation of the updated probabilities, since the
  correction factor is the same in the numerator and denominator. 
  *****************************************/
                                  
  for (i=0; i<_numWM; i++) {        // compute _Ai[i] ...
    _Ai[wi][i] = 0;
    int wm_len_i = _wm_len[i];
    for (int l=0; l<length; l++) {  // ... by summing _Aij[i][l] over all l
      if (window->AmbiguousCharAt(l)) { // 'N' or 'X' at this position, cant have pij at this position
	_Ail_window[i][l] = 0;
	continue;
      }
      if (l==0) {                   // case 1: no alpha term defined for l-1
	_Ail_window[i][l] = _cij[l][wm_len_i-1]*_pi[i]
	  *ComputeSequenceProbability(window,l,l+wm_len_i-1,wm[i])
	  *_beta[l+wm_len_i];
	_Ai[wi][i] += _Ail_window[i][l];
	continue;
      }
      if (l+wm_len_i>=length) {     // case 2: no beta term defined for l+wm_len[i]
	_Ail_window[i][l] = _alpha[l-1]*_cij[l][length-1-l]*_pi[i]
	  *ComputeSequenceProbability(window,l,length-1,wm[i]);
	_Ai[wi][i] += _Ail_window[i][l];
	continue;
      }
	                            // general condition: use both alpha and beta
      _Ail_window[i][l] = _alpha[l-1]*_cij[l][wm_len_i-1]*_pi[i]
	*ComputeSequenceProbability(window,l,l+wm_len_i-1,wm[i])
	*_beta[l+wm_len_i];
      _Ai[wi][i] += _Ail_window[i][l];	
    }  
  }
                                    // Clean up
  delete [] wm;
}

void Parameters_H0::InitializeEiks()
{
  int i;
  int bkgIndex = BackgroundIndex(); // the background matrix corresponds to last index

  for (i=0; i<_numWM; i++) {
    if (i==bkgIndex) continue;
    int wm_len_i = _wm_len[i];
    for (int k=0; k<wm_len_i; k++) {
      for (map_type::iterator iter = _Eiks[i][k].begin(); iter != _Eiks[i][k].end(); iter++) {
	(*iter).second = 0;      
      }
    }
  }

  return;
}
  
void Parameters_H0::PrepareForUpdateEiks()
{
  int i;
  int bkgIndex = BackgroundIndex(); // the background matrix corresponds to last index
  WtMx **wm = new WtMx *[_numWM];
  for (i=0; i<_numWM; i++) {
    if (i!=bkgIndex) {
      wm[i] = _wmc->WM(i);
    }
    else {
      wm[i] = _bkgwm;
    }
  }

  Window *window = _currentWindow;
  int length = window->Length();

  int wi = window->GetIndex();
  if ((*_windows)[wi] != window) {
    printf("Error: Couldnt retrieve index of window correctly\n");
    exit(1);
  }

  DTYPE correction = FringeCorrectionFactor(wi);
  for (i=0; i<_numWM; i++) {
    if (i==bkgIndex) continue;
    int wm_len_i = _wm_len[i];
    for (int l=0; l<length; l++) {  // ... by summing _Aij[i][l] over all l
      if (window->AmbiguousCharAt(l)) {
	continue;
      }
      char *arrayofchar;
      char chindex = window->IndexOfCharAt(l,arrayofchar);
      int s;
      if (chindex != -1) {
	int species = window->Seq()->GetSpeciesIndex();
	s = ArrayOfCharToIndex(chindex,species);
      }
      else {
	s = ArrayOfCharToIndex(arrayofchar);
      }
      for (int k=0; k<wm_len_i; k++) {
	if (l-k<0) continue;
	DTYPE ail = _Ail_window[i][l-k]*correction;
	_Eiks[i][k][s] = _Eiks[i][k][s] + ail;
      }
    }	
  }
                                    // Clean up
  delete [] wm;
}  

bool Parameters_H0::UpdateEmissionProbabilities()
{
  int i;
  int bkgIndex = BackgroundIndex(); // the background matrix corresponds to last index
  WtMx **wm = new WtMx *[_numWM];
  for (i=0; i<_numWM; i++) {
    if (i!=bkgIndex) {
      wm[i] = _wmc->WM(i);
    }
    else {
      wm[i] = _bkgwm;
    }
  }

  for (i=0; i<_numWM; i++) {
    if (i==bkgIndex) continue;
    for (int k=0; k<_wm_len[i]; k++) {
      if (!_free_emission_probabilities[i][k]) continue;
      // else set up the equations to be solved
      DDTYPE u[5];
      for (int j=0; j<4; j++) {
	u[j] = wm[i]->Frequency(k,j);
	u[j] = log(u[j]);
      }
      DDTYPE lagrange_multiplier = -100;
      u[4] = lagrange_multiplier; // initialize Lagrangian multiplier 

      // then Newton's method to find the best update of u
      DDTYPE  previous_least_squares = INF_LEAST_SQUARES;
      DDTYPE  current_least_squares;
      int count = 0;
      bool newton_failed = false;
      
      // Allocate the temporary matrices needed by the loop below
      int n = 5;
      ColumnVector gradFu(n);
      SymmetricMatrix hessianFu(n);
      Matrix V(n,n);
      DiagonalMatrix Lambda(n);
      SymmetricMatrix WORK(n);
      
      int i1;
      do {
#ifdef _DEBUG
	printf("u=\n");
	for (i1=0; i1<n; i1++) printf("%g ",u[i1]);
	printf("\n");
	printf("<Enter> to continue:");
	//getchar();
#endif
	// Compute grad F
	bool gotoloop = false;
	for (i1=0; i1<n; i1++) {
	  DDTYPE grad = GradF(u,i1,n,i,k);
	  gradFu(i1+1) = grad;
	  if (grad != grad) { // is this NAN
	    for (int j=0; j<4; j++) { // reset u to a different start and go back to loop
	      u[j] = wm[i]->Frequency(k,j);
	      u[j] = log(u[j]);
	    }
	    lagrange_multiplier /= 2;
	    u[4] = lagrange_multiplier; // initialize Lagrangian multiplier 
	    gotoloop = true;
	    break;	    
	  }
	}
	if (gotoloop) {
	  count++;
	  continue;
	}
	    
#ifdef _DEBUG
	printf("grad=\n");
	for (i1=0; i1<n; i1++) printf("%g\n",gradFu(i1+1));
	printf("<Enter> to continue:");
	//getchar();
#endif
	// Evaluate current least squares and check for convergence
	current_least_squares = 0;
	for (i1=0; i1<n; i1++) current_least_squares += pow(gradFu(i1+1),2);
	current_least_squares = sqrt(current_least_squares);

#ifdef _DEBUG 
	printf("grad norm (2) = %g\n",current_least_squares);
	printf("<Enter> to continue:");
	//getchar();
#endif
	if (current_least_squares < LEAST_SQUARES_THRESHOLD) {
#ifdef _DEBUG
	  printf("Newton Converged after %d iterations\n",count);
	  printf("<Enter> to continue:");
	  //getchar();
#endif
	  break;
	}
	if (abs(previous_least_squares - current_least_squares) < 1e-5) {
	  for (int j=0; j<4; j++) { // reset u to a different start and go back to loop
	    u[j] = wm[i]->Frequency(k,j);
	    u[j] = log(u[j]);
	  }
	  lagrange_multiplier /= 2;
	  u[4] = lagrange_multiplier; // initialize Lagrangian multiplier 
	  gotoloop = true;
	  break;	    
	}
	if (gotoloop) {
	  count++;
	  continue;
	}
	  
	previous_least_squares = current_least_squares;
	
	// Compute Hessian
	gotoloop = false;
	for (i1=0; i1<n; i1++) {
	  for (int j1=i1; j1<n; j1++) {
	    DDTYPE  val = HessianF(u,i1,j1,n,i,k);
	    if (val != val || val < -1e100 || val > 1e100) { // is the NAN
	      for (int j=0; j<4; j++) { // reset u to a different start and go back to loop
		u[j] = wm[i]->Frequency(k,j);
		u[j] = log(u[j]);
	      }
	      lagrange_multiplier /= 2;
	      u[4] = lagrange_multiplier; // initialize Lagrangian multiplier 
	      gotoloop = true;
	      break;	    
	    }	      
	    hessianFu(j1+1,i1+1) = val;
	  }
	  if (gotoloop) break;
	}
	if (gotoloop) {
	  count++;
	  continue;
	}
#ifdef _DEBUG
	printf("hessian=\n");
	for (i1=0; i1<n; i1++) {
	  for (int j1=0; j1<n; j1++) {
	    if (i1<j1) printf("%g ",hessianFu(j1+1,i1+1));
	    else printf("%g ",hessianFu(i1+1,j1+1));
	  }
	  printf("\n");
	}
	printf("<Enter> to continue:");
	//getchar();
#endif

	// Do SVD of Hessian to get \lambda and V
	Jacobi(hessianFu,Lambda,WORK,V);
#ifdef _DEBUG
	printf("V=\n");
	for (i1=0; i1<n; i1++) {
	  for (int j1=0; j1<n; j1++) {
	    printf("%g ",V(i1+1,j1+1));
	  }
	  printf("\n");
	}
	printf("Lambda=\n");
	for (i1=0; i1<n; i1++) printf("%g\n",Lambda(i1+1));
	printf("<Enter> to continue:");
	//getchar();
#endif
	
	DDTYPE  max_abs_lambda = -1; 
	for (i1=0; i1<n; i1++) {
	  if (abs(Lambda(i1+1)) > max_abs_lambda) max_abs_lambda = abs(Lambda(i1+1));
	}
	if (max_abs_lambda < LAMBDA_THRESHOLD) {
	  newton_failed = true;
	  break;
	}
	for (i1=0; i1<n; i1++) {
	  if (abs(Lambda(i1+1)) < LAMBDA_THRESHOLD) Lambda(i1+1) = 0;
	}
	
	// Solve hessianFu*(change_u) = -gradFu
	ColumnVector change_u(n);
	gradFu = -gradFu;
	Matrix hessianFuinverse(n,n); hessianFuinverse = 0.0;
	for (i1=0; i1<n; i1++) {
	  if (abs(Lambda(i1+1)) < LAMBDA_THRESHOLD) continue;
	  hessianFuinverse += V.Column(i1+1)*V.Column(i1+1).t()*(1/Lambda(i1+1));
	}
	change_u = hessianFuinverse * gradFu;
#ifdef _DEBUG
	printf("change_u=\n");
	for (i1=0; i1<n; i1++) printf("%g\n",change_u(i1+1));
	printf("<Enter> to continue:");
	//getchar();
#endif
	
	// update u and loop back 
	for (i1=0; i1<n; i1++) { 
	  u[i1] += change_u(i1+1);
#ifdef _DEBUG
	  printf("%g ",u[i1]);
#endif
	}
#ifdef _DEBUG
	printf("\n");
	printf("<Enter> to continue:");
	//getchar();
#endif
	count++;
      } while (count < MAX_NEWTON_ITERATIONS); 
      
      // Check if there was convergence or not; exit if not
      if (newton_failed || count == MAX_NEWTON_ITERATIONS) {
	// printf("Newton Failed To Converge\n");
#ifdef _DEBUG
	printf("Newton Failed To Converge\n");
#endif
	// return false;
      }
      else {
	// printf("Newton Converged for column %d in %d iterations\n",k,count);
	// update the probabilities and normalize
	for (int i1=0; i1<n; i1++) u[i1] = exp(u[i1]);
	DTYPE updatefreq[4];
	for (int i1=0; i1<4; i1++) updatefreq[i1] = (DTYPE)u[i1];
	wm[i]->UpdateFrequency(k,updatefreq);
	if (_revComp) {
	  // also update the next wm 
	  wm[i+1]->UpdateFrequency(k,updatefreq);
	}
      }
    }
  }
  // Clean up
  delete [] wm;
  return true;
}

DDTYPE Parameters_H0::GradF(DDTYPE *u, int beta, int n, int wmindex, int offset) 
{
  if (n != 5) {
    printf("Error: GradF must be operating in 4 dimensional space\n");
    exit(1);
  }
  if (beta == 4) {
    DDTYPE sum = 0;
    for (int i=0; i<4; i++) {
      sum += exp(u[i]);
    }
    return sum - 1;
  }
  if (beta < 0 || beta > 3) {
    printf("Error: GradF computed with invalid beta\n");
    exit(1);
  }
  // compute GradF
  DDTYPE A = 0, B = 0;
  DDTYPE Wikb = exp(u[beta]);

  for (int rc=0; rc<(_revComp?2:1); rc++) {
    map_type *Esik; WtMx *wm; bool rev_orientation; int effective_offset;
    if (rc==0) {
      Esik = &(_Eiks[wmindex][offset]);
      wm = _wmc->WM(wmindex);
      rev_orientation = false;
      effective_offset = offset;
    }
    if (rc==1) {
      Esik = &(_Eiks[wmindex+1][_wmc->WM(wmindex+1)->Length()-1-offset]);
      wm = _wmc->WM(wmindex+1);
      rev_orientation = true;
      effective_offset = wm->Length()-1-offset;
    }
    for (map_type::iterator it = Esik->begin(); it != Esik->end(); it++) {
      int index = (*it).first;
      DDTYPE value = (*it).second;
      char *arrayofchar = new char[1+2*_numSpecies];
      IndexToArrayOfChar(index,arrayofchar);
      if (rc==1) {
	ReverseArrayOfChar(arrayofchar);
      }
      if (arrayofchar[0] == 1) {  // single species column
	if (arrayofchar[2] == beta) { // doesnt matter what species this is
	  A += value;
	}
	delete [] arrayofchar;
	continue;
      }
      // multiple species column
      if (_phy->_type == FLATARRAY) {
	if (arrayofchar[1] != 0) {
	  printf("Error in converting index to arrayofchar: element 1 should be ref spc index\n");
	  exit(1);
	}
	if (arrayofchar[2] >= 4) {
	  delete [] arrayofchar;
	  continue;
	}
	if (arrayofchar[2] == beta) {
	  A += value;
	  int numSeq = arrayofchar[0];
	  DDTYPE cnt = 0;
	  for (int j=0; j<numSeq-1; j++) {
	    int spcindex = arrayofchar[3+2*j];
	    int chindex =  arrayofchar[4+2*j];
	    if (chindex==beta && spcindex != 0) {
	      DDTYPE mu = _phy->_mu[spcindex];
	      cnt += mu*Wikb/(1-mu + mu*Wikb);
	    }
	  }
	  B += value*cnt;	  
	}
	else {
	  int numSeq = arrayofchar[0];
	  int cnt = 0;
	  for (int j=0; j<numSeq-1; j++) {
	    int spcindex = arrayofchar[3+2*j];
	    int chindex =  arrayofchar[4+2*j];
	    if (chindex==beta && spcindex != 0) {
	      cnt++;
	    }
	  }
	  A += value*cnt;
	}
      }
      else { // compute first derivative, mutliply by value, and add to A.
	_phy->ComputeFTermsAndCacheThem(u, rev_orientation, index, beta); // index carries the \psi
	DDTYPE prob = _phy->ComputeProbabilityFromCache(u, rev_orientation, index);
	DDTYPE prob_inv = 1/prob; // this is Pr(\psi|W_k)^{-1}
	DDTYPE parder1 = _phy->ComputeFirstPartialDerivative(u, rev_orientation, index, beta); // [Pr(\psi|W_k)]_\beta
	A += value*prob_inv*parder1;	  
      }
      delete [] arrayofchar;
    }
  }
  return A + B + u[4]*Wikb;
}

DDTYPE Parameters_H0::HessianF(DDTYPE *u, int beta, int alpha, int n, int wmindex, int offset) 
{
  if (n != 5) {
    printf("Error: Hessian must be operating in 4 dimensional space\n");
    exit(1);
  }

  if (beta == 4 && alpha == 4) {
    return 0;
  }
  if (beta == 4 && alpha < 4) {
    return exp(u[alpha]);
  }
  if (alpha == 4 && beta < 4) {
    return exp(u[beta]);
  }

  if (beta < 0 || beta >= 4 || alpha < 0 || alpha >= 4) {
    printf("Error: HessianF computed with invalid index\n");
    exit(1);
  }
    
  // alpha < 4, beta < 4
  if (_phy->_type == FLATARRAY) 
    if (alpha != beta) return 0;

#ifdef _DDEBUG
  printf("Hessian called with:\n");
  for (int i=0; i<n; i++) printf("%.6f ",exp(u[i])); printf("\n");
  printf("%d %d %d %d %d\n", beta, alpha, n, wmindex, offset);
  printf("<Enter> to continue:");
  //getchar();
#endif

  DDTYPE B = 0;
  DDTYPE Wikb = exp(u[beta]);

  for (int rc=0; rc<(_revComp?2:1); rc++) {
    map_type *Esik; WtMx *wm; bool rev_orientation; int effective_offset;
    if (rc==0) {
      Esik = &(_Eiks[wmindex][offset]);
	wm = _wmc->WM(wmindex);
	rev_orientation = false;
	effective_offset = offset;
    }
    if (rc==1) {
      Esik = &(_Eiks[wmindex+1][_wmc->WM(wmindex+1)->Length()-1-offset]);
      wm = _wmc->WM(wmindex+1);
      rev_orientation = true;
      effective_offset = wm->Length()-1-offset;
    }
    for (map_type::iterator it = Esik->begin(); it != Esik->end(); it++) {
      int index = (*it).first;
      DDTYPE value = (*it).second;
      char *arrayofchar = new char[1+2*_numSpecies];
      IndexToArrayOfChar(index,arrayofchar);
      if (rc==1) {
	ReverseArrayOfChar(arrayofchar);
      }
      if (arrayofchar[0] == 1) {  // single species column
	delete [] arrayofchar;
	continue;
      }
      // multiple species column
      if (_phy->_type == FLATARRAY) {
	if (arrayofchar[1] != 0) {
	  printf("Error in converting index to arrayofchar: element 1 should be ref spc index\n");
	  exit(1);
	}
	if (arrayofchar[2] >= 4) {
	  delete [] arrayofchar;
	  continue;
	}
	if (arrayofchar[2] == beta) {
	  int numSeq = arrayofchar[0];
	  DDTYPE cnt = 0;
	  for (int j=0; j<numSeq-1; j++) {
	    int spcindex = arrayofchar[3+2*j];
	    int chindex =  arrayofchar[4+2*j];
	    if (chindex==beta && spcindex != 0) {
	      DDTYPE mu = _phy->_mu[spcindex];
	      cnt += mu*Wikb/(1-mu + mu*Wikb);
	      cnt += -pow(mu*Wikb,2)/pow(1-mu + mu*Wikb,2);
	    }
	  }
	  B += value*cnt;	  
	}
      }
      else { // compute second derivative, mutliply by value, and add to B.
	_phy->ComputeFTermsAndCacheThem(u, rev_orientation, index, beta, alpha); // index carries the \psi
	DDTYPE prob = _phy->ComputeProbabilityFromCache(u, rev_orientation, index);
	DDTYPE prob_inv = 1/prob; // this is Pr(\psi|W_k)^{-1}
	DDTYPE prob_inv_sqr = pow(prob_inv,2.0); // this is Pr(\psi|W_k)^{-2}
	  
	DDTYPE parder2 = _phy->ComputeSecondPartialDerivative(u, rev_orientation, index, beta, alpha); 
	// [Pr(\psi|W_k)]_\beta_\alpha
	DDTYPE parder1beta = _phy->ComputeFirstPartialDerivative(u, rev_orientation, index, beta); 
	// [Pr(\psi|W_k)]_\beta
	DDTYPE parder1alpha = _phy->ComputeFirstPartialDerivative(u, rev_orientation, index, alpha); 
	// [Pr(\psi|W_k)]_\alpha
	B += value*(prob_inv*parder2 - prob_inv_sqr*parder1beta*parder1alpha);
#ifdef _DDEBUG
	if (alpha != beta) {
	  // print the arrayofchar
	  char *ptr = arrayofchar;
	  int numentries = (*ptr++);
	  printf("%d ",numentries);
	  for (int count=0; count <numentries; count++) {
	    char c1 = (*ptr++); char c2 = (*ptr++);
	    printf("%d %d ",c1,c2);
	  }
	  printf("\n");
	  printf("prob is %.6f\n",prob);
	  printf("parder1beta is %.6f\n",parder1beta);
	  printf("parder1alpha is %.6f\n",parder1alpha);
	  printf("parder2 is %.6f\n",parder2);
	  printf("pd2 of log Pr is %.6f\n",(prob_inv*parder2 - prob_inv_sqr*parder1beta*parder1alpha));
	  printf("<Enter> to continue: ");
	  //getchar();
	}
#endif
      }
      delete [] arrayofchar;
    }
  }
  return B + u[4]*Wikb*(beta==alpha?1:0);
}

void Parameters_H0::UpdateTransitionProbabilities()
{
  int i;

  DTYPE oldmotifprob = 0;
  for (i=0; i<_numWM; i++) {
    if (i!=BackgroundIndex()) {
      oldmotifprob += _pi[i];
    }
  }
                             // save current pij
  for (i=0; i<_numWM; i++) {
    _oldpi[i] = _pi[i];
  }
 
  DTYPE  *ai = new DTYPE [_numWM];
  DTYPE  sum = 0;

  int numWindows = _windows->size();
  for (i=0; i<_numWM; i++) {
    ai[i] = 0; 
    for (int wi=0; wi<numWindows; wi++) {
      DTYPE  correction = FringeCorrectionFactor(wi);
      DTYPE incr = _Ai[wi][i]*correction;
      ai[i] += incr;
    }
    sum += ai[i];
  }
  if (sum > 0) {
    for (i=0; i<_numWM; i++) {
      _pi[i] = float(ai[i]/sum);
    }
  }
  int totalLen = 0;
  for (int wi=0; wi<numWindows; wi++) {
    Window *win = (*_windows)[wi];
    totalLen += win->Length();
  }
  DTYPE maxmotifprob = DTYPE(_max_sites)/DTYPE(totalLen);
  DTYPE motifprob = 0;
  for (i=0; i<_numWM; i++) {
    if (i!=BackgroundIndex()) {
      motifprob += _pi[i];
    }
  }
  if (maxmotifprob > 0 && motifprob > maxmotifprob && oldmotifprob < motifprob) {
    // fprintf(stderr,"motifprob = %.6f\toldmotifprob = %.6f\tmaxmotifprob = %.6f\tReverting\n",motifprob,oldmotifprob,maxmotifprob);
    Revert();
  }

  delete [] ai;
}

bool Parameters_H0::Update()
{
  if (!UpdateEmissionProbabilities()) return false;;
  if (IsTransitionProbabilityFree()) UpdateTransitionProbabilities();
  return true;
}

void Parameters_H0::Revert()
{
  int i;

  for (i=0; i<_numWM; i++) {
    _pi[i] = _oldpi[i];
  }

  return;
}

void Parameters_H0::SetMaxSites(int maxSites) 
{
  _max_sites = maxSites;
}

void Parameters_H0::Print(FILE *fp, bool verbose)
{
  int totalLen = 0;
  for (int wi=0; wi<_windows->size(); wi++) {
    totalLen += (*_windows)[wi]->Length();
  }

  if (!verbose) {
    fprintf(fp,"%d\t",(*_windows)[0]->Start());
#ifdef _PRINT_SEQNAME_IN_FENFILE
    char seqname[1024]; (*_windows)[0]->Seq()->Name(seqname);
    fprintf(fp,"%.6f\t%.6f\t%d\t%d\t%s\n",_free_energy_differential,_free_energy_perlength,totalLen,_num_iterations,seqname);
#else
    fprintf(fp,"%.6f\t%.6f\t%d\t%d\n",_free_energy_differential,_free_energy_perlength,totalLen,_num_iterations);
#endif

    return;
  }
  else {
    for (int wi=0; wi<_windows->size(); wi++)
      (*_windows)[wi]->Print(verbose);
    fprintf(fp,"Score = %.6f\tTotalLen = %d\tIterations = %d\n",_free_energy_differential,totalLen,_num_iterations);
  
    int i;
    
    _bkgwm->Print();
    fprintf(fp,"Transition probabilities (p_i):\n");   // print the _pi values
    for (i=0; i<_numWM; i++) {                    
      fprintf(fp,"%g ",_pi[i]);
    }
    fprintf(fp,"\n");
  }
}

void Parameters_H0::PrintProbabilities(FILE *fp, bool verbose)
{
  for (int i=0; i<_numWM; i++) {
    fprintf(fp,"%.6f ",_pi[i]);
  }
  fprintf(fp,"\n");
  return;
}

DTYPE  Parameters_H0::ComputeAverageCount(int i)
{
  DTYPE  totalac = 0;
  int numWindows = _windows->size();
  for (int wi=0; wi<numWindows; wi++) {
    DTYPE  ac = _Ai[wi][i];
    DTYPE  correction = FringeCorrectionFactor(wi);
    totalac += ac*correction;
  }

  return totalac;
}

DTYPE  Parameters_H0::ComputeExpectedAverageCount(int i, DTYPE  *&expectations)
{
  int bkgIndex = BackgroundIndex(); // the background matrix corresponds to last index
  WtMx **wm = new WtMx *[_numWM];
  for (int k=0; k<_numWM; k++) {
    if (k!=bkgIndex) {
      wm[k] = _wmc->WM(k);
    }
    else {
      wm[k] = _bkgwm;
    }
  }

  DTYPE  mean = 0;
  int numWindows = _windows->size();
  expectations = new DTYPE [numWindows];

  for (int wi=0; wi<numWindows; wi++) {
    Window *window = (*_windows)[wi];
    int length = window->NumSpecificCharacters();

    DTYPE  *alpha = new DTYPE [length];
    alpha[0] = 1;
    DTYPE  *alphasum = new DTYPE [length];
    alphasum[0] = alpha[0];
    for (int l=1; l<length; l++) {
      alpha[l] = 0;
      for (int k=0; k<_numWM; k++) {
	if (l-_wm_len[k]<0) continue;
	alpha[l] += alpha[l-_wm_len[k]]*_pi[k];
      }
      alphasum[l] = alphasum[l-1]+alpha[l];
    }
    expectations[wi] = _pi[i]*alphasum[length-1];
    mean += expectations[wi];

    delete [] alpha;
    delete [] alphasum;              // TODO: optimize this
  }

  delete [] wm;
  return mean;
}

DTYPE   Parameters_H0::ComputeVarianceOfCount(int i, DTYPE  *expectations)
{
  int bkgIndex = BackgroundIndex(); // the background matrix corresponds to last index
  WtMx **wm = new WtMx *[_numWM];
  for (int k=0; k<_numWM; k++) {
    if (k!=bkgIndex) {
      wm[k] = _wmc->WM(k);
    }
    else {
      wm[k] = _bkgwm;
    }
  }

  DTYPE  variance = 0;
  int numWindows = _windows->size();
  for (int wi=0; wi<numWindows; wi++) {
    Window *window = (*_windows)[wi];
    int length = window->NumSpecificCharacters();
    
    DTYPE  *alpha = new DTYPE  [length];
    alpha[0] = 1;
    for (int l=1; l<length; l++) {
      alpha[l] = 0;
      for (int k=0; k<_numWM; k++) {
	if (l-_wm_len[k]<0) continue;
	alpha[l] += alpha[l-_wm_len[k]]*_pi[k];
      }
    }

    // Compute termIJ
    DTYPE  termIJ = 0;
    variance += (expectations[wi] + 2*pow(_pi[i],2)*termIJ - pow(expectations[wi],2));
    delete [] alpha;
  }

  delete [] wm;
  return variance;
}

void Parameters_H0::PrintAverageCounts(FILE *fp, bool verbose)
{
  int bkgIndex = BackgroundIndex(); // the background matrix corresponds to last index
  WtMx **wm = new WtMx *[_numWM];
  for (int i=0; i<_numWM; i++) {
    if (i!=bkgIndex) {
      wm[i] = _wmc->WM(i);
    }
    else {
      wm[i] = _bkgwm;
    }
  }
  
  int numWindows = _windows->size();
  
  for (int i=0; i<_numWM; i++) {
    DTYPE  totalaverage = 0;
    for (int wi=0; wi<numWindows; wi++) {
      Window *window = (*_windows)[wi];
      int length = window->Length();
      DTYPE  correction = FringeCorrectionFactor(wi);      	
      DTYPE  average = _Ai[wi][i]*correction;
      totalaverage += average;
    }
    fprintf(fp,"%.6f ",totalaverage);      
  }    
  fprintf(fp,"\n");
  
  delete [] wm;

  return;
}

#include <list>
struct tmpstruc1 {
  int mindex;
  int offset;
  DTYPE ail;
};

void Parameters_H0::PrintProfile(FILE *fp, FILE *dict, float occurrence_threshold)
{
  int bkgIndex = BackgroundIndex(); // the background matrix corresponds to last index
  WtMx **wm = new WtMx *[_numWM];
  for (int i=0; i<_numWM; i++) {
    if (i!=bkgIndex) {
      wm[i] = _wmc->WM(i);
    }
    else {
      wm[i] = _bkgwm;
    }
  }
  
  int numWindows = _windows->size();
  for (int wi=0; wi<numWindows; wi++) {
    Window *window = (*_windows)[wi];
    char name[1024];
    window->Seq()->Name(name);
    fprintf(fp,">\nSequence : %s\tPosition %d\n",name,window->Start());
    fprintf(dict,">%s\nPosition: %d\tNucl: %d\tWord_av_length: 0.00\tFree Energy: %.6f\n",name,window->Start(),window->NumSpecificCharacters(),_free_energy_differential);

    _currentWindow = window;
    Forward();
    Backward();
    PrepareForUpdate();

    int length = window->Length();
    DTYPE  correction = FringeCorrectionFactor(wi);      	
    list<tmpstruc1 *> worklist;

    for (int l=0; l<length; l++) {
      fprintf(fp,"%d\t%c\n",window->Start()+l,window->Seq()->CharAt(window->Start()+l));
      if (window->AmbiguousCharAt(l)) {
	fprintf(fp,"N\t\t\t\t1.0\n");
	continue;
      }

      // process the working list
      for (list<tmpstruc1 *>::iterator it = worklist.begin(); it != worklist.end(); ) {
	tmpstruc1 *&current = *it;
	char name[1024]; wm[current->mindex]->Name(name,15);
	if (current->offset <= wm[current->mindex]->Length()) {
	  fprintf(fp,"%s\t+\t%d\t%.6f\n",name,current->offset,current->ail);
	}
	current->offset ++;
	if (current->offset > wm[current->mindex]->Length()) {
	  it = worklist.erase(it);
	  delete current;
	}
	else it++;
      }      

      // see if there's a new motif starting here
      for (int i=0; i<_numWM; i++) {
	if (l >= length-_wm_len[i]+1) continue;
	DTYPE  ail = _Ail_window[i][l]*correction;
	if (ail > occurrence_threshold) {
	  char name[1024]; wm[i]->Name(name,15);
	  if (i==bkgIndex) {
	    fprintf(fp,"%s\t\t\t%.6f\n",name,ail);
	  }
	  else {
	    fprintf(fp,"%s\t+\t1\t%.6f\n",name,ail);
	    // also put it in a list
	    tmpstruc1 *tmp = new tmpstruc1;
	    tmp->mindex = i;
	    tmp->offset = 2;
	    tmp->ail    = ail;
	    worklist.push_back(tmp);
	  }
	}
      }      
    }

    // delete the working list
    for (list<tmpstruc1 *>::iterator it = worklist.begin(); it != worklist.end();) {
      tmpstruc1 *&current = *it;
      it = worklist.erase(it);
      delete current;
    }      

    // write the dictionary
    for (int i=0; i<_numWM; i++) {
      DTYPE average = _Ai[wi][i]*correction;
      if (average > occurrence_threshold) {
	char name[1024]; wm[i]->Name(name,15);
#ifdef _WTMX_BIAS
	float fbias = wm[i]->GetForwardBias();
	fprintf(dict,"%s\t%.6f\t%.6f\t%.2f\n",name,_pi[i],average,fbias);
#else 
	fprintf(dict,"%s\t%.6f\t%.6f\n",name,_pi[i],average);
#endif	
      }
    }

    fprintf(dict,"<\n");
    fprintf(fp,"<\n");
  }    
  
  delete [] wm;
  return;
}

#ifdef _CYCLIC_WINDOWS

float **Parameters_H0::GetLastMotifs()
{
  int bkgIndex = BackgroundIndex(); // the background matrix corresponds to last index
  WtMx **wm = new WtMx *[_numWM];
  for (int i=0; i<_numWM; i++) {
    if (i!=bkgIndex) {
      wm[i] = _wmc->WM(i);
    }
    else {
      wm[i] = _bkgwm;
    }
  }
  
  int numWindows = _windows->size();
  int numWM = _numWM;

  float **initial;
  initial = new float *[numWindows];
  for (int wi=0; wi<numWindows; wi++) {
    initial[wi] = new float[numWM];
    for (int j=0; j<numWM; j++) {
      initial[wi][j] = 0;
    }

    Window *window = (*_windows)[wi];
    _currentWindow = window;
    Forward();
    Backward();
    PrepareForUpdate();

    int length = window->Length();
    DTYPE  correction = FringeCorrectionFactor(wi);      	
    list<tmpstruc1 *> worklist;

    int last_motif_starts_at = -1;
    float remaining_probability = 1;
    for (int l=length-1; l>=0; l--) {
      if (window->AmbiguousCharAt(l)) {
	continue;
      }

      // see if there's a new motif starting here
      for (int i=0; i<_numWM; i++) {
	if (i==bkgIndex) continue;
	if (l >= length-_wm_len[i]+1) continue;
	DTYPE  ail = _Ail_window[i][l]*correction;
	if (ail < SMALL_MOTIF_OCCURRENCE_THRESHOLD) continue;
	tmpstruc1 *tmp = new tmpstruc1;
	tmp->mindex = i;
	tmp->offset = l;
	tmp->ail    = ail*remaining_probability;
	worklist.push_back(tmp);
	remaining_probability -= tmp->ail;
      }
      if (remaining_probability < SMALL_FLOAT) break;
    }

    // process the working list
    int nummotifsfound = 0;
    for (list<tmpstruc1 *>::iterator it = worklist.begin(); it != worklist.end();) {
      tmpstruc1 *&current = *it;
      initial[wi][current->mindex] += current->ail;
      nummotifsfound++;
      it++;
    }    
    float sum = 0;
    for (int j=0; j<numWM; j++) sum += initial[wi][j];
    if (sum < 1) initial[wi][bkgIndex] = 1-sum;
    else {
      for (int j=0; j<numWM; j++) initial[wi][j] /= sum;
    }

    // delete the working list
    for (list<tmpstruc1 *>::iterator it = worklist.begin(); it != worklist.end();) {
      tmpstruc1 *&current = *it;
      it = worklist.erase(it);
      delete current;
    }      
  }

  return initial;
}

void Parameters_H0::DeleteSpaceForLastMotifs(float **initial)
{
  int numWindows = _windows->size();
  int numWM = _numWM;

  if (initial) {
    for (int wi=0; wi<numWindows; wi++) 
      delete [] initial[wi];
    delete [] initial;
  }

  return;
}
#endif


void Parameters_H0::SetParameters(DTYPE  *p)
{
  for (int i=0; i<_numWM; i++) _pi[i] = p[i];
}

DTYPE Parameters_H0::GetParameter(int wmindex)
{
  return _pi[wmindex];
}


#define MINIMUM_OVERLAP 1

int Parameters_H0::MaximumLeftOverlap(AlignmentNode *al, float occurrence_threshold)
{
  int position = al->_l1;
  Window *win = (*_windows)[0];
  int length = win->Length();
  int rel_position = position - win->Start();
  if (rel_position < 0) return 0;
  if (rel_position >= length) return 0;


  _currentWindow = win;
  Forward();
  Backward();
  PrepareForUpdate();  
  DTYPE  correction = FringeCorrectionFactor(0);      	

  int bkgIndex = BackgroundIndex();
  int best_wm_index = -1;
  int best_so_far = rel_position;
  for (int i=0; i<_numWM; i++) {
    if (i==bkgIndex) continue;
    int wm_len = _wmc->WM(i)->Length();
    if (wm_len == 1) continue;
    for (int l=rel_position-wm_len+MINIMUM_OVERLAP; l<rel_position; l++) {
      if (l < 0) continue;
      DTYPE  ail = _Ail_window[i][l]*correction;
      if (ail > occurrence_threshold && best_so_far > l) {
	best_so_far = l;
	best_wm_index = i;
	break;
      }
    }
  }
  if (best_wm_index >= 0) {
    char name[32];
    _wmc->WM(best_wm_index)->Name(name);
    // printf("left: %s: %d %d\n",name, _wmc->WM(best_wm_index)->Length(), rel_position-best_so_far);
  }
  return rel_position-best_so_far;
}

int Parameters_H0::MaximumRightOverlap(AlignmentNode *al, float occurrence_threshold)
{
  int position = al->_r1;
  Window *win = (*_windows)[0];
  int length = win->Length();
  int rel_position = position - win->Start();
  if (rel_position < 0) return 0;
  if (rel_position >= length) return 0;


  _currentWindow = win;
  Forward();
  Backward();
  PrepareForUpdate();  
  DTYPE  correction = FringeCorrectionFactor(0);      	

  int bkgIndex = BackgroundIndex();
  int best_wm_index = -1;
  int best_so_far = rel_position;
  for (int i=0; i<_numWM; i++) {
    if (i==bkgIndex) continue;
    int wm_len = _wmc->WM(i)->Length();
    if (wm_len == 1) continue;
    for (int l=rel_position-wm_len+2; l<=rel_position-MINIMUM_OVERLAP+1; l++) {
      if (l < 0) continue;
      if (l+wm_len-1 >= length) continue;
      DTYPE  ail = _Ail_window[i][l]*correction;
      if (ail > occurrence_threshold && best_so_far < l+wm_len-1) {
	best_so_far = l+wm_len-1;
	best_wm_index = i;
      }
    }
  }
  if (best_wm_index >=0 ) {
    char name[32];
    _wmc->WM(best_wm_index)->Name(name);
    // printf("right: %s: %d %d\n",name, _wmc->WM(best_wm_index)->Length(), best_so_far-rel_position);
  }
  return best_so_far-rel_position;
}

Parameters_H0::Parameters_H0()
{
  _pi = _oldpi = NULL;
  _alpha = _beta = NULL;
  _cij = NULL;
  _Ai = NULL;
  _Ail_window = NULL;
  _c = NULL; 
}

Parameters_H0::~Parameters_H0()
{
  Destroy();
}

void Parameters_H0::Destroy()
{
  int i;

  if (_pi) {
    delete [] _pi;
  }

  if (_oldpi) {
    delete [] _oldpi;
  }

  if (_free_emission_probabilities) {
    for (i=0; i<_numWM; i++) {
      delete [] _free_emission_probabilities[i];
    }
    delete [] _free_emission_probabilities;
  }

  if (_bkgwm) delete _bkgwm;
  if (_wm_len) delete [] _wm_len;

  if (_windows==NULL) return;

  if (_Ai) {
    int numWindows = _windows->size();
    for (int wi=0; wi<numWindows; wi++) {
      if (_Ai[wi]) {
	  delete [] _Ai[wi];	  
      }
    }
    delete [] _Ai;
    _Ai = NULL;
  }

  if (_Ail_window) {
    for (i=0; i<_numWM; i++) {
      if (_Ail_window[i]) {
	delete [] _Ail_window[i];
      }
    }
    delete [] _Ail_window;
    _Ail_window = NULL;
  }

  if (_Eiks) {
    for (int i=0; i<_numWM; i++) {
      if (_Eiks[i]) {
	int wm_len_i = _wmc->WM(i)->Length();
	for (int k=0; k<wm_len_i; k++) _Eiks[i][k].clear();
	delete [] _Eiks[i];
      }
    }
    delete [] _Eiks;
  }

  if (_alpha) {
    delete [] _alpha;    
    _alpha = NULL;
  }
  if (_beta) {
    delete [] _beta;
    _beta = NULL;
  }
  if (_c) {
    delete [] _c;
    _c = NULL;
  }

  if (_cij) {
    for (i=0; i<_max_window_length; i++) {
      if (_cij[i]) delete [] _cij[i];
    }
    delete [] _cij;
    _cij = NULL;
  }

  if (_fringe_corrections) {
    delete [] _fringe_corrections;
    _fringe_corrections = NULL;
  }

  // destroy the cache if present
  if (_currentwindowcache) {
    int numWindows = _windows->size();
    for (int wi=0; wi<numWindows; wi++) _currentwindowcache[wi].Destroy();
    delete [] _currentwindowcache;
    _currentwindowcache = NULL;
  }

  return;
}

Parameters_H0::Parameters_H0(const Parameters_H0 &p)
{
  Copy(p);
}

Parameters_H0& Parameters_H0::operator=(const Parameters_H0 &p)
{
  if (this == &p) return *this;
  Destroy();
  Copy(p);
}

void Parameters_H0::Copy(const Parameters_H0 &p)
{
  _wmc = p._wmc;
  _numWM = p._numWM;
  _windows = p._windows;
  _is_initialized = p._is_initialized;
  _is_trained = p._is_trained;
  _numSpecies = p._numSpecies;

  int i;

  if (_numWM && p._pi) {
    _pi = new float [_numWM];
    for (i=0; i < _numWM; i++) {
      _pi[i] = p._pi[i];
    }
  }
  else _pi = NULL;

  if (_numWM && p._oldpi) {
    _oldpi = new float [_numWM];
    for (i=0; i< _numWM; i++) {
      _oldpi[i] = p._oldpi[i];
    }
  }
  else _oldpi = NULL;

  int bkgIndex = BackgroundIndex();
  if (_numWM && p._free_emission_probabilities) {
    _free_emission_probabilities = new bool *[_numWM];
    WtMx *w;
    for (i=0; i<_numWM; i++) {
      if (i==bkgIndex) w = p._bkgwm;
      else w = p._wmc->WM(i);
      _free_emission_probabilities[i] = new bool[w->Length()];
      for (int j=0; j<w->Length(); j++) {
	_free_emission_probabilities[i][j] = p._free_emission_probabilities[i][j];
      }
    }
  }
  else _free_emission_probabilities = NULL;

  if (_windows && _numWM && p._Ai) {
    int numWindows = _windows->size();
    _Ai = new DTYPE  *[numWindows];
    for (int wi=0; wi<numWindows; wi++) {
      int length = (*_windows)[wi]->Length();
      _Ai[wi] = new DTYPE  [_numWM];
      for (int i=0; i<_numWM; i++) {
	_Ai[wi][i] = p._Ai[wi][i];
      }
    }
  }
  else _Ai = NULL;

  if (_windows && _numWM && p._Eiks) {
    _Eiks = new map_type *[_numWM];
    for (int i=0; i<_numWM; i++) {
      if (i==BackgroundIndex(_wmc)) {
	_Eiks[i] = NULL;
	continue;
      }
      int wm_len_i = _wmc->WM(i)->Length();	
      _Eiks[i] = new map_type[wm_len_i];
      for (int k=0; k<wm_len_i; k++) {
	_Eiks[i][k] = p._Eiks[i][k];
      }
    }
  }
  else _Eiks = NULL;
  
  _currentWindow = NULL;
  _alpha = _beta = NULL;
  _cij = NULL;
  _Ail_window = NULL;

  _bkgwm = new WtMx(p._bkgwm);
  _c = NULL;
  _free_energy = p._free_energy;
  _free_energy_differential = p._free_energy_differential;
  _initialbias = p._initialbias;
  _num_iterations = p._num_iterations;

  _is_initialized = p._is_initialized;

  return;
}

Parameters_H0::Parameters_H0(WtMxCollection *wmc, int extreme)
{
  int i;

  _wmc = wmc;
  _numWM = _wmc->Size()+1;
  _pi = new float[_numWM];
  _oldpi = new float[_numWM];
  for (i=0; i<_numWM; i++) {
    if (i==extreme) {
	_pi[i] = ALMOST_ONE;
    }
    else {
      _pi[i] = (1-ALMOST_ONE)/(_numWM-1);
    }
    _oldpi[i] = _pi[i];
  }

  _Ai = NULL;
  _currentWindow = NULL;
  _alpha = _beta = NULL;
  _cij = NULL;
  _Ail_window = NULL;

  _bkgwm = NULL;
  _c = NULL; 
  _free_energy = 0;
  _free_energy_differential = 0;
  _numSpecies = 1;
  _is_initialized = true;
}


DTYPE  Parameters_H0::Norm_of_parameter_difference()
{
  DTYPE  sum = 0;
  for (int i=0; i<_numWM; i++) {
    sum += (_pi[i]-_oldpi[i])*(_pi[i]-_oldpi[i]);
  }
  return sqrt(sum)/_numWM;
}

char *Parameters_H0::CreateSequence(int length, int randseed, bool verbose)
{
  int i;
  char *sequence = new char[length+1];
  int bkgIndex = BackgroundIndex(); // the background matrix corresponds to last index
  WtMx **wm = new WtMx *[_numWM];
  for (i=0; i<_numWM; i++) {
    if (i!=bkgIndex) {
      wm[i] = _wmc->WM(i);
    }
    else {
      wm[i] = _bkgwm;
    }
  }
                                    
  float *cum = new float[_numWM];
  cum[0] = _pi[0];
  for (i=1; i<_numWM; i++) {
    cum[i] = cum[i-1] + _pi[i];
  }

  int *count = new int[_numWM];
  for (i=0; i<_numWM; i++) count[i] = 0;

  srandom(randseed);
  int pos = 0;
  while (pos < length) {
    float r = random()/float(RAND_MAX);
    int rindex = -1;
    if (r < cum[0]) {
      rindex = 0; 
    }
    else {
      for (int j=1; j<_numWM; j++) {
	if (r < cum[j]) {
	  rindex = j;
	  break;
	}
      }
      if (rindex==-1) rindex = _numWM-1;
    }
    // plant a wm[rindex]
    // but first decide orientation:
    int orientation = count[rindex]%2;
    for (int l=0; l<_wm_len[rindex]; l++) {
      if (orientation==0) 
	sequence[pos] = wm[rindex]->GetRandomChar(l);
      else 
	sequence[pos] = ReverseChar(wm[rindex]->GetRandomChar(_wm_len[rindex]-1-l));
      pos++;
      if (pos >= length) break;
    }
    count[rindex]++;
  }

  if (verbose) {
    printf("Planting stats: ");
    for (i=0; i<_numWM; i++) printf("%d %d, ",i,count[i]);
    printf("\n");
  }

  sequence[length] = 0;

  delete [] count;
  delete [] cum;
  delete [] wm;

  return sequence;
}

int Parameters_H0::ArrayOfCharToIndex(char *arrayofchar)
{
  int index = 0;
  char *ptr = arrayofchar;
  int numSeq = (int)(*ptr++);
  for (int i=0; i<numSeq; i++) {
    char seqindex = (*ptr++);
    char chindex  = (*ptr++);
    chindex++;
    index |= (chindex << 3*seqindex);
  }
  return index;
}

int Parameters_H0::ArrayOfCharToIndex(char chindex, int seqindex)
{
  int index = 0;
  index |= ((chindex+1) << 3*seqindex);
  return index;
}

void Parameters_H0::IndexToArrayOfChar(int index, char *arrayofchar)
{
  int numSeq = 0;
  for (int i=0; i<_numSpecies; i++) {
    int chindex = index & 7;  // get the last three bits
    index = index >> 3;
    if (chindex == 0) continue;
    arrayofchar[1+2*numSeq] = i;
    arrayofchar[2+2*numSeq] = chindex-1;
    numSeq++;
  }
  arrayofchar[0] = numSeq;
  return;
}

void Parameters_H0::ReverseArrayOfChar(char *arrayofchar)
{
  int numSeq = arrayofchar[0];
  for (int i=0; i<numSeq; i++) {
    char chindex = arrayofchar[2+2*i];
    if (chindex >=0 && chindex <= 3) {
      arrayofchar[2+2*i] = 3-chindex;
    }
  }
}

void Parameters_H0::MaskOccurrences(int wmindex, float occurrence_threshold)
{
  int bkgIndex = BackgroundIndex(); // the background matrix corresponds to last index
  WtMx **wm = new WtMx *[_numWM];
  for (int i=0; i<_numWM; i++) {
    if (i!=bkgIndex) {
      wm[i] = _wmc->WM(i);
    }
    else {
      wm[i] = _bkgwm;
    }
  }
  
  int numWindows = _windows->size();
  for (int wi=0; wi<numWindows; wi++) {
    Window *window = (*_windows)[wi];
    _currentWindow = window;

    Forward();
    Backward();
    PrepareForUpdate();

    int length = window->Length();
    DTYPE  correction = FringeCorrectionFactor(wi);      	

    for (int l=0; l<length; l++) {
      // see if there's a new motif starting here
      for (int rc=0; rc<(_revComp?2:1); rc++) {
	int wmi;
	if (rc==0) wmi = wmindex;
	if (rc==1) wmi = wmindex+1;
	if (l >= length-_wm_len[wmi]+1) continue;
	DTYPE  ail = _Ail_window[wmi][l]*correction;
	if (ail > occurrence_threshold) {
	  // l .. l+w-1 is motif
	  // mask central w/3, i.e., l+ ceil(w/3) .. l+ trunc(2w/3)
	  // int posl = l + (int)ceilf(_wm_len[wmi]/3);
	  // int posr = l + (int)(2*_wm_len[wmi]/3);
	  // mask central base, i.e., l+ trunc(w/2) .. l+ ceil(w/2)
#ifndef _MASK_THISMANYCENTRALBASES_
	  int posl = l + (int)(_wm_len[wmi]/2);
	  int posr = l + (int)ceilf(_wm_len[wmi]/2);
	  for (int pos=posl; pos <= posr; pos++) {
	    window->Mask(pos);
	  }
#else
	  int posl = l+ int((_wm_len[wmi]-_MASK_THISMANYCENTRALBASES_+1)/2);
	  int posr = l+ int((_wm_len[wmi]+_MASK_THISMANYCENTRALBASES_)/2); 
	  for (int pos=posl; pos <= posr; pos++) {
	    window->Mask(pos);
	  }
#endif
	}    
      }  
    }
  }

  delete [] wm;
  return;
}
    
struct Occurrence {
  char _wmname[64];
  char _seqname[1024];
  char _sequence[64];
  int  _motiflen;
  DTYPE _strength;
  int  _speciesindex;
  bool _rc;
  int  _position;
  bool _aligned;
  void Print(FILE *fp) { 
    int seqlen = strlen(_sequence);
    if (_rc) {
      char *seq = new char[seqlen+1];
      for (int i=0; i<seqlen; i++) {
	switch(_sequence[i]) {
	case 'a': seq[seqlen-1-i] = 't'; break;
	case 'A': seq[seqlen-1-i] = 'T'; break;
	case 'c': seq[seqlen-1-i] = 'g'; break;
	case 'C': seq[seqlen-1-i] = 'G'; break;
	case 'g': seq[seqlen-1-i] = 'c'; break;
	case 'G': seq[seqlen-1-i] = 'C'; break;
	case 't': seq[seqlen-1-i] = 'a'; break;
	case 'T': seq[seqlen-1-i] = 'A'; break;
	default:  seq[seqlen-1-i] = _sequence[i]; break;
	}
      }
      seq[seqlen] = 0;      
      fprintf(fp,"%s\t%s\t%s\t%d\t%d\t%.2f\t-\t",seq,_seqname,_wmname,_position+_motiflen-1,_position,_strength); 
      delete [] seq;
    }
    else 
      fprintf(fp,"%s\t%s\t%s\t%d\t%d\t%.2f\t+\t",_sequence,_seqname,_wmname,_position,_position+_motiflen-1,_strength); 
    
    if (_aligned) fprintf(fp,"Aligned\n");
    else fprintf(fp,"Not Aligned\n");
  }
} ;

int CompareOccurrence(const void *lv, const void *rv) 
{
  struct Occurrence *l = (struct Occurrence *)lv;
  struct Occurrence *r = (struct Occurrence *)rv;
  if (l->_strength > r->_strength) return -1;
  if (l->_strength < r->_strength) return 1;
  if (l->_position < r->_position) return -1;
  if (l->_position > r->_position) return 1; 
  return 0;
}

void Parameters_H0::PrintOccurrences(FILE *fp, int wmindex, float occurrence_threshold, int context)
{
  int bkgIndex = BackgroundIndex(); // the background matrix corresponds to last index
  WtMx **wm = new WtMx *[_numWM];
  for (int i=0; i<_numWM; i++) {
    if (i!=bkgIndex) {
      wm[i] = _wmc->WM(i);
    }
    else {
      wm[i] = _bkgwm;
    }
  }
  
  struct Occurrence *occurrences = new struct Occurrence[10000];
  int numoccurrences = 0;
  
  int numWindows = _windows->size();
  for (int wi=0; wi<numWindows; wi++) {
    Window *window = (*_windows)[wi];
    _currentWindow = window;

    Forward();
    Backward();
    PrepareForUpdate();

    int length = window->Length();
    DTYPE  correction = FringeCorrectionFactor(wi);      	

    for (int l=0; l<length; l++) {
      // see if there's a new motif starting here
      for (int rc=0; rc<(_revComp?2:1); rc++) {
	int wmi;
	if (rc==0) wmi = wmindex;
	if (rc==1) wmi = wmindex+1;
	if (l >= length-_wm_len[wmi]+1) continue;
	DTYPE  ail = _Ail_window[wmi][l]*correction;
	if (ail > occurrence_threshold) {
	  char *sequence = new char[2*context + _wm_len[wmi] + 5];
	  ExtractSequenceWithContext(l, _wm_len[wmi], context, window->Seq(), window->Start(), sequence);
	  strcpy(occurrences[numoccurrences]._sequence,sequence);
	  delete [] sequence;
	  occurrences[numoccurrences]._strength = ail;
	  occurrences[numoccurrences]._speciesindex = window->Seq()->GetSpeciesIndex();
	  occurrences[numoccurrences]._rc = (rc==1);
	  occurrences[numoccurrences]._position = l;
	  occurrences[numoccurrences]._aligned = false;
	  occurrences[numoccurrences]._motiflen = _wm_len[wmi];
	  char wmname[64];
	  wm[wmi]->Name(wmname);
	  strcpy(occurrences[numoccurrences]._wmname,wmname);
	  char seqname[1024];
	  window->Seq()->Name(seqname);
	  for (int k=0; k<strlen(seqname); k++) 
	    if (seqname[k]==' ' || seqname[k]=='\t') seqname[k] = '_';
	  strcpy(occurrences[numoccurrences]._seqname,seqname);
	  numoccurrences++;
	  if (numoccurrences >= 10000) {
	    printf("Error: too many occurrences (>= 10000) of motif. Try increasing the \"-ot\" argument to program.\n");
	    exit(1);
	  }

	  if (window->Seq()->GetSpeciesIndex()==0) { // is this the reference sequence 	    
	    struct AlignmentNode *ndlist = window->Seq()->_alignments->GetAlignmentNodeList(window->Seq(),l,l+_wm_len[wmi]);
	    for (struct AlignmentNode *ptr = ndlist; ptr != NULL; ptr = ptr->_next) {
	      int leftposinblock = l-ptr->_l1;
	      int rightposinblock = l+_wm_len[wmi]-1-ptr->_l1;
	      int leftpos2 = ptr->_l2+leftposinblock;
	      int rightpos2 = ptr->_l2+rightposinblock;
	      if (leftpos2 < ptr->_l2 || rightpos2 > ptr->_r2) {
		continue;
	      }
	      char *sequence = new char[2*context + _wm_len[wmi] + 5];
	      ExtractSequenceWithContext(leftpos2, rightpos2-leftpos2+1, context, ptr->_otherSeq, 0, sequence);
	      strcpy(occurrences[numoccurrences]._sequence,sequence);
	      delete [] sequence;
	      occurrences[numoccurrences]._strength = ail;
	      occurrences[numoccurrences]._speciesindex = ptr->_otherSeq->GetSpeciesIndex();
	      occurrences[numoccurrences]._rc = (rc==1);
	      occurrences[numoccurrences]._position = leftpos2;
	      occurrences[numoccurrences]._aligned = true;
	      occurrences[numoccurrences-1]._aligned = true;
	      occurrences[numoccurrences]._motiflen = _wm_len[wmi];
	      strcpy(occurrences[numoccurrences]._wmname,wmname);
	      ptr->_otherSeq->Name(seqname);
	      for (int k=0; k<strlen(seqname); k++) 
		if (seqname[k]==' ' || seqname[k]=='\t') seqname[k] = '_';
	      strcpy(occurrences[numoccurrences]._seqname,seqname);
	      numoccurrences++;
	      if (numoccurrences >= 10000) {
		printf("Error: too many occurrences (>= 10000) of motif. Try increasing the \"-ot\" argument to program.\n");
		exit(1);
	      }
	    }
	  }	      
	}      
      }
    }
  }

  qsort(occurrences, numoccurrences, sizeof(struct Occurrence), CompareOccurrence);
  for (int i=0; i<numoccurrences; i++) {
    occurrences[i].Print(fp);
  }
  delete [] occurrences;
  delete [] wm;
  return;
}

void Parameters_H0::ExtractSequenceWithContext(int l, int mlength, int context, Sequence *seq, int windowstart, char *sequence)
{
  int ptr = 0;
  for (int pos = 0; pos < context; pos++) {
    if (l-context+pos < 0) sequence[ptr++] = 'x';
    else sequence[ptr++] = seq->CharAt(windowstart+l-context+pos);
    sequence[ptr-1] = tolower(sequence[ptr-1]);
  }
  for (int pos = 0; pos < mlength; pos++) {
    sequence[ptr++] = seq->CharAt(windowstart+l+pos);
  }	  
  for (int pos = 0; pos < context; pos++) {
    if (l+mlength+pos >= seq->Length()) sequence[ptr++] = 'x';
    else sequence[ptr++] = seq->CharAt(windowstart+l+mlength+pos);
    sequence[ptr-1] = tolower(sequence[ptr-1]);
  }
  sequence[ptr++] = 0;
  return;
}
