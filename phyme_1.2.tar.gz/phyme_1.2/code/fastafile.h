/*****************************************************************
        Copyright by Rockefeller University,
can not be reproduced or distributed without written permission of
copyright holder.  

Written by Saurabh Sinha, Mathieu Blanchette, and Martin Tompa.

The PhyME program implements an algorithm to find
motifs in sets of orthologous sequences, as described in the
following paper:
"PhyME: A probabilistic algorithm for finding motifs in sets of 
orthologous sequences"
by Saurabh Sinha , Mathieu Blanchette  and Martin Tompa.
BMC Bioinformatics 2004, 5:170     doi:10.1186/1471-2105-5-170
Published 28 October 2004.

******************************************************************/
#ifndef _fastafile_h_
#define _fastafile_h_

#include "sequence.h"

#define MAX_NUM_SEQUENCES 10000

class FastaFile {
  Sequence *_sequences[MAX_NUM_SEQUENCES];
  int _numSequences;
public:
  FastaFile();
  void ReadFasta(char *filename);
  ~FastaFile();
  int Size();
  Sequence *operator[](int index);
};

#endif
