/*****************************************************************
        Copyright by Rockefeller University,
can not be reproduced or distributed without written permission of
copyright holder.  

Written by Saurabh Sinha, Mathieu Blanchette, and Martin Tompa.

The PhyME program implements an algorithm to find
motifs in sets of orthologous sequences, as described in the
following paper:
"PhyME: A probabilistic algorithm for finding motifs in sets of 
orthologous sequences"
by Saurabh Sinha , Mathieu Blanchette  and Martin Tompa.
BMC Bioinformatics 2004, 5:170     doi:10.1186/1471-2105-5-170
Published 28 October 2004.

******************************************************************/
#include "parameters.h"
#include <math.h>
#include <stdexcept>
#include "util.h"

Parameters::probabilitycache::probabilitycache()
{
  _prob = NULL;
  _wms = NULL;
  _numWM = 0;
  _start = 0;
  _length = 0;
  _associatedCurrentWindow = NULL;
}

Parameters::probabilitycache& Parameters::probabilitycache::operator=(const probabilitycache &pc)
{
  if (this == &pc) return *this;
  Destroy();
  Copy(pc);
}

Parameters::probabilitycache::probabilitycache(const probabilitycache &pc)
{
  Copy(pc);
}

Parameters::probabilitycache::~probabilitycache()
{
  Destroy();
}

void Parameters::probabilitycache::Copy(const probabilitycache &pc)
{
  const probabilitycache *pcptr = &pc;
  if (pcptr==NULL) {
    printf("Error: copy called for null probabilitycache\n");
    exit(1);
  }

  int i;
  _numWM = pcptr->_numWM;
  _start = pcptr->_start;
  _length = pcptr->_length;

  Window *pcptr_window = pcptr->_associatedCurrentWindow;
  _associatedCurrentWindow = pcptr_window;   // shallow copy

  if (pcptr->_wms) {
    _wms = new WtMx*[_numWM];
    for (i=0; i<_numWM; i++) 
      _wms[i] = pcptr->_wms[i];
  }
  else _wms = NULL;

  if (pcptr->_prob) {
    _prob = new DTYPE  *[_numWM];
    for (int j=0; j<_numWM; j++) {
      _prob[j] = new DTYPE [_length];
      for (int l=0; l<_length; l++) 
	_prob[j][l] = pcptr->_prob[j][l];
    }
  }
  else _prob = NULL;
  
}

void Parameters::probabilitycache::Destroy()
{
  if (_prob) {
    for (int j=0; j<_numWM; j++) {
      if (_prob[j]) delete [] _prob[j];
    }
    delete [] _prob;
    _prob = NULL;
  }

  if (_wms) {
    delete [] _wms;
    _wms = NULL;
  }

}

Parameters::Phylogeny::Phylogeny()
{
  _mu = NULL;
  _tree = NULL;
  _numSpecies = 0;
  _type = FLATARRAY;
}

Parameters::Phylogeny::~Phylogeny()
{
  if (_mu != NULL) delete [] _mu;
  if (_tree != NULL) delete _tree;
  _mu = NULL;
  _tree = NULL;
}

DTYPE  Parameters::Phylogeny::ComputeProbability(WtMx *wm, int index, bool rev_orientation, char *arrayofchar)
  // this is capable of handling multiple sequences, but only with independence assumption
  // do not use this if you want to handle ms and horder bkgwm accurately
  // rev_orientation only specifies that the observed nucleotides have to be complemented. 
  // the index is taken care of by caller.
{
  if (GetPhylogenyType() == FLATARRAY) {
    DTYPE  sum = 0;
    for (int a=0; a<4; a++) {  // ancestor char at this position
      sum += wm->Frequency(index,a)*ComputeProbabilityGivenAncestor(wm,index,(rev_orientation?1:0),a,arrayofchar);
    }
    return sum;
  }
  if (GetPhylogenyType() == TREE) {
    if (_tree == NULL || _tree->root == NULL) { printf("Error: Type tree but no tree stored\n"); return 0; }
    // convert arrayofchar to a direct addressible format
    char hashofchar[MAX_ALIGNED_SEQUENCES];
    for (int i=0; i<MAX_ALIGNED_SEQUENCES; i++) hashofchar[i] = -1;
    char numseq = *arrayofchar;
    char *ptr = arrayofchar; ptr++;
    for (int j=0; j<numseq; j++) {
      char seqindex = *ptr++;
      char indch = *ptr++;
      hashofchar[seqindex] = indch;
    }

    DTYPE  sum = 0;
    int orientation = (rev_orientation?1:0);
    ComputeProbabilityOfTreeGivenParentHelper(wm, index, orientation, hashofchar, _tree->root);
    for (int a=0; a<4; a++) {  // ancestor char at this position
      DTYPE term = wm->Frequency(index,a);
      //for (list<struct Tree::Node *>::iterator it = _tree->root->children.begin(); it != _tree->root->children.end(); it++) {
      //struct Tree::Node *nd = (*it);
      for (int it = 0; it < _tree->root->numChildren; it++) {
	struct Tree::Node *nd = _tree->root->children_array[it];
	term *= ComputeProbabilityOfTreeGivenParent(wm,index,orientation,a,hashofchar,nd);
      }
      sum += term;
    }
    return sum;
  }
  printf("Warning: ComputeProbability returning dummy value\n");
  return 0;
}

DTYPE  Parameters::Phylogeny::ComputeProbabilityGivenAncestor(WtMx *wm, int index, int orientation, int a, char *arrayofchar, int *history)
  // this is for flat array phylogeny (star) only.
  // given the center of the star, computes probability of all the leaves of the star
  // orientation: 0 => forward only, 1 => backward only, 2 => both ("both" used only for background)
  // history[seq_index] has the history word for leaf sequence seq_index, and -1 if not enough history.
  // note: the "both orientation" case is not supported nay more.
{
  char numseq = *arrayofchar;
  DTYPE  term = 1;
  if (history == NULL) {
    char *ptr = arrayofchar; ptr++;
    for (int j=0; j<numseq; j++) {
      char seqindex = *ptr++;
      float mu = _mu[seqindex];
      char indch = *ptr++;
      char indrevch = (indch <= 3 ? 3-indch : indch);
      if (orientation==0) 
	term *= (mu*wm->Frequency(index,indch) + (indch==a?1-mu:0));
      if (orientation==1) 
	term *= (mu*wm->Frequency(index,indrevch) + (indrevch==a?1-mu:0));
      if (orientation==2) {
	printf("Error: orientation 2 no longer supported\n");
	exit(1);
      }
    }
    return term;  
  }
  else {
    char *ptr = arrayofchar; ptr++;
    for (int j=0; j<numseq; j++) {
      char seqindex = *ptr++;
      float mu = _mu[seqindex];
      char indch = *ptr++;
      char indrevch = (indch <= 3 ? 3-indch : indch);
      int hword = history[seqindex];
      if (hword==-1) {  // dont use history
	if (orientation==0) 
	  term *= (mu*wm->Frequency(index,indch) + (indch==a?1-mu:0));
	if (orientation==1)
	  term *= (mu*wm->Frequency(index,indrevch) + (indrevch==a?1-mu:0));
	if (orientation==2) {
	  printf("Error: orientation 2 no longer supported\n");
	  exit(1);
	}
      }
      else {            // use history
	if (orientation==0) 
	  term *= (mu*wm->Frequency(index,indch,hword) + (indch==a?1-mu:0));
	if (orientation==1)
	  term *= (mu*wm->Frequency(index,indrevch,hword) + (indrevch==a?1-mu:0));
	if (orientation==2) {
	  printf("Error: orientation 2 no longer supported\n");
	  exit(1);
	}
      }
    }
    return term;
  }
}

DTYPE  Parameters::Phylogeny::ComputeProbabilityOfTreeGivenRoot(WtMx *wm, int index, int orientation, int a, char *arrayofchar, Tree::Node *root, int *history)
  // this computes the probability of the entire subtree rooted at "root", given that the root itself has base 'a'.
  // orientation: 0 => forward only, 1 => backward only, 2 => both
  // backward orientation means that the leaf nodes are to be reversed, everything else remains same.
  // history[seq_index] has the history word for leaf sequence seq_index, and -1 if not enough history.
  // this differs from ComputeProbabilityGivenAncestor in that it can handle trees.
{
  // convert arrayofchar to a direct addressible format
  char hashofchar[MAX_ALIGNED_SEQUENCES];
  for (int i=0; i<MAX_ALIGNED_SEQUENCES; i++) hashofchar[i] = -1;
  char numseq = *arrayofchar;
  char *ptr = arrayofchar; ptr++;
  for (int j=0; j<numseq; j++) {
    char seqindex = *ptr++;
    char indch = *ptr++;
    hashofchar[seqindex] = indch;
  }

  DTYPE term = 1; 
  //for (list<struct Tree::Node *>::iterator it = root->children.begin(); it != _tree->root->children.end(); it++) {
  //struct Tree::Node *nd = (*it);
  ComputeProbabilityOfTreeGivenParentHelper(wm, index, orientation, hashofchar, _tree->root, history);
  for (int it = 0; it < _tree->root->numChildren; it++) {
    struct Tree::Node *nd = _tree->root->children_array[it];
    term *= ComputeProbabilityOfTreeGivenParent(wm,index,orientation,a,hashofchar,nd,history);
  }
  return term;
}

DTYPE  Parameters::Phylogeny::ComputeProbabilityOfTreeGivenParent(WtMx *wm, int index, int orientation, int a, char *hashofchar, Tree::Node *root, int *history)
  // this computes the probability of the entire subtree rooted at "root", given that the father of the root has base 'a'.
  // orientation: 0 => forward only, 1 => backward only, 2 => both
  // backward orientation means that the leaf nodes are to be reversed, everything else remains same.
  // history[seq_index] has the history word for leaf sequence seq_index, and -1 if not enough history.
  // this differs from ComputeProbabilityGivenAncestor in that it can handle trees.
  // also, it differs because a is the probability of the **parent** of the tree, rather than the root of the tree.
  // also, another difference is that the leaves are in hashpfchar and not arrayofchar
{
  if (!root->nodeInfo->valid) return 1;
  return root->nodeInfo->TGP[a];
}

void  Parameters::Phylogeny::ComputeProbabilityOfTreeGivenParentHelper(WtMx *wm, int index, int orientation, char *hashofchar, Tree::Node *root, int *history)
{
  if (root->no_children) { // leaf node 
    float mu = root->mu;	
    if (root->nodeInfo == NULL) root->nodeInfo = new NodeInfo;
    DTYPE  term = 1;
    if (history == NULL) {
      char indch = hashofchar[root->spc_index];
      if (indch < 0) {
	root->nodeInfo->valid = false;
	return;
      }
      root->nodeInfo->valid = true;
      char indrevch = (indch <= 3 ? 3-indch : indch);
      for (int a = 0; a < 4; a++) { // for all possible bases at parent
	DTYPE term;
	if (orientation==0) 
	  term = (mu*wm->Frequency(index,indch) + (indch==a?1-mu:0));
	if (orientation==1) 
	  term = (mu*wm->Frequency(index,indrevch) + (indrevch==a?1-mu:0));
	if (orientation==2) {
	  printf("Error: orientation 2 no longer supported\n");
	  exit(1);
	}          
	// store term
	root->nodeInfo->TGP[a] = term;
      }
    }
    else {
      char indch = hashofchar[root->spc_index];
      if (indch < 0) {
	root->nodeInfo->valid = false;
	return;
      }
      root->nodeInfo->valid = true;
      char indrevch = (indch <= 3 ? 3-indch : indch);
      int hword = history[root->spc_index];
      for (int a = 0; a < 4; a++) {
	DTYPE term;
	if (hword==-1) {  // dont use history 
	  if (orientation==0) 
	    term = (mu*wm->Frequency(index,indch) + (indch==a?1-mu:0));
	  if (orientation==1) 
	    term = (mu*wm->Frequency(index,indrevch) + (indrevch==a?1-mu:0));
	  if (orientation==2) {
	    printf("Error: orientation 2 no longer supported\n");
	    exit(1);
	  }
	}
	else {            // use history
	  if (orientation==0) 
	    term = (mu*wm->Frequency(index,indch,hword) + (indch==a?1-mu:0));
	  if (orientation==1)
	    term = (mu*wm->Frequency(index,indrevch,hword) + (indrevch==a?1-mu:0));
	  if (orientation==2) {
	    printf("Error: orientation 2 no longer supported\n");
	    exit(1);
	  }	 
	}
	root->nodeInfo->TGP[a] = term;
      }
    }
  }
  else { // internal node, apply recursion.
    for (int it = 0; it < root->numChildren; it++) {
      struct Tree::Node *nd = root->children_array[it];
      ComputeProbabilityOfTreeGivenParentHelper(wm,index,orientation,hashofchar,nd,history);
    }
    // computed children's terms, now use them to compute own
    if (root->nodeInfo == NULL) root->nodeInfo = new NodeInfo;
    // check if there is something below this, otherwise this internal node may be ignored
    bool somechildexists = false;
    for (int it = 0; it < root->numChildren; it++) {
      struct Tree::Node *nd = root->children_array[it];
      if (nd->nodeInfo->valid) somechildexists = true;
    }
    if (!somechildexists) {
      root->nodeInfo->valid = false;
      return;
    }
    root->nodeInfo->valid = true;
    // something does exist, so process this node. First, cache the wm frequencies
    for (int b = 0; b < 4; b++) {
      root->nodeInfo->freq[b] = wm->Frequency(index,b);
    }
    for (int a = 0; a < 4; a++) { // for each base in parent
      DTYPE sum = 0;
      for (int b=0; b < 4; b++) {
	float localmu = root->mu;       
	DTYPE term;
	if (orientation==2) {
	  printf("Error: orientation 2 no longer supported\n");
	  exit(1);
	}
	term = (localmu*root->nodeInfo->freq[b] + (b==a?1-localmu:0)); // orientation doesnt matter at this level (internal node)
	//for (list<Tree::Node *>::iterator it = root->children.begin(); it != root->children.end(); it++) {
	//Tree::Node *nd = (*it);
	for (int it = 0; it < root->numChildren; it++) {
	  struct Tree::Node *nd = root->children_array[it];
	  if (nd->nodeInfo->valid)
	    term *= nd->nodeInfo->TGP[b];
	}
	sum += term;
      }
      // store term as root->TGP[a]
      root->nodeInfo->TGP[a] = sum;
    }
  }
  return;
}

DTYPE  Parameters::Phylogeny::ComputeProbabilityFromCache(DDTYPE *u, bool rev_orientation, int index)
{
  if (GetPhylogenyType() == FLATARRAY) {
    printf("Error: ComputeProbabilityFromCache shouldnt be called for FLATARRAY phylogeny\n");
    exit(1);
  }
  if (GetPhylogenyType() == TREE) {
    if (_tree == NULL || _tree->root == NULL) { printf("Error: Type tree but no tree stored\n"); return 0; }
    return _tree->root->nodeInfo->f[0]; // taking alpha = 0, shouldnt matter, all alphas shd be same.
  }
  return 0;
}

DTYPE  Parameters::Phylogeny::ComputeFirstPartialDerivative(DDTYPE *u, bool rev_orientation, int index, int beta) 
{
  if (GetPhylogenyType() == FLATARRAY) {
    printf("Error: ComputeFirstPartialDerivative shouldnt be called for FLATARRAY phylogeny\n");
    exit(1);
  }
  if (GetPhylogenyType() == TREE) {
    if (_tree == NULL || _tree->root == NULL) { printf("Error: Type tree but no tree stored\n"); return 0; }
    return _tree->root->nodeInfo->f_b[0][beta]; // taking alpha = 0, shouldnt matter, all alphas shd be same.
  }
  return 0;
}

DTYPE  Parameters::Phylogeny::ComputeSecondPartialDerivative(DDTYPE *u, bool rev_orientation, int index, int beta, int gamma) 
{
  if (GetPhylogenyType() == FLATARRAY) {
    printf("Error: ComputeSecondPartialDerivative shouldnt be called for FLATARRAY phylogeny\n");
    exit(1);
  }
  if (GetPhylogenyType() == TREE) {
    if (_tree == NULL || _tree->root == NULL) { printf("Error: Type tree but no tree stored\n"); return 0; }
    return _tree->root->nodeInfo->f_b_g[0][beta][gamma]; // taking alpha = 0, shouldnt matter, all alphas shd be same.
  }
  return 0;
}

int Parameters::Phylogeny::IndexToChIndex(int index, int spc_index)
{
  int numSeq = 0;
  for (int i=0; i<_numSpecies; i++) {
    int chindex = index & 7;  // get the last three bits
    index = index >> 3;
    if (i==spc_index) {
      if (chindex == 0) chindex = 4; // absence of base treated as 'N'
      else chindex--;
      return chindex;
    }
  }
  printf("Error: spc_index not found in index\n");
  return 4;
}

void Parameters::Phylogeny::ComputeFTermsAndCacheThem(DDTYPE *u, bool rev_orientation, int index, int beta) 
{
  Tree::Node *root = _tree->root;
  root->mu = 1;  // this is a clean hack. it takes care of the fact that the root does not really have an ancestor.
  ComputeFTermsAndCacheThem(u, rev_orientation, index, beta, root);
}

void Parameters::Phylogeny::ComputeFTermsAndCacheThem(DDTYPE *u, bool rev_orientation, int index, int beta, Tree::Node *nd)
{
  if (nd->nodeInfo == NULL) {
    nd->nodeInfo = new struct NodeInfo;
  }
  if (nd->no_children) { // leaf node
    if (nd->nodeInfo->index != index) { // assign the base to this node
      nd->nodeInfo->base = IndexToChIndex(index, nd->spc_index);
      nd->nodeInfo->index = index;
    }
    if (nd->nodeInfo->base >= 4) {
      nd->nodeInfo->valid = false;
      for (int alpha = 0; alpha <= 3; alpha++) {      
	nd->nodeInfo->f[alpha] = 1;
	nd->nodeInfo->f_b[alpha][beta] = 0;	
      }
      nd->CacheNodeInfo(index,rev_orientation,beta); // stores away f and f_b in a hash indexed by index, rev_orientation
      return; 
    }
    
    nd->nodeInfo->valid = true;
    for (int alpha = 0; alpha <= 3; alpha++) {      
      float mu = nd->mu;
      char base = nd->nodeInfo->base;
      if (rev_orientation) base = 3-base; // if rev_orientation then reverse the base
      DDTYPE e_ubase = exp(u[base]);
      DDTYPE term = mu*e_ubase + (1-mu)*(alpha==base?1:0);
      nd->nodeInfo->f[alpha] = term;
      nd->nodeInfo->f_b[alpha][beta] = (beta==base?mu*exp(u[beta]):0);
    }
    nd->CacheNodeInfo(index,rev_orientation,beta); // stores away f and f_b in a hash indexed by index, rev_orientation
    return;
  }
  // internal node
  bool valid = false;
  //for (list<struct Tree::Node *>::iterator it = nd->children.begin(); it != nd->children.end(); it++) {
  //struct Tree::Node *chld = (*it);
  for (int it = 0; it < nd->numChildren; it++) {
    struct Tree::Node *chld = nd->children_array[it];
    ComputeFTermsAndCacheThem(u, rev_orientation, index, beta, chld);
    if (chld->nodeInfo->valid) valid = true;
  }
  nd->nodeInfo->valid = valid;
  if (!nd->nodeInfo->valid) {
    for (int alpha = 0; alpha <= 3; alpha++) {
      nd->nodeInfo->f[alpha] = 1;
      nd->nodeInfo->f_b[alpha][beta] = 0;
    }
    nd->CacheNodeInfo(index,rev_orientation,beta); // stores away f and f_b in a hash indexed by index, rev_orientation
    return;
  }
  // internal node that exists

  float mu = nd->mu;
  for (int alphaprime = 0; alphaprime <= 3; alphaprime++) {
    nd->nodeInfo->LCache1[alphaprime] = -1;
    nd->nodeInfo->LCache3[alphaprime][beta] = -1;
    for (int x=0; x < MAX_ALIGNED_SEQUENCES; x++) nd->nodeInfo->LCache2[alphaprime][x] = -1;
  }

  for (int alpha = 0; alpha <= 3; alpha++) {      
    if (nd == _tree->root && alpha != 0) continue; // for root, only need terms for alpha = 0, since alpha doesnt matter
    // Compute f[]
    DDTYPE f = 0;
    for (int alphaprime = 0; alphaprime <=3; alphaprime++) {
      DDTYPE term = 1;
      if (nd->nodeInfo->LCache1[alphaprime] == -1) {
	//for (list<struct Tree::Node *>::iterator it = nd->children.begin(); it != nd->children.end(); it++) {
	//struct Tree::Node *chld = (*it);
	for (int it = 0; it < nd->numChildren; it++) {
	  struct Tree::Node *chld = nd->children_array[it];
	  term *= chld->nodeInfo->f[alphaprime];
	}
	nd->nodeInfo->LCache1[alphaprime] = term;
      }
      else { // already computed \prod_c f(\psi_c,alphaprime) and stored in nd->nodeInfo->LCache1[alphaprime]
	term = nd->nodeInfo->LCache1[alphaprime];
      }
      term *= (mu*exp(u[alphaprime]) + (1-mu)*(alpha==alphaprime?1:0));
      f += term;
    }
    nd->nodeInfo->f[alpha] = f;

    // Compute f_b[][beta]
    DDTYPE term = 1;
    //for (list<struct Tree::Node *>::iterator it = nd->children.begin(); it != nd->children.end(); it++) {
    //struct Tree::Node *chld = (*it);
    //for (int it = 0; it < nd->numChildren; it++) {
    //struct Tree::Node *chld = nd->children_array[it];
    //term *= chld->nodeInfo->f[beta];
    //}      
    term = nd->nodeInfo->LCache1[beta]; // since it has already been computed earlier, for each beta (called alphaprime there)
    DDTYPE B = term*(mu*exp(u[beta]));

    DDTYPE A = 0;
    for (int alphaprime = 0; alphaprime <=3; alphaprime++) {
      DDTYPE term = (mu*exp(u[alphaprime]) + (1-mu)*(alpha==alphaprime?1:0));
      DDTYPE sum_x = 0;
      if (nd->nodeInfo->LCache3[alphaprime][beta] == -1) {
	//for (list<struct Tree::Node *>::iterator it = nd->children.begin(); it != nd->children.end(); it++) {
	//struct Tree::Node *x = (*it);
	for (int it = 0; it < nd->numChildren; it++) {
	  DDTYPE term2 = 1;
	  struct Tree::Node *x = nd->children_array[it];
	  if (nd->nodeInfo->LCache2[alphaprime][it] == -1) {
	    //for (list<struct Tree::Node *>::iterator it2 = nd->children.begin(); it2 != nd->children.end(); it2++) {
	    //struct Tree::Node *chld = (*it2);
	    for (int it2 = 0; it2 < nd->numChildren; it2++) {
	      struct Tree::Node *chld = nd->children_array[it2];
	      if (chld == x) continue;
	      term2 *= chld->nodeInfo->f[alphaprime];
	    }
	    nd->nodeInfo->LCache2[alphaprime][it] = term2;
	  }
	  else {
	    term2 = nd->nodeInfo->LCache2[alphaprime][it];
	  }
	  term2 *= x->nodeInfo->f_b[alphaprime][beta];
	  sum_x += term2;
	}
	nd->nodeInfo->LCache3[alphaprime][beta] = sum_x;
      }
      else {
	sum_x = nd->nodeInfo->LCache3[alphaprime][beta];
      }
      term *= sum_x;
      A += term;
    }
    nd->nodeInfo->f_b[alpha][beta] = A + B;
  }  

  nd->CacheNodeInfo(index,rev_orientation,beta); // stores away f and f_b in a hash indexed by index, rev_orientation
  return;
} 

void Parameters::Phylogeny::ComputeFTermsAndCacheThem(DDTYPE *u, bool rev_orientation, int index, int beta, int gamma) 
{
  Tree::Node *root = _tree->root;
  root->mu = 1;  // this is a clean hack. it takes care of the fact that the root does not really have an ancestor.
  ComputeFTermsAndCacheThem(u, rev_orientation, index, beta, gamma, root);
}

void Parameters::Phylogeny::ComputeFTermsAndCacheThem(DDTYPE *u, bool rev_orientation, int index, int beta, int gamma, Tree::Node *nd)
{
#ifdef _DDEBUG
  printf("Entered ComputeFTermsAndCacheThem\n");
#endif
  if (nd->nodeInfo == NULL) {
    nd->nodeInfo = new struct NodeInfo;
  }
  nd->LoadNodeInfo(index,rev_orientation,beta,gamma); // loads the stored f[] and f_b[][beta,gamma] 
                                                      // so that those computations are saved
  if (nd->no_children) { // leaf node
    if (nd->nodeInfo->index != index) { // assign the base to this node
      nd->nodeInfo->base = IndexToChIndex(index, nd->spc_index);
      nd->nodeInfo->index = index;
    }
    if (nd->nodeInfo->base >= 4) {
      nd->nodeInfo->valid = false;
      for (int alpha = 0; alpha <= 3; alpha++) {      
	//nd->nodeInfo->f[alpha] = 1;                 // saved
	//nd->nodeInfo->f_b[alpha][beta] = 0;	      // saved
	//nd->nodeInfo->f_b[alpha][gamma] = 0;	      // saved
	nd->nodeInfo->f_b_g[alpha][beta][gamma] = 0;
      }
#ifdef _DDEBUG
      printf("leaf node with nothing.\n");
      nd->Print(stdout);
      fflush(stdout);
      nd->nodeInfo->Print();
      //printf("<Enter> to continue: ");
      //getchar();
#endif
      return; 
    }
    
    nd->nodeInfo->valid = true;
    for (int alpha = 0; alpha <= 3; alpha++) {      
      float mu = nd->mu;
      char base = nd->nodeInfo->base;
      if (rev_orientation) base = 3-base; // if rev_orientation then reverse the base
      DDTYPE e_ubase = exp(u[base]);
      DDTYPE term = mu*e_ubase + (1-mu)*(alpha==base?1:0);
      //nd->nodeInfo->f[alpha] = term; // saved
      //nd->nodeInfo->f_b[alpha][beta] = mu*exp(u[beta])*(beta==base?1:0); // saved
      //nd->nodeInfo->f_b[alpha][gamma] = mu*exp(u[gamma])*(gamma==base?1:0); // saved
      nd->nodeInfo->f_b_g[alpha][beta][gamma] = ((beta==base)&&(gamma==base)?mu*exp(u[beta]):0);
    }
#ifdef _DDEBUG
    printf("leaf node with something.\n");
    nd->Print(stdout);
    fflush(stdout);
    nd->nodeInfo->Print();
    //printf("<Enter> to continue: ");
    //getchar();
#endif
    return;
  }
  // internal node
  bool valid = false;
  //for (list<struct Tree::Node *>::iterator it = nd->children.begin(); it != nd->children.end(); it++) {
  //struct Tree::Node *chld = (*it);
  for (int it = 0; it < nd->numChildren; it++) {
    struct Tree::Node *chld = nd->children_array[it];
#ifdef _DDEBUG
    printf("Going to compute fterms for child\n");
#endif
    ComputeFTermsAndCacheThem(u, rev_orientation, index, beta, gamma, chld);
#ifdef _DDEBUG
    printf("Computed fterms for child\n");
#endif
    if (chld->nodeInfo->valid) valid = true;
  }
  nd->nodeInfo->valid = valid;
  if (!nd->nodeInfo->valid) {
    for (int alpha = 0; alpha <= 3; alpha++) {
      //nd->nodeInfo->f[alpha] = 1; // saved
      //nd->nodeInfo->f_b[alpha][beta] = 0; // saved
      //nd->nodeInfo->f_b[alpha][gamma] = 0; // saved
      nd->nodeInfo->f_b_g[alpha][beta][gamma] = 0;
    }
#ifdef _DDEBUG
    printf("internal node with nothing.\n");
    nd->Print(stdout);
    fflush(stdout);
    nd->nodeInfo->Print();
    //printf("<Enter> to continue: ");
    //getchar();
#endif
    return;
  }
  // internal node that exists
  DDTYPE LCache4[4];
  for (int alphaprime = 0; alphaprime <= 3; alphaprime++) LCache4[alphaprime] = -1;
  float mu = nd->mu;
  for (int alpha = 0; alpha <= 3; alpha++) {      
    if (nd == _tree->root && alpha != 0) continue; // for root, only need terms for alpha = 0, since alpha doesnt matter
#ifdef _DDEBUG
    printf("Computing internal node f for %d\n",alpha);
#endif
    // Compute f[]
#if 0 // saved
    DDTYPE f = 0;
    for (int alphaprime = 0; alphaprime <=3; alphaprime++) {
#ifdef _DDEBUG
      printf("alphaprime = %d\n",alphaprime);
#endif
      DDTYPE term = 1;
      //for (list<struct Tree::Node *>::iterator it = nd->children.begin(); it != nd->children.end(); it++) {
      //struct Tree::Node *chld = (*it);
      for (int it = 0; it < nd->numChildren; it++) {
	struct Tree::Node *chld = nd->children_array[it];
	term *= chld->nodeInfo->f[alphaprime];
#ifdef _DDEBUG
	printf("Afterm multipying term by %.6f, term is %.6f\n",chld->nodeInfo->f[alphaprime],term);
#endif
      }
      term *= (mu*exp(u[alphaprime]) + (1-mu)*(alpha==alphaprime?1:0));
#ifdef _DDEBUG
      printf("Afterm multipying term by %.6f (mu = %.6f), term is %.6f, and added to f\n",(mu*exp(u[alphaprime]) + (1-mu)*(alpha==alphaprime?1:0)), mu, term);
#endif
      f += term;
#ifdef _DDEBUG
      printf("f is %.6f\n",f);
#endif
    }
    nd->nodeInfo->f[alpha] = f;
#ifdef _DDEBUG
    printf("Done computing internal node f for %d\n",alpha);
#endif
#endif  // saved

    // Compute f_b[][beta,gamma]
#if 0 // saved
    for (int i=0; i<2; i++) {
      int betaorgamma;
      if (i==0) betaorgamma = beta;
      else betaorgamma = gamma;

      DDTYPE term = 1;
      //for (list<struct Tree::Node *>::iterator it = nd->children.begin(); it != nd->children.end(); it++) {
      //struct Tree::Node *chld = (*it);
      for (int it = 0; it < nd->numChildren; it++) {
	struct Tree::Node *chld = nd->children_array[it];
	term *= chld->nodeInfo->f[betaorgamma];
      }      
      DDTYPE B = term*(mu*exp(u[betaorgamma]));
      DDTYPE A = 0;
      for (int alphaprime = 0; alphaprime <=3; alphaprime++) {
	DDTYPE term = (mu*exp(u[alphaprime]) + (1-mu)*(alpha==alphaprime?1:0));
	DDTYPE sum_x = 0;
	//for (list<struct Tree::Node *>::iterator it = nd->children.begin(); it != nd->children.end(); it++) {
	//struct Tree::Node *x = (*it);
	for (int it = 0; it < nd->numChildren; it++) {
	  struct Tree::Node *x = nd->children_array[it];
	  DDTYPE term2 = 1;
	  //for (list<struct Tree::Node *>::iterator it2 = nd->children.begin(); it2 != nd->children.end(); it2++) {
	  //struct Tree::Node *chld = (*it2);
	  for (int it2 = 0; it2 < nd->numChildren; it2++) {
	    struct Tree::Node *chld = nd->children_array[it2];
	    if (chld == x) continue;
	    term2 *= chld->nodeInfo->f[alphaprime];
	  }
	  term2 *= x->nodeInfo->f_b[alphaprime][betaorgamma];
	  sum_x += term2;
	}
	term *= sum_x;
	A += term;
      }
      nd->nodeInfo->f_b[alpha][betaorgamma] = A + B;
    }  
#endif // saved

    // Compute f_b_g[][beta][gamma]
    DDTYPE term = 1;
#if 0 // saved
    //for (list<struct Tree::Node *>::iterator it = nd->children.begin(); it != nd->children.end(); it++) {
    //struct Tree::Node *chld = (*it);
    for (int it = 0; it < nd->numChildren; it++) {
      struct Tree::Node *chld = nd->children_array[it];
      term *= chld->nodeInfo->f[beta];
    }    
#endif
    term = nd->nodeInfo->LCache1[beta]; // already computed and loaded from cache.
    DDTYPE C = (gamma==beta?mu*exp(u[beta])*term:0);

#if 0 // saved
    DDTYPE sum_x = 0;
    //for (list<struct Tree::Node *>::iterator it = nd->children.begin(); it != nd->children.end(); it++) {
    //struct Tree::Node *x = (*it);
    for (int it = 0; it < nd->numChildren; it++) {
      struct Tree::Node *x = nd->children_array[it];
      DDTYPE term2 = 1;
      //for (list<struct Tree::Node *>::iterator it2 = nd->children.begin(); it2 != nd->children.end(); it2++) {
      //struct Tree::Node *chld = (*it2);
      for (int it2 = 0; it2 < nd->numChildren; it2++) {
	struct Tree::Node *chld = nd->children_array[it2];
	if (chld == x) continue;
	term2 *= chld->nodeInfo->f[beta];
      }
      sum_x += term2*x->nodeInfo->f_b[beta][gamma];
    }
#endif 
    DDTYPE sum_x = nd->nodeInfo->LCache3[beta][gamma];
    DDTYPE B = mu*exp(u[beta])*sum_x;

    DDTYPE A = 0;
    for (int alphaprime=0; alphaprime <= 3; alphaprime++) {      
      DDTYPE sum_x = 0;
      if (LCache4[alphaprime] == -1) {
	//for (list<struct Tree::Node *>::iterator it = nd->children.begin(); it != nd->children.end(); it++) {
	//struct Tree::Node *x = (*it);
	for (int it = 0; it < nd->numChildren; it++) {
	  struct Tree::Node *x = nd->children_array[it];
	  DDTYPE sum_y = 0;
	  //for (list<struct Tree::Node *>::iterator it2 = nd->children.begin(); it2 != nd->children.end(); it2++) {
	  //struct Tree::Node *y = (*it2);
	  for (int it2 = 0; it2 < nd->numChildren; it2++) {
	    struct Tree::Node *y = nd->children_array[it2];
	    if (y == x) continue;
	    DDTYPE term3 = 1;
	    //for (list<struct Tree::Node *>::iterator it3 = nd->children.begin(); it3 != nd->children.end(); it3++) {
	    //struct Tree::Node *chld = (*it3);
	    for (int it3 = 0; it3 < nd->numChildren; it3++) {
	      struct Tree::Node *chld = nd->children_array[it3];
	      if (chld == y) continue;
	      if (chld == x) continue;
	      term3 *= chld->nodeInfo->f[alphaprime];
	    }
	    sum_y += term3*y->nodeInfo->f_b[alphaprime][gamma];
	  }
	  DDTYPE A1 = sum_y*x->nodeInfo->f_b[alphaprime][beta];
	  
	  DDTYPE term2 = 1;
#if 0
	  //for (list<struct Tree::Node *>::iterator it2 = nd->children.begin(); it2 != nd->children.end(); it2++) {
	  //struct Tree::Node *chld = (*it2);
	  for (int it2 = 0; it2 < nd->numChildren; it2++) {
	    struct Tree::Node *chld = nd->children_array[it2];
	    if (chld == x) continue;
	    term2 *= chld->nodeInfo->f[alphaprime];
	  }
#endif
	  term2 = nd->nodeInfo->LCache2[alphaprime][it];
	  DDTYPE A2 = term2*x->nodeInfo->f_b_g[alphaprime][beta][gamma];
	  
	  sum_x += (A1 + A2);
	}
	LCache4[alphaprime] = sum_x;
      }
      else sum_x = LCache4[alphaprime];
      A += (mu*exp(u[alphaprime]) + (1-mu)*(alpha==alphaprime?1:0))*sum_x;
    }
    
#if 0 // saved
    sum_x = 0;
    //for (list<struct Tree::Node *>::iterator it = nd->children.begin(); it != nd->children.end(); it++) {
    //struct Tree::Node *x = (*it);
    for (int it = 0; it < nd->numChildren; it++) {
      struct Tree::Node *x = nd->children_array[it];
      DDTYPE term2 = 1;
      //for (list<struct Tree::Node *>::iterator it2 = nd->children.begin(); it2 != nd->children.end(); it2++) {
      //struct Tree::Node *chld = (*it2);
      for (int it2 = 0; it2 < nd->numChildren; it2++) {
	struct Tree::Node *chld = nd->children_array[it2];
	if (chld == x) continue;
	term2 *= chld->nodeInfo->f[gamma];
      }
      sum_x += term2*x->nodeInfo->f_b[gamma][beta];
    }
#endif
    sum_x = nd->nodeInfo->LCache3[gamma][beta];
    DDTYPE D = sum_x*mu*exp(u[gamma]);
 
    nd->nodeInfo->f_b_g[alpha][beta][gamma] = A + D + B + C;
  }
#ifdef _DDEBUG
  printf("internal node with something.\n");
  nd->Print(stdout);
  fflush(stdout);
  nd->nodeInfo->Print();
  //printf("<Enter> to continue: ");
  //getchar();
#endif
  return;
} 

// Static member data of the (virtual) Parameters class has to be explicitly defined
struct Parameters::probabilitycache *Parameters::_currentwindowcache = NULL;
struct Parameters::Phylogeny *Parameters::_phy = NULL;

char Parameters::ReverseChar(char ch)
{
  switch(ch) {
  case 'A': return 'T';
  case 'C': return 'G';
  case 'G': return 'C';
  case 'T': return 'A';
  case 'R': return 'Y';
  case 'Y': return 'R';
  case 'S': return 'S';
  case 'W': return 'W';
  case 'N': return 'N';
  }
  return 'N';
}

WtMx *Parameters::TrainWtMx(Window *context)
{
  if (context==NULL) {
    printf("Error: TrainWtMx called on null window\n");
    exit(1);
  }

  int i;
  WtMx *bkgwm;

#ifndef _MARKOV
  float *bkg = new float[4];
  context->ComputeBaseFrequencies(bkg);

  float **bkgmat = new float *[4];
  for (i=0; i<4; i++) {
    bkgmat[i] = new float[1];
    bkgmat[i][0] = bkg[i];
  }

  bkgwm = new WtMx(bkgmat,1,"Background");  // create a length 1 wm for background 

  for (i=0; i<4; i++) 
    delete [] bkgmat[i];
  delete [] bkgmat;
  delete [] bkg;
#else
#ifndef MARKOV_ORDER
  int morder = 0;
#else 
  int morder = MARKOV_ORDER;
#endif
  // now train a Markov chain.
  int powmorder = (int)(pow(4.0,morder));
  float **bkg = new float *[powmorder];
  for (i=0; i<powmorder; i++) bkg[i] = new float[4];
  context->ComputeBaseFrequenciesWithHistory(bkg,morder);

  float ***bkgmat = new float **[powmorder];
  for (i=0; i<powmorder; i++) {
    bkgmat[i] = new float *[4];
    for (int j=0; j<4; j++) {
      bkgmat[i][j] = new float[1];
      bkgmat[i][j][0] = bkg[i][j];
    }
  }

  float *basicbkg = new float[4];
  context->ComputeBaseFrequencies(basicbkg);

  float **basicbkgmat = new float *[4];
  for (i=0; i<4; i++) {
    basicbkgmat[i] = new float[1];
    basicbkgmat[i][0] = basicbkg[i];
  }

  bkgwm = new WtMx(bkgmat,basicbkgmat,1,"Background",morder);

  for (i=0; i<powmorder; i++) {
    for (int j=0; j<4; j++) {
      delete [] bkgmat[i][j];
    }
    delete [] bkgmat[i];
    delete [] bkg[i];
  }
  delete [] bkgmat;
  delete [] bkg;
  for (i=0; i<4; i++) {
    delete [] basicbkgmat[i];
  }
  delete [] basicbkg;
  delete [] basicbkgmat;
#endif 
  
  return bkgwm;
}

void Parameters::TrainBackground(Window *context)
{
#ifdef _MULTIPLE_SEQUENCES_BACKGROUND 
  vector<Window *> *context_list = new vector<Window *>;
#endif

  bool context_was_null = false;
  if (global_background==NULL) {
#ifdef _MULTIPLE_SEQUENCES_BACKGROUND
    if (context==NULL) {
      context = (*_windows)[0]->Context(int(CONTEXT_WIDTH_FACTOR)*(*_windows)[0]->Length());
      context_list->push_back(context);
      for (int windex=1; windex < _windows->size(); windex++) 
	context_list->push_back((*_windows)[windex]);
      context_was_null = true;
    }
    if (_bkgwm) delete _bkgwm;
    _bkgwm = TrainWtMx(context_list);
#else 
    if (context==NULL) {
      context = (*_windows)[0]->Context(int(CONTEXT_WIDTH_FACTOR)*(*_windows)[0]->Length());
      context_was_null = true;
    }
    
    if (_bkgwm) delete _bkgwm;
    _bkgwm = TrainWtMx(context);
#endif      
  }
  else {
    if (_bkgwm) delete _bkgwm;
    _bkgwm = new WtMx(global_background);
  }

  // if this function created the context window, then delete it
  if (context_was_null) {
#ifdef _MULTIPLE_SEQUENCES_BACKGROUND
    delete context_list;
    delete context;
#else
    delete context;
#endif
  }

  // destroy the cache if present
  if (_currentwindowcache) delete [] _currentwindowcache;
  _currentwindowcache = NULL;

  // create an array of caches, one for each window 
  struct probabilitycache *currentpc = new struct probabilitycache[_windows->size()];
  for (int i=0; i<_windows->size(); i++) {
    (*_windows)[i]->SetIndex(i);
    struct probabilitycache *pc = CacheWindowBackgroundProbabilities((*_windows)[i],_bkgwm);
    currentpc[i] = *pc;
    delete pc;
  }
  _currentwindowcache = currentpc;
}

Parameters::Parameters()
{
  _windows = NULL;
  _wmc = NULL; _wm_len = NULL; 
  _is_trained = _is_initialized = false;
  _free_emission_probabilities = NULL;
  _free_transition_probabilities = true;
  _free_energy_differential = _free_energy = -1;
  _bkgwm = NULL;
  _numWM = 0;
  _initialbias = 10000;
  _num_iterations = 0;
  _numSpecies = 0;
  _revComp = false;
  _max_iterations = -1;
}

DTYPE  Parameters::ComputeSequenceProbability(Window *win, int start, int stop, WtMx *wm, bool both_orientations)
{
#ifndef _OPTIMIZE_CAREFULCSP
  if (start>stop) return 0;
  if (stop-start+1 > wm->Length()) {
#ifdef WARNINGS
    Warn("Warning: Sequence longer then motif length, cant compute probability\n");
#endif
    return 0;
  }
#endif

  int history_length = wm->MarkovOrder();
  int wm_len = wm->Length();

  // check the global cache kept in the sequence object
#ifdef _OPTIMIZE_PROTECTED_ACCESS
  Sequence *seq = win->_seq;
  int win_start = win->_start;
  struct probabilitycache *pc = (struct probabilitycache *)(seq->_udata);
#else
  Sequence *seq = win->Seq();
  int win_start = win->Start();
  struct probabilitycache *pc = (struct probabilitycache *)(seq->GetUserData());
#endif
  if (pc != NULL) {
    int index = -1;
#ifndef _OPTIMIZE_WMINDEX
    for (int i=0; i<pc->_numWM; i++) {
      if (pc->_wms[i]==wm) {
	index = i;
	break;
      }
    }
#else
#ifdef _OPTIMIZE_PROTECTED_ACCESS
    index = wm->_udata;
#else
    index = wm->GetUserData();
#endif
#endif
    // if found, fetch the prob from the cache
    if (index >= 0) {
      if (stop+win_start < pc->_start+pc->_length && stop-start+1==wm_len) {
	return pc->_prob[index][start+win_start-pc->_start];
      }
    }
  }
  
  // also check the current window cache kept locally
  if (_currentwindowcache != NULL) {
    int window_index = win->GetIndex();
    pc = &(_currentwindowcache[window_index]);
    if (pc->_associatedCurrentWindow==win) {
      int index = -1;
#ifndef _OPTIMIZE_WMINDEX
      for (int i=0; i<pc->_numWM; i++) {
	if (pc->_wms[i]==wm) {
	  index = i;
	  break;
	}
      }
#else
      // use the fact that if the background prob is cached, itll be in the first (and only) location in _wms
      if (pc->_wms[0] == wm) index = 0;
#endif
      // if found, fetch the prob from the cache
      // we dont substract pc->_start since this is the local window cache and has pc->_start implicitly zero.
      if (index >= 0) {
	if (stop < pc->_length && stop-start+1==wm_len) {
	  return pc->_prob[index][start];
	}
      }
    }
  }

  // if reached here, nothing found in cache
  int ss_len = stop-start+1;
  char *arrayofchar;
#ifdef BKG_FORWARD_ONLY 
  if (wm_len == 1) both_orientations = false;
#endif

  // first handle the simple case of no markov history
  // in the case of multiple sequences, do not allow wm to overlap an alignment boundary

  if (history_length == 0) {
    DTYPE  prob = 1;
    for (int i=0; i<ss_len; i++) {
      if (wm_len > 1) {
#ifndef _OVERLAPS
	if (i > 0 && win->AlignmentBeginsAt(start+i)) return 0;
	if (i<wm_len-1 && win->AlignmentEndsAt(start+i)) return 0;
#endif
      }
      char ch = win->IndexOfCharAt(start+i,arrayofchar);
      if (ch == -1) prob *= _phy->ComputeProbability(wm,i,false,arrayofchar);
      else prob *= wm->Frequency(i,ch);
    }
    
    if (!both_orientations) {
      return prob;
    }
    
    DTYPE  prob_rc = 1;
    for (int i=0; i<ss_len; i++) {
      char indch = win->IndexOfCharAt(start+i,arrayofchar);
      if (indch == -1) prob_rc *= _phy->ComputeProbability(wm,wm_len-1-i,true,arrayofchar);
      else {
	if (indch >= 0 && indch <= 3) {
	  prob_rc *= wm->Frequency(wm_len-1-i,3-indch);
	}
	else {
	  prob_rc *= wm->Frequency(wm_len-1-i,indch);
	}
      }
    }

    float fbias = wm->GetForwardBias();
    return fbias*prob+(1-fbias)*prob_rc;
    // return max(prob,prob_rc);
  }

  // else history required
  // first construct the initial history word
  // only allow 1 sequence (the reference sequence) ... this function cannot be used for multiple sequences
  // only allow unit-length matrix
  // Rationale: if history used, matrix must be unit-length; for that case you can use 
  // ComputeProbabilityGivenAncestor. The following piece of code is used when there is single species
  // and you want to compute background probabilities (in CacheWindowBackground...) 

  if (ss_len > 1) {
    printf("Error: ComputeSequenceProbability called with history and non-unit length matrix\n");
    exit(1);
  }
  int history[MAX_ALIGNED_SEQUENCES]; // this is an oversight. only history[this_seq_index] is used, no need of array.
  for (int i=0; i<MAX_ALIGNED_SEQUENCES; i++) history[i] = -1;
  int this_seq_index = seq->GetSpeciesIndex();
  int last_ambiguous_seen_at = -1;
  for (int i=0; i<history_length; i++) {    
    int hpos = start-history_length+i;
    if (hpos < 0) {
      history[this_seq_index] = -1;
      last_ambiguous_seen_at = hpos;
      break;
    }
    if (win->AmbiguousCharAt(hpos)) {
      history[this_seq_index] = -1; 
      last_ambiguous_seen_at = hpos;
      break;
    }
    char ch = win->IndexOfCharAt(hpos,arrayofchar);
    if (ch == -1) {
      printf("Error: ComputeSequenceProbability called for horder and multiple sequence\n");
      exit(1);
    }
    if (i==0) { // first iteration : initialize the history array if needed
      history[this_seq_index] = ch;
    }
    else {
      history[this_seq_index] = history[this_seq_index]*4+ch;;
    }
  }
    
  int mask = int(pow(4.0,history_length-1));
  DTYPE  prob = 1;
  DTYPE  prob_rc = 1;
  for (int i=0; i<ss_len; i++) {
    int start_plus_i = start+i;
    // retrieve the current character and multiply prob by its probability
    char ch = win->IndexOfCharAt(start_plus_i,arrayofchar);
    bool not_enough_history = (start_plus_i-last_ambiguous_seen_at <= history_length);
    if (not_enough_history) {
      prob *= wm->Frequency(i,ch);
    }
    else {
      prob *= wm->Frequency(i,ch,history[this_seq_index]);
    }
      
    if (both_orientations) {
      if (ch >= 0 && ch <= 3) {
	if (not_enough_history) 
	  prob_rc *= wm->Frequency(wm_len-1-i,3-ch);
	else 
	  prob_rc *= wm->Frequency(wm_len-1-i,3-ch,history[this_seq_index]);
      }
      else {
	if (not_enough_history) 
	  prob_rc *= wm->Frequency(wm_len-1-i,ch);
	else 	  
	  prob_rc *= wm->Frequency(wm_len-1-i,ch,history[this_seq_index]);
      }
    }
  }
  
  if (!both_orientations) {
    return prob;
  }
  else {
    float fbias = wm->GetForwardBias();
    return fbias*prob+(1-fbias)*prob_rc;
    // return max(prob,prob_rc);
  }
}

void Parameters::CacheBackgroundProbabilities()
{
  if (_currentwindowcache) {
    printf("Error: Request to cache background probabilities when cache exists\n");
    exit(1);
  }

  struct probabilitycache *currentpc = new struct probabilitycache[_windows->size()];
  for (int i=0; i<_windows->size(); i++) {
    struct probabilitycache *pc = CacheWindowBackgroundProbabilities((*_windows)[i],_bkgwm);
    currentpc[i] = *pc;
    delete pc;
  }
  _currentwindowcache = currentpc;
}


Parameters::probabilitycache *Parameters::CacheWindowBackgroundProbabilities(Window *win, WtMx *wm)
  // PRECONDITION: wm is the weight matrix for background
{
  int numWM = 1;
  WtMx **wms = new WtMx *[1];
  wms[0] = wm;
  if (wm==NULL) {
    printf("Error: Cant cache probabilities for null matrix\n");
    exit(1);
  }

  int length = win->Length();
  int morder = wm->MarkovOrder();
  int powmorder = 1;   // will be set later if required
  int mask;
  int this_seq_index;
  bool horderandms = (morder > 0 && _phy && _phy->_numSpecies > 0); // if this is true, we need to ...
                                                                    // use ancestor probs in computing prob
  
  int wm_len = wms[0]->Length();
  DTYPE  **aprob;
  int history[MAX_ALIGNED_SEQUENCES];

  if (horderandms) {
    if (wm_len != 1) {             // assume unit length
      printf("Error: Higher order wm with non-unit length not supported\n");
      exit(1);
    }

    aprob = new DTYPE  *[length];
    powmorder = int(pow(4.0,morder));
    mask = int(pow(4.0,morder-1));
    this_seq_index = win->Seq()->GetSpeciesIndex();
  }

  DTYPE  **prob = new DTYPE  *[1];
  prob[0] = new DTYPE  [length];

  int orientation = 0;  // this means background will be considered in forward orientation only
#if 0
  int orientation = 2;  // this is no longer supported.
#endif

  char *arrayofchar; char ch;
  if (horderandms) {
    for (int j=0; j<MAX_ALIGNED_SEQUENCES; j++) history[j] = -1;
  }
  int last_ambiguous_seen_at = -1;
  float pga[4];
  
  if (horderandms) {
    for (int l=0; l<length-wm_len+1; l++) {
      // Update aprob
      aprob[l] = new DTYPE [powmorder];     // assign aprob[l]
	
      if (l - last_ambiguous_seen_at <= morder) {  // use default values for aprob, dont look at sequence
	for (int a=0; a<powmorder; a++) {   // assign aprob[l][a] TODO: minor bug here, not looking at sequence
	  aprob[l][a] = wm->HigherOrderFrequency(0,a);
	}
      }
      else {
	for (int a=0; a<powmorder; a++) {   // assign aprob[l][a]
	  DTYPE  sum = 0;
	  int aprefix = a/4;
	  int asuffix = a%4;
	  for (int am1=0; am1<4; am1++) {   // sum over all a_{-1}
	    DTYPE  term = 1;
	    int ahis = aprefix + int(am1<<(2*(morder-1))); // ahis is the k-mer a_{-1}
	    term *= wm->Frequency(0,asuffix,ahis);
	    term *= pga[ahis%4];
	    term *= aprob[l-1][ahis]/prob[0][l-1];
	    sum += term;
	  }
	  aprob[l][a] = sum;
	}
      }
      
      // Update history 
      if (l>0) {
	if (ch == -1) {
	  char *ptr = arrayofchar;
	  char num_seq = *ptr++;
	  for (int j=0; j<num_seq; j++) {
	    char seq_index = *ptr++;
	    char ch_index = *ptr++;
	    if (win->AmbiguousChar(ch_index)) history[seq_index] = -1;
	    else {
	      if (history[seq_index]==-1) history[seq_index] = ch_index;
	      else history[seq_index] = (history[seq_index]%mask)*4 + ch_index;
	    }
	  }
	}
	else {
	  char *tmp; char ch2;
	  if (l>=2 && (ch2 = win->IndexOfCharAt(l-2,tmp))==-1) { // l-1 not aligned, l-2 aligned, i.e., algnmt ends.
	    for (int j=0; j<MAX_ALIGNED_SEQUENCES; j++) {
	      if (j==this_seq_index) continue;
	      history[j] = -1;
	    }
	  }
	  if (win->AmbiguousChar(ch)) history[this_seq_index] = -1;
	  else {
	    if (history[this_seq_index] == -1) history[this_seq_index] = ch;
	    else history[this_seq_index] = (history[this_seq_index]%mask)*4 + ch;
	  }
	}
      }
      
      // look at current column and update prob
      if (win->AmbiguousCharAt(l)) {
	last_ambiguous_seen_at = l;
      }

      ch = win->IndexOfCharAt(l,arrayofchar);	
      if (ch != -1) {
	arrayofchar = new char[3];
	arrayofchar[0] = 1; arrayofchar[1] = this_seq_index; arrayofchar[2] = ch;
      }
      
      float sum = 0;
      for (int al=0; al<4; al++) {
	if (l-last_ambiguous_seen_at <= morder) {
	  if (_phy->_type == FLATARRAY)
	    pga[al] = _phy->ComputeProbabilityGivenAncestor(wms[0],0,orientation,al,arrayofchar);
	  else 
	    pga[al] = _phy->ComputeProbabilityOfTreeGivenRoot(wms[0],0,orientation,al,arrayofchar, _phy->_tree->root);	  	  
	}
	else {
	  if (_phy->_type == FLATARRAY)
	    pga[al] = _phy->ComputeProbabilityGivenAncestor(wms[0],0,orientation,al,arrayofchar,history);
	  else 
	    pga[al] = _phy->ComputeProbabilityOfTreeGivenRoot(wms[0],0,orientation,al,arrayofchar, _phy->_tree->root, history);	  
	}	
	int powmorderm1 = mask; // pow(4,morder-1)
	float term = 0;
	for (int ap=0; ap<powmorderm1; ap++) {
	  term += aprob[l][ap*4+al];
	}	 
	sum += term*pga[al];
      }      
      if (ch != -1) delete [] arrayofchar;
      
      prob[0][l] = sum;
    }
    
    for (int l=0; l<length-wm_len+1; l++) {
      delete [] aprob[l];
    }
  }
  else {
    bool both_orientations = (orientation==0?false:true);
    for (int l=0; l<length-wm_len+1; l++) {
      prob[0][l] = Parameters::ComputeSequenceProbability(win, l, l+wm_len-1, wms[0], both_orientations);
    }
  }
  
  if (horderandms) delete [] aprob;

  struct probabilitycache *pc = new struct probabilitycache;
  pc->_numWM = numWM;
  pc->_wms = wms;
  pc->_length = length;
  pc->_prob = prob;
  pc->_associatedCurrentWindow = win;

  return pc;
}

void Parameters::CacheSubsequenceProbabilities(Sequence *seq, WtMxCollection *wmc, int start, int cache_length, bool lookAtAlignments)
{
  struct probabilitycache *oldpc = (struct probabilitycache *)(seq->GetUserData());
  if (oldpc != NULL) delete oldpc;
  seq->SetUserData(NULL);

  int numWM = wmc->Size();
  WtMx **wms = new WtMx *[numWM];
  for (int i=0; i<numWM; i++) {
    WtMx *wm = wmc->WM(i);
    wms[i] = wm;
#ifdef _OPTIMIZE_WMINDEX
    wm->SetUserData(i);
#endif
  }

  int length = cache_length;
  if (start+length-1 >= seq->Length()) length = seq->Length()-start;
  Window *win = new Window(seq,start,start+length-1);
  if (lookAtAlignments && seq->_alignments != NULL) {
    struct AlignmentNode *ndlist = seq->_alignments->GetAlignmentNodeList(seq,start,start+length-1);
    for (struct AlignmentNode *ptr = ndlist; ptr != NULL; ptr = ptr->_next) {
      Window *owin = new Window(ptr->_otherSeq, ptr->_l2, ptr->_r2);
      win->AlignWindow(owin,ptr->_l1);
      delete owin;
    }
  }

#ifdef _WTMX_BIAS
  float bkg[4]; win->ComputeBaseFrequencies(bkg);
  float **bkgmat = new float *[4];
  for (int i=0; i<4; i++) {
    bkgmat[i] = new float[1];
    bkgmat[i][0] = bkg[i];
  }
  WtMx *bkgwm = new WtMx(bkgmat,1,"full_background");
  for (int i=0; i<4; i++) delete [] bkgmat[i];
  delete [] bkgmat;

  int win_length = win->Length();
  for (int i=0; i<wmc->Size(); i++) {
    WtMx *w_tmp = wmc->WM(i);
    int wt_length = w_tmp->Length();

    float fcount = 0;
    float bcount = 0;
    for (int l=0; l<win_length-wt_length; l++) {
      w_tmp->SetForwardBias(1);
      float fprob = Parameters::ComputeSequenceProbability(win,l,l+wt_length-1,w_tmp,true);
      w_tmp->SetForwardBias(0);
      float bprob = Parameters::ComputeSequenceProbability(win,l,l+wt_length-1,w_tmp,true);

      float bkgprob = 1; 
      for (int l1=0; l1<wt_length; l1++) 
	bkgprob *= Parameters::ComputeSequenceProbability(win,l+l1,l+l1,bkgwm); 
      if (bkgprob > 0 && fprob > bkgprob) fcount++;
      if (bkgprob > 0 && bprob > bkgprob) bcount++;
    }

    // if (fcount + bcount < 10) wmc->WM(i)->SetForwardBias(0.5);
    wmc->WM(i)->SetForwardBias((fcount+1)/(fcount+bcount+2));
  }

  delete bkgwm;
#endif

  DTYPE  **prob = new DTYPE  *[numWM];
  for (int j=0; j<numWM; j++) {
    int wm_len = wms[j]->Length();
    prob[j] = new DTYPE  [length];
    for (int l=0; l<length-wm_len+1; l++) {
      prob[j][l] = Parameters::ComputeSequenceProbability(win, l, l+wm_len-1, wms[j], true);
    }
  }
  delete win;

  struct probabilitycache *pc = new struct probabilitycache;
  pc->_numWM = numWM;
  pc->_wms = wms;
  pc->_start = start;
  pc->_length = length;
  pc->_prob = prob;
  pc->_associatedCurrentWindow = NULL;  // this is the global sequence cache, not associated with any particular window

  seq->SetUserData((void *)pc);
}

void Parameters::DeleteCacheSubsequenceProbabilities(Sequence *seq)
{
  struct probabilitycache *pc = (struct probabilitycache *)(seq->GetUserData());
  if (pc == NULL) return;
  delete pc;
  seq->SetUserData(NULL);
}

DTYPE  Parameters::EvaluateFreeEnergyBackground(bool both_orientations)
{
  if (!_is_initialized) {
    printf("Error: EvaluateFreeEnergyBackground called without complete initialization\n");
    exit(1);
  }

  DTYPE  logP = 0;
  for (int wi=0; wi<_windows->size(); wi++) {
    Window *window = (*_windows)[wi];
    int start = window->Start();
    int length = window->Length();

    DTYPE  tmplogP = 0;
    for (int i=0; i<length; i++) {
      if (window->AmbiguousCharAt(i)) continue;
      DTYPE  prob = ComputeSequenceProbability(window,i,i,_bkgwm,both_orientations);
      tmplogP += log(prob);
    }
    logP += tmplogP;
  }
  return -logP;
}

float Parameters::Free_Energy_Differential()
{
  if (_is_trained) return _free_energy_differential;
#ifdef WARNINGS
  Warn("Warning: free energy differential computed on untrained parameters\n");
#endif
  return -1;
}

float Parameters::Free_Energy()
{
  if (_is_trained) return _free_energy;
#ifdef WARNINGS
  Warn("Warning: free energy computed on untrained parameters\n");
#endif
  return -1;
}

void Parameters::Scale_Free_Energy_Differential(float scalefactor)
{
  _free_energy_differential *= scalefactor;
}

int Parameters::InitialBias()
{
  return _initialbias;
}

int Parameters::NumIterations()
{
  return _num_iterations;
}

void Parameters::SetTrainingIterations(int numIter)
{
  _max_iterations = numIter;
}

bool Parameters::IsTrained() 
{
  return _is_trained;
}

bool Parameters::IsInitialized()
{
  return _is_initialized;
}

int Parameters::BackgroundIndex()
{
  if (!_is_initialized) {
    printf("Error: background index computed on uninitialized parameters\n");
    exit(1);
  }
  if (_wmc==NULL) return 0;
  return _numWM-1;
}

int Parameters::BackgroundIndex(WtMxCollection *wmc)
{
  return wmc->Size();
}

void Parameters::PrintBackground(FILE *fp)
{
  _bkgwm->Print(fp);
}

void Parameters::PrintWM(FILE *fp, int i)
{
  _wmc->WM(i)->Print(fp);
}

DTYPE Parameters::PID()
{
  int numSpecific=0;
  int numAligned=0;
  int numNonAligned=0;
  for (int i=0; i<1; i++) {
    Window *win = (*_windows)[i];
    for (int l=0; l<win->Length(); l++) {
      if (win->AmbiguousCharAt(l)) continue;
      numSpecific++;
      char *arrayofchar;
      if (win->IndexOfCharAt(l,arrayofchar) == -1) numAligned++;
      else numNonAligned++;
    }
  }
  if (numSpecific==0) return 0;
  return float(numAligned)/float(numSpecific);
}

void Parameters::PrintPID(FILE *fp)
{
  int totalLen = 0;
  for (int wi=0; wi<_windows->size(); wi++) {
    totalLen += (*_windows)[wi]->Length();
  }

  DTYPE pid = PID();
  fprintf(fp,"%d\t",(*_windows)[0]->Start());
#ifdef _PRINT_SEQNAME_IN_FENFILE
  char seqname[1024]; (*_windows)[0]->Seq()->Name(seqname);
  fprintf(fp,"%.6f\t%.6f\t%d\t%d\t%s\n",pid,pid,totalLen,_num_iterations,seqname);
#else
  fprintf(fp,"%.6f\t%.6f\t%d\t%d\n",pid,pid,totalLen,_num_iterations);
#endif
  
  return;
}

int Parameters::NumWM()
{
  return _numWM;
}

void Parameters::GetBackground(float *&bkg)
{
  if (_bkgwm==NULL) return;
  for (int i=0; i<4; i++) bkg[i] = _bkgwm->Frequency(0,i);
}

void Parameters::SetBackground(float *bkg)
{
  int i;
  if (_bkgwm) delete _bkgwm;

  float **bkgmat = new float *[4];
  for (i=0; i<4; i++) {
    bkgmat[i] = new float[1];
    bkgmat[i][0] = bkg[i];
  }
  _bkgwm = new WtMx(bkgmat,1,"Background");  // create a length 1 wm for background 
  for (i=0; i<4; i++) 
    delete [] bkgmat[i];
  delete [] bkgmat;

  // dont cache probabilities !! why ??
  if (_currentwindowcache) delete [] _currentwindowcache;
  _currentwindowcache = NULL;
}

void Parameters::GetBackground(WtMx *&bkg)
{
  bkg = _bkgwm;
}

void Parameters::SetBackground(WtMx *bkg)
{
  if (_bkgwm) delete _bkgwm;
  _bkgwm = bkg;

  if (_currentwindowcache) delete [] _currentwindowcache;
  _currentwindowcache = NULL;
}

void Parameters::SetPhylogeny(float *mu, int numSpecies)
{
  if (_phy != NULL) delete _phy;
  _phy = new Parameters::Phylogeny;
  _phy->_numSpecies = numSpecies; 
  _phy->_mu = new float[numSpecies];
  for (int i=0; i<numSpecies; i++) _phy->_mu[i] = mu[i];
  _phy->_tree = NULL;
  _phy->_type = FLATARRAY;
}

void Parameters::SetPhylogeny(Tree *tree, int numSpecies)
{
  if (_phy != NULL) delete _phy;
  _phy = new Parameters::Phylogeny;
  _phy->_numSpecies = numSpecies; 
  _phy->_tree = tree;
  _phy->_mu = NULL;
  _phy->_type = TREE;
}

const void *Parameters::GetPhylogeny(int &numSpecies, char type)
{
  if (_phy == NULL || _phy->_numSpecies < 1) {
    numSpecies = 0;
    return NULL;
  }
  numSpecies = _phy->_numSpecies;
  if (_phy->_type != type) {
    printf("Error in GetPhylogeny: types dont match\n");
    exit(1);
  }
  if (type == 0) 
    return _phy->_mu;
  else 
    return _phy->_tree;
}

char Parameters::GetPhylogenyType()
{
  if (_phy == NULL) { return -1; }
  return _phy->_type;
}

void Parameters::FreeEmissionProbabilities(int wmindex, int offset)
{
  if (offset >= 0) {
    _free_emission_probabilities[wmindex][offset] = true;
  }
  else {
    WtMx *w;
    if (wmindex == BackgroundIndex()) w = _bkgwm;
    else w = _wmc->WM(wmindex);
    for (int i=0; i<w->Length(); i++) {
      _free_emission_probabilities[wmindex][i] = true;
    }
  }
  return;
}

bool Parameters::IsEmissionProbabilityFree(int wmindex, int offset) 
{
  if (!_is_initialized) {
    printf("IsEmissionProbabilityFree called without complete initialization\n");
    exit(1);
  }
  if (offset >= 0) {
    return _free_emission_probabilities[wmindex][offset];
  }
  else {
    bool isfree = false;
    WtMx *w;
    if (wmindex == BackgroundIndex(_wmc)) w = _bkgwm;
    else w = _wmc->WM(wmindex);
    for (int i=0; i<w->Length(); i++) {
      if (_free_emission_probabilities[wmindex][i]) {
	isfree = true;
	break;
      }
    }
    return isfree;
  }
}

void Parameters::FixEmissionProbabilities(int wmindex, int offset)
{
  if (offset >= 0) {
    _free_emission_probabilities[wmindex][offset] = false;
  }
  else {
    WtMx *w;
    if (wmindex == BackgroundIndex()) w = _bkgwm;
    else w = _wmc->WM(wmindex);
    for (int i=0; i<w->Length(); i++) {
      _free_emission_probabilities[wmindex][i] = false;
    }
  }
  return;
}

void Parameters::FixTransitionProbabilities()
{
  _free_transition_probabilities = false;
}

bool Parameters::IsTransitionProbabilityFree()
{
  return _free_transition_probabilities;
}

void Parameters::SetNumSpecies(int sp)
{
  _numSpecies = sp;
}

void Parameters::SetRevComp()
{
  _revComp = true;
}
