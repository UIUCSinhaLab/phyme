/*****************************************************************
        Copyright by Rockefeller University,
can not be reproduced or distributed without written permission of
copyright holder.  

Written by Saurabh Sinha, Mathieu Blanchette, and Martin Tompa.

The PhyME program implements an algorithm to find
motifs in sets of orthologous sequences, as described in the
following paper:
"PhyME: A probabilistic algorithm for finding motifs in sets of 
orthologous sequences"
by Saurabh Sinha , Mathieu Blanchette  and Martin Tompa.
BMC Bioinformatics 2004, 5:170     doi:10.1186/1471-2105-5-170
Published 28 October 2004.

******************************************************************/
#include "sequence.h"
#include <string.h>
#include <stdio.h>
#include <ctype.h>

#define LAGAN_LINELEN 1024

Sequence **ReadLaganOutput(char *fastafile, char *anchsfile, int &numSequences, int numSpecies)
{
  char **sequences = new char *[numSpecies];
  int *seq_lengths = new int[numSpecies];
  char **seq_names = new char *[numSpecies];
  numSequences = 0;

  char line[LAGAN_LINELEN];
  char *sequence = NULL;
  int last_seq_len = 0;
  char name[LAGAN_LINELEN];

  // Read the sequences
  bool first_sequence_encountered = false;
  FILE *fp = fopen(fastafile,"r");
  if (fp == NULL) {
    printf("Error: file %s could not be opened\n",fastafile);
    exit(1);
  }
  while(fgets(line,LAGAN_LINELEN-1,fp)) {
    if (line[0]!='>' && !first_sequence_encountered) continue;
    if (line[0]=='>' && !first_sequence_encountered) first_sequence_encountered = true;

    // chomp
    int last_pos = strlen(line)-1;
    if (line[last_pos]=='\n' || line[last_pos]=='\r') line[last_pos] = 0;

    if (line[0]=='>') {
      if (sequence!=NULL) {
	sequences[numSequences] = new char[last_seq_len+1];
	strcpy(sequences[numSequences],sequence);
	seq_names[numSequences] = new char[strlen(name)+1];
	strcpy(seq_names[numSequences],name);
	seq_lengths[numSequences] = last_seq_len;
	delete [] sequence;

	numSequences++;
      }

      strcpy(name,line);
      sequence = new char[Sequence::MAX_SEQ_LENGTH+1];
      sequence[0] = 0;
      continue;
    }
      
    // concatenate
    strcat(sequence,line);
    last_seq_len = strlen(sequence);
  }
  fclose(fp);

  if (sequence) {
    sequences[numSequences] = new char[last_seq_len+1];
    strcpy(sequences[numSequences],sequence);
    seq_names[numSequences] = new char[strlen(name)+1];
    strcpy(seq_names[numSequences],name);
    seq_lengths[numSequences] = last_seq_len;
    delete [] sequence;
    sequence = NULL;
    numSequences++;
  }

  // Create the sequence objects
  Sequence **seqs = new Sequence *[numSequences];
  for (int i=0; i<numSequences; i++) {
    seqs[i] = new Sequence(sequences[i],seq_lengths[i],seq_names[i]);
    int speciesIndex;
    sscanf(seq_names[i],">SPECIES_%d",&speciesIndex);
    seqs[i]->SetSpeciesIndex(speciesIndex);
  }

  // Create the alignment objects
  FILE *afp = fopen(anchsfile,"r");
  if (afp == NULL) {
    printf("Error: file %s could not be opened\n",anchsfile);
    exit(1);
  }
  Alignment *alignments = new Alignment(numSpecies);
  int spc1 = 0; // reference species
  int spc2 = 0; // other species
  while (fgets(line,LAGAN_LINELEN-1,afp)) {
    if (line[0]=='>') {
      sscanf(line,">SPECIES_%d",&spc2);
      continue;
    }
    // find out the seqindex for spc2
    int seq2Index = -1;
    for (int i=0; i<numSequences; i++) {
      if (seqs[i]->GetSpeciesIndex() == spc2) {
	seq2Index = i;
	break;
      }
    }
    if (seq2Index < 0) {
      printf("Error: species index in blk file invalid\n");
      exit(1);
    }
    int l1,l2,r1,r2;
    if (sscanf(line,"(%d %d)=(%d %d)", &l1,&r1,&l2,&r2) < 4) break;
    l1--; l2--; r1--; r2--;
    if (r1-l1 != r2-l2) {
#ifdef WARNINGS
      Warn("Unequal length aligned block encountered and discarded\n");
#endif
      continue;
    }
    alignments->AddAlignmentNode(new AlignmentNode(seqs[spc1],l1,r1,seqs[seq2Index],l2,r2));
    alignments->AddAlignmentNode(new AlignmentNode(seqs[seq2Index],l2,r2,seqs[spc1],l1,r1));
  }

  for (int i=0; i<numSequences; i++) {
    delete [] seq_names[i];
    delete [] sequences[i];
  }
  delete [] seq_lengths;
  delete [] seq_names;
  delete [] sequences;

  seqs[0]->_alignments = alignments;
  return seqs;
}


