/*****************************************************************
        Copyright by Rockefeller University,
can not be reproduced or distributed without written permission of
copyright holder.  

Written by Saurabh Sinha, Mathieu Blanchette, and Martin Tompa.

The PhyME program implements an algorithm to find
motifs in sets of orthologous sequences, as described in the
following paper:
"PhyME: A probabilistic algorithm for finding motifs in sets of 
orthologous sequences"
by Saurabh Sinha , Mathieu Blanchette  and Martin Tompa.
BMC Bioinformatics 2004, 5:170     doi:10.1186/1471-2105-5-170
Published 28 October 2004.

******************************************************************/
#ifndef _STUBBUTIL_H_
#define _STUBBUTIL_H_

#define MIN_WINDOW_LENGTH 20
#define MIN_SPEC_FRACTION 0.5

#include "parameters.h"

struct Options {
  int numSpecies;
  int motifLen;
  int numSequences;
  char **sequencefiles;
  char **blocksfiles;
  char *output_dir;
  char *bkg_file;
  char *phylogeny_file;
  char *anchors_file;
  char *corr_file;
  int  *corr_list; int corr_list_size;
  float fen_threshold;
  float motif_occurrence_threshold;
  bool  revcompS;
  bool  revcompW;
  bool  revcompO;
  bool  trainmu;
  bool  refseqonly;
  bool  tree;
  int   numMotifs;
  int   numIter;
  int   numSites;
  int   maxSites;
  int   SeedTrainingIterations;
  char  seed[64];
  char  wtmxfile[1024];
  bool  shakeseed;

  Options() { numSpecies = 0; motifLen = 0; numSequences = 0; sequencefiles = NULL; blocksfiles = NULL; output_dir = NULL; bkg_file = NULL; phylogeny_file = NULL; anchors_file = NULL; corr_file = NULL; fen_threshold = 0; motif_occurrence_threshold = DEFAULT_MOTIF_OCCURRENCE_THRESHOLD; corr_list = NULL; corr_list_size = 0; revcompS = false; revcompW = false; revcompO = false; trainmu = false; refseqonly = false; tree = false; numMotifs = 1; numIter = 100; numSites = -1; SeedTrainingIterations = 25; seed[0] = 0; maxSites = -1; wtmxfile[0] = 0; shakeseed = false; }
  ~Options() { if (sequencefiles != NULL) delete [] sequencefiles; if (blocksfiles != NULL) delete [] blocksfiles; if (corr_list != NULL) delete [] corr_list; }
};

void PrintParameters(struct Options *opt);
struct Options *ReadOptionalArguments(int &argbase, int argc, char **argv);

void Warn(const char *str);
FILE *OpenProfile(char *suffix,char *output_dir = NULL);
FILE *OpenOutput(char *suffix,char *output_dir = NULL);
FILE *OpenDictionary(char *suffix,char *output_dir = NULL);
FILE *OpenAlignments(char *output_dir = NULL);
#endif
