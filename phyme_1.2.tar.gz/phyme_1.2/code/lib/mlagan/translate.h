
seq* transSeq(seq*, int);
char toPeptide (char* dnaword, char revcomp);
