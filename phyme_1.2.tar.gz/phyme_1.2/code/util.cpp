/*****************************************************************
        Copyright by Rockefeller University,
can not be reproduced or distributed without written permission of
copyright holder.  

Written by Saurabh Sinha, Mathieu Blanchette, and Martin Tompa.

The PhyME program implements an algorithm to find
motifs in sets of orthologous sequences, as described in the
following paper:
"PhyME: A probabilistic algorithm for finding motifs in sets of 
orthologous sequences"
by Saurabh Sinha , Mathieu Blanchette  and Martin Tompa.
BMC Bioinformatics 2004, 5:170     doi:10.1186/1471-2105-5-170
Published 28 October 2004.

******************************************************************/
#include "util.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "parameters.h"

void Warn(const char *str)
{
  FILE *fp = fopen("error_log","a");
  fprintf(fp,str);
  fclose(fp);
}

FILE *OpenProfile(char *suffix,char *output_dir)
{
  char filename[1024];
  if (output_dir != NULL) {
    sprintf(filename,"%s/profile_%s.txt",output_dir,suffix);
  }
  else {
    sprintf(filename,"profile_%s.txt",suffix);
  }
  FILE *prof = fopen(filename,"w");
  return prof;
}

FILE *OpenOutput(char *suffix,char *output_dir)
{
  char filename[1024];
  if (output_dir != NULL) {
    sprintf(filename,"%s/energy_%s.txt",output_dir,suffix);
  }
  else {
    sprintf(filename,"energy_%s.txt",suffix);
  }
  FILE *out = fopen(filename,"w");
  return out;
}

FILE *OpenDictionary(char *suffix,char *output_dir)
{
  char filename[1024];
  if (output_dir != NULL) {
    sprintf(filename,"%s/dictionary_%s.txt",output_dir,suffix);
  }
  else {
    sprintf(filename,"dictionary_%s.txt",suffix);
  }
  FILE *dict = fopen(filename,"w");
  return dict;
}

FILE *OpenAlignments(char *output_dir)
{
  char filename[1024];
  if (output_dir != NULL) {
    strcpy(filename, output_dir);
    strcat(filename, "/alignments.txt");
  }
  else {
    strcpy(filename,"alignments.txt");
  }
  FILE *algn = fopen(filename,"w");
  return algn;
}

void PrintParameters(struct Options *opt)
{
  char filename[1024];
  char *output_dir = opt->output_dir;
  if (output_dir != NULL) {
    strcpy(filename, output_dir);
    strcat(filename, "/parameters.txt");
  }
  else {
    strcpy(filename,"parameters.txt");
  }
  FILE *par = fopen(filename,"w");

  fprintf(par,"External Parameters\n\nMotif Length: %d\nSequencefiles:\n",opt->motifLen);
  for (int i=0; i<opt->numSequences; i++) {
    fprintf(par,"%s\t%s\n",opt->sequencefiles[i],opt->blocksfiles[i]);
  }
  fprintf(par,"\nbackground file: %s\n",opt->bkg_file);
  fprintf(par,"\nnmotifs %d\tnsites %d\tniter %d\n",opt->numMotifs, opt->numSites, opt->numIter);
  if (opt->SeedTrainingIterations > 0) {
    fprintf(par, "\nnseediter %d\n",opt->SeedTrainingIterations);
  }
  if (opt->seed[0] != 0) {
    fprintf(par, "\nseed = %s\n",opt->seed);
  }
  if (opt->maxSites >= 0) {
    fprintf(par, "\nmaxsites %d\n",opt->maxSites);
  }

  fprintf(par,"\nInternal Parameters\n\nMARKOV_ORDER: %d (%d+1)-mers are counted\nCONTEXT_SIZE: %.2f\nBKG_FORWARD_ONLY: %d\nALMOST_ONE: %.2f\nParameters_H0 convergence threshold: %f\n",MARKOV_ORDER, MARKOV_ORDER, Parameters::GetContextWidthFactor(), Parameters::GetBackgroundOrientation(), Parameters::GetAlmostOne(), Parameters_H0::GetThreshold());
#ifdef _MARKOV
  fprintf(par,"Markov used\n");
#endif
#ifdef _MULTIPLE_SEQUENCES
  fprintf(par,"Multiple Sequences considered\n");
  fprintf(par,"Phylogeny file: %s\n",opt->phylogeny_file);
  int phy_type = Parameters::GetPhylogenyType();
  int numSpecies;
  if (phy_type == FLATARRAY) {
    const float *mu = (const float *)Parameters::GetPhylogeny(numSpecies);
    fprintf(par,"mutation rates (mu): ");
    for (int i=0; i<opt->numSpecies; i++) fprintf(par,"%.2f ",mu[i]);
    fprintf(par,"\n");
  }
  else {
    const Tree *mu = (const Tree *)Parameters::GetPhylogeny(numSpecies,TREE);
    mu->Print(par);    
  }
#endif
  fclose(par);
}

struct Options *ReadOptionalArguments(int &argbase, int argc, char **argv)
{
  struct Options *opt = new struct Options;
  while (argbase < argc && argv[argbase][0]=='-') {
    if (strstr(argv[argbase],"-cons")) {
      strcpy(opt->seed,argv[++argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-nseediter")) {
      opt->SeedTrainingIterations = atoi(argv[++argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-maxsites")) {
      opt->maxSites = atoi(argv[++argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-nsites")) {
      opt->numSites = atoi(argv[++argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-nmotifs")) {
      opt->numMotifs = atoi(argv[++argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-niter")) {
      opt->numIter = atoi(argv[++argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-revcompW")) {
      opt->revcompW = true;
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-revcompO")) {
      opt->revcompO = true;
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-trainmu")) {
      opt->trainmu = true;
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-refseqonly")) {
      opt->refseqonly = true;
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-tree")) {
      opt->tree = true;
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-shakeseed")) {
      opt->shakeseed = true;
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-K")) {
      opt->numSpecies = atoi(argv[++argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-w")) {
      opt->motifLen = atoi(argv[++argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-Wtmx")) {
      strcpy(opt->wtmxfile,argv[++argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-N")) {
      opt->numSequences = atoi(argv[++argbase]);
      argbase++;
      opt->sequencefiles = new char *[opt->numSequences];
      opt->blocksfiles = new char *[opt->numSequences];
      for (int i=0; i< opt->numSequences; i++) {
	opt->sequencefiles[i] = argv[argbase++];
	opt->blocksfiles[i] = argv[argbase++];
      }
      continue;
    }
    if (strstr(argv[argbase],"-od")) {
      opt->output_dir = argv[++argbase];
      argbase++;
      continue;
    }    
    if (strstr(argv[argbase],"-b")) {
      opt->bkg_file = argv[++argbase];
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-ft")) {
      opt->fen_threshold = atof(argv[++argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-ot")) {
      opt->motif_occurrence_threshold = atof(argv[++argbase]);
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-pf")) {
      opt->phylogeny_file = argv[++argbase];
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-af")) {
      opt->anchors_file = argv[++argbase];
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-cf")) {
      opt->corr_file = argv[++argbase];
      argbase++;
      continue;
    }
    if (strstr(argv[argbase],"-cl")) {
      int numpairs = atoi(argv[++argbase]);
      if (numpairs < 1) {
	printf("Error: correlation list size must be positive\n");
	exit(1);
      }
      opt->corr_list_size = numpairs;
      opt->corr_list = new int[2*numpairs];
      int j = 0;
      for (int i=0; i<numpairs; i++) {
	opt->corr_list[j++] = atoi(argv[++argbase]);
	opt->corr_list[j++] = atoi(argv[++argbase]);
      }
      argbase++;
      continue;
    }
  }

  return opt;
}
