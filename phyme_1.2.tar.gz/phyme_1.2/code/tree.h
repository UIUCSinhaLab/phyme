/*****************************************************************
        Copyright by Rockefeller University,
can not be reproduced or distributed without written permission of
copyright holder.  

Written by Saurabh Sinha, Mathieu Blanchette, and Martin Tompa.

The PhyME program implements an algorithm to find
motifs in sets of orthologous sequences, as described in the
following paper:
"PhyME: A probabilistic algorithm for finding motifs in sets of 
orthologous sequences"
by Saurabh Sinha , Mathieu Blanchette  and Martin Tompa.
BMC Bioinformatics 2004, 5:170     doi:10.1186/1471-2105-5-170
Published 28 October 2004.

******************************************************************/
#ifndef _TREE_H_
#define _TREE_H_

#include <list.h>
#include <ctype.h>
#include "typedefs.h"
#include "sequence.h"

struct NodeInfo {
  char base;
  int index;
  bool valid;
  DDTYPE TGP[4];
  DDTYPE freq[4];
  DDTYPE f[4];
  DDTYPE f_b[4][4];
  DDTYPE f_b_g[4][4][4];
  DDTYPE LCache1[4]; // [alphaprime] is \prod_c f(\psi_c,alphaprime)
  DDTYPE LCache2[4][MAX_ALIGNED_SEQUENCES]; // [alphaprime][x] is (\prod_{c != x} f(\psi_c,alphaprime))
  DDTYPE LCache3[4][4]; // [alphaprime][beta] is \sum_x (\prod_{c != x} f(\psi_c,alphaprime))*f_beta(\psi_x,alphaprime)
  NodeInfo() {
    base = -1; 
    index = -1;
    valid = true;    
  }
  void Print();
};

#include <hash_map.h>
using namespace std;
struct equalInt {
  bool operator()(int l, int r) const
  {
    return l==r;
  }
};
struct CachedArrays {
  DDTYPE f[4];
  DDTYPE f_b[4][4];
  DDTYPE LCache1[4]; // [alphaprime] is \prod_c f(\psi_c,alphaprime)
  DDTYPE LCache2[4][MAX_ALIGNED_SEQUENCES]; // [alphaprime][x] is (\prod_{c != x} f(\psi_c,alphaprime))
  DDTYPE LCache3[4][4]; // [alphaprime][beta] is \sum_x (\prod_{c != x} f(\psi_c,alphaprime))*f_beta(\psi_x,alphaprime)
};  
typedef hash_map<int,struct CachedArrays,hash<int>,equalInt> cache_type;

struct Tree {
  struct Node {
    char name[1024];
    int spc_index;
    float mu;
    NodeInfo *nodeInfo;
    list<struct Node *> children;
    bool no_children;
    struct Node **children_array;
    int numChildren;
    cache_type cache;
    
    Node() { name[0] = 0; spc_index = -1 ; mu = 0; nodeInfo = NULL; children_array = NULL; numChildren = 0; no_children = true; }
    void Print(FILE *fp) const;
    void AssignSpeciesIndices();
    void CacheNodeInfo(int index,int rev_orientation,int beta);
    void LoadNodeInfo(int index,bool rev_orientation,int beta,int gamma);
  };

  Node *root;
  void ReadTree(FILE *fp);
  void Print(FILE *fp) const;

  private:
  int lineid;
  Node *ReadTreeHelper(FILE *fp, int depth);
  void get_comment(FILE *fp);
  
};

#endif
