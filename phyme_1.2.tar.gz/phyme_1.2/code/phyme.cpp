/*****************************************************************
        Copyright by Rockefeller University,
can not be reproduced or distributed without written permission of
copyright holder.  

Written by Saurabh Sinha, Mathieu Blanchette, and Martin Tompa.

The PhyME program implements an algorithm to find
motifs in sets of orthologous sequences, as described in the
following paper:
"PhyME: A probabilistic algorithm for finding motifs in sets of 
orthologous sequences"
by Saurabh Sinha , Mathieu Blanchette  and Martin Tompa.
BMC Bioinformatics 2004, 5:170     doi:10.1186/1471-2105-5-170
Published 28 October 2004.

******************************************************************/
#include <stdio.h>
#include <assert.h>
#include <math.h>

#include "util.h"
#include "sequence.h"
#include "parameters.h"
#include "fastafile.h"

int globalid;
WtMx * global_background;

extern Sequence **ReadLaganOutput(char *fastaname, char *anchname, int &numSequences, int numSpecies);
#define PHYLOGENY_FILE "phylogeny.txt"

main(int argc, char **argv)
{
  if (argc < 5) {
    printf("usage: %s -K <numSpecies> -N <numSequences> <seqfile1> <blkfile1> ... <seqfile_N> <blkfile_N> -w <wtmx length> -pf <phylogeny file>  [-tree] [-od <output_dir>] [-b <background file>] [-revcompW] [-nmotifs <numberofmotifs>] [-ot <motif_occurrence_threshold>] [-nsites <num_expected_sites_of_each_motif>] [-maxsites <max_number_of_expected_sites>] [-niter <num_iterations_of_EM_per_motif>] [-nseediter <num_iterations_to_find_best_seed>] [-trainmu] [-refseqonly] [-shakeseed]\n",argv[0]);
    exit(1);
  }
  globalid = 0;
  global_background = NULL;

  // Read in the arguments
  int argbase = 1;
  struct Options *opt = ReadOptionalArguments(argbase, argc, argv);

  if (opt->numSpecies < 2) {
    printf("Error: this program currently supports >= 2 species\n");
    exit(1);
  }
  if (opt->numSequences < 1) {
    printf("Error: must input at least one sequence file with its block file\n");
    exit(1);
  }

  // Set the global background if needed
  if (opt->bkg_file != NULL) {
    Sequence *bkg_seq = new Sequence(opt->bkg_file);
    Window *bkg_window = new Window(bkg_seq,0,bkg_seq->Length()-1);
    global_background = Parameters::TrainWtMx(bkg_window);
    delete bkg_window;
    delete bkg_seq;
  }

  // Read in the sequences and lagan blocks
  Sequence ***seqs;
  int *numSequencesReadArray;
  seqs = new Sequence **[opt->numSequences];
  numSequencesReadArray = new int[opt->numSequences];

  for (int i=0; i<opt->numSequences; i++) {
    int numSequencesRead;
    seqs[i] = ReadLaganOutput(opt->sequencefiles[i], opt->blocksfiles[i], numSequencesRead, opt->numSpecies);
    if (numSequencesRead < 1) {
      printf("Error: Read of Lagan output gives less than one sequence\n");
      exit(1);
    }
    // seqs[i][0] should point to the reference sequence
    if (seqs[i][0]->GetSpeciesIndex() != 0) {
      printf("Error: Read of Lagan output gives first species as non-reference\n");
      exit(1);
    }
    numSequencesReadArray[i] = numSequencesRead;
  }

  // Enter the phylogeny information into the system
  if (!opt->tree) {
    float *mu = new float[opt->numSpecies]; 
    FILE *fpp = fopen(opt->phylogeny_file,"r");
    for (int i=0; i<opt->numSpecies; i++) {
      float mut;
      if (fscanf(fpp,"%f ",&mut) < 1) {
	printf("Error reading phylogeny file\n");
	exit(1);
      }
      mu[i] = mut;
    }
    if (mu[0] != 0) { 
      printf("Error: in the current version, the reference species (species 0) must be the ancestor (mu = 0)\n");
      exit(1);
    }
    fclose(fpp);
    Parameters::SetPhylogeny(mu,opt->numSpecies);
    delete [] mu;
  }
  else { // read a newick tree    
    Tree *tree = new Tree;
    FILE *fpp = fopen(opt->phylogeny_file,"r");
    tree->ReadTree(fpp);
    fclose(fpp);
    tree->root->AssignSpeciesIndices();
    Parameters::SetPhylogeny(tree,opt->numSpecies);    
  }

  // Prepare for various printing
  FILE *algn = OpenAlignments(opt->output_dir);

  // print alignments and create windows
  vector<Window *> *wl = new vector<Window *>;
  for (int i=0; i<opt->numSequences; i++) {
    fprintf(algn,"Sequence %d\n",i);
    seqs[i][0]->_alignments->Print(algn);
    fprintf(algn,"\n\n");

    MSWindowIteratorFixedShift wi(seqs[i],numSequencesReadArray[i],opt->refseqonly);
    int refLength = seqs[i][0]->Length();
    if (!wi.Begin(refLength,1)) {
      printf("Error: MSWindowIterator Begin failed\n");
      exit(1);
    }
    vector<Window *> *wli = new vector<Window *>;
    wi.CurrentWindowList(wli, opt->motifLen+1);
    
    // add all windows in wli to another vector wl
    for (int i=0; i<wli->size(); i++) {
      wl->push_back((*wli)[i]);
    }  
    delete wli;
  }

#if 0
  printf("%d separate windows seen\n",wl->size());
  for (int i=0; i<wl->size(); i++) {
    Window *win = (*wl)[i];
    win->Print(true);
  }
#endif

  // set the phylogeny values if needed
  if (opt->trainmu) {
    if (!opt->tree) {
      float *mu = new float[opt->numSpecies];
      int numSpecies;
      const float *old_mu =  (const float *)Parameters::GetPhylogeny(numSpecies);
      mu[0] = old_mu[0];
      for (int i=1; i<opt->numSpecies; i++) {
	mu[i] = old_mu[i];
	int mismatch = 0;
	int total = 0;
	for (int j=0; j<opt->numSequences; j++) {
	  for (int k=0; k<numSequencesReadArray[j]; k++) {
	    if (seqs[j][k]->GetSpeciesIndex()!=i) continue;
	    int mis=0, tot=0;
	    seqs[j][0]->_alignments->MutationRateInAlignments(seqs[j][0],seqs[j][k],mis,tot);
	    mismatch += mis;
	    total += tot;
	  }
	}
	if (total == 0) continue;
	mu[i] = float(mismatch)/float(total);
      }
      Parameters::SetPhylogeny(mu,opt->numSpecies);
      delete [] mu;
    }
    else {
      printf("Error: trainmu option not supported for tree phylogenies\n");
      exit(1);
    }
  }
      
  PrintParameters(opt);

  int w = opt->motifLen;
  int totalLen = 0;
  for (int i=0; i<wl->size(); i++) {
    Window *win = (*wl)[i];
    totalLen += win->Length();
  }

  // now find n motifs.

  for (int nmotif = 0; nmotif < opt->numMotifs; nmotif++) {
    char *bestseed = new char[w+1];
    DTYPE bestscore = -1;
    int bestseedpos = -1;
    int bestseedseq = -1;
    if (opt->seed[0] != 0) {
      strcpy(bestseed, opt->seed);
    }
    else {      
      for (int niter = 0; niter < opt->numIter; niter++) {
	char *seed = new char[w+1];
	bool foundseed = false;
	int triedfindingseed = 0;
	int i,l;
	while (!foundseed && triedfindingseed < 1000) {
	  triedfindingseed++;
	  i = rand()%(opt->numSequences);
	  Sequence *seq = seqs[i][0];
	  if (seq->Length() < w) {
	    continue;
	  }
	  l = rand()%(seq->Length()-w+1);
	  if (!seq->IsAligned(l,l+w-1)) {
	    continue;
	  }
	  bool badseed = false;
	  for (int m=0; m<w; m++) {
	    seed[m] = seq->CharAt(l+m);
	    if (seed[m]=='N') {
	      badseed = true;
	      break;
	    }
	  }
	  if (badseed) {
	    continue;
	  }
	  seed[w] = 0;     
	  fprintf(stderr,"Motif %d Iteration %d: Seeding from %s (sequence %d position %d)\n",nmotif,niter,seed,i,l);
	  foundseed = true;
	}
	if (!foundseed) {
	  fprintf(stderr,"Warning: Couldnt find seed on iteration %d\n",niter);
	  continue;
	}
	// found seed, work with it
	WtMx *wm = new WtMx(seed);
	WtMxCollection wmc;
	wmc.Add(wm);
	// if revcompW, also add reverse
	if (opt->revcompW) {
	  WtMx *wmrc = new WtMx(wm, true); 
	  wmc.Add(wmrc);
	}
	// train
	Parameters_H0 *param0 = new Parameters_H0;
	param0->SetNumSpecies(opt->numSpecies);
	int bkgIndex = param0->BackgroundIndex(&wmc);
	param0->Initialize(wl,&wmc,bkgIndex);
	param0->FreeEmissionProbabilities(0);  // the 0 stands for wmindex of wm
	if (opt->revcompW) {
	  param0->SetRevComp(); // let param0 know that it has a revcomp matrix 
	}
	if (opt->numSites > 0) {
	  DTYPE motifprob = DTYPE(opt->numSites)/DTYPE(totalLen);
	  if (motifprob >= 1) {
	    printf("Error: -nsites too high. Try reducing this parameter.\n");
	    exit(1);
	  }
	  if (!opt->revcompW) {
	    DTYPE prob[2]; prob[0] = motifprob; prob[1] = 1-prob[0];
	    param0->SetParameters(prob);
	    param0->FixTransitionProbabilities();
	  }
	  else {
	    DTYPE prob[3]; prob[0] = prob[1] = motifprob/2; prob[2] = 1-prob[0]-prob[1];
	    param0->SetParameters(prob);
	    param0->FixTransitionProbabilities();
	  }
	}
	if (opt->maxSites > 0) {
	  param0->SetMaxSites(opt->maxSites);
	  DTYPE motifprob = DTYPE(opt->maxSites)/DTYPE(totalLen);
	  if (motifprob >= 1) {
	    printf("Error: -maxsites too high. Try reducing this parameter.\n");
	    exit(1);
	  }
	  if (!opt->revcompW) {
	    DTYPE prob[2]; prob[0] = motifprob; prob[1] = 1-prob[0];
	    param0->SetParameters(prob);
	  }
	  else {
	    DTYPE prob[3]; prob[0] = prob[1] = motifprob/2; prob[2] = 1-prob[0]-prob[1];
	    param0->SetParameters(prob);
	  }
	}
	if (opt->SeedTrainingIterations > 0) 
	  param0->SetTrainingIterations(opt->SeedTrainingIterations);
	param0->Train();   
	DTYPE score = param0->Free_Energy_Differential();
	if (score > bestscore) {
	  bestscore = score;
	  strcpy(bestseed,seed);
	  bestseedseq = i;
	  bestseedpos = l;
	  fprintf(stderr,"Found better seed %s with score %.2f\n",bestseed, bestscore);
	  wm->Print(stderr);
	  fprintf(stderr,"Consensus: "); wm->PrintConsensus(stderr);
	}
	else {
	  fprintf(stderr,"Seed %s scored %.2f ... Trained to\n",seed,score);
	  wm->Print(stderr);
	  fprintf(stderr,"Consensus: "); wm->PrintConsensus(stderr);
	}
	delete param0;
	delete [] seed;
      }
    }
    
    // shake the best seed, i.e., try various shifted versions. 
    if (opt->shakeseed && bestseedpos >= 0) {
      int bestseedrangel = bestseedpos;
      int bestseedrangeh = bestseedpos;
      bestseedrangel -= w/2;
      bestseedrangeh += w/2;
      for (int b=bestseedrangel; b<=bestseedrangeh; b++) {
	char *shakenseed = new char[w+1];
	Sequence *seq = seqs[bestseedseq][0];
	if (b < 0 || b >= (seq->Length()-w+1)) continue;	    
	if (b == bestseedpos) continue;
	bool badseed = false;
	for (int m=0; m<w; m++) {
	  shakenseed[m] = seq->CharAt(b+m);
	  if (shakenseed[m]=='N') {
	    badseed = true;
	    break;
	  }
	}
	if (badseed) {
	  continue;
	}
	shakenseed[w] = 0;     

	// try this shaken seed to see if it scores better than the best seed.
	// totally repititive code (from above) -- use a function

	WtMx *wm = new WtMx(shakenseed);
	WtMxCollection wmc;
	wmc.Add(wm);
	
	// if revcompW, also add reverse
	if (opt->revcompW) {
	  WtMx *wmrc = new WtMx(wm, true); 
	  wmc.Add(wmrc);
	}
	// train
	Parameters_H0 *param0 = new Parameters_H0;
	param0->SetNumSpecies(opt->numSpecies);
	int bkgIndex = param0->BackgroundIndex(&wmc);
	param0->Initialize(wl,&wmc,bkgIndex);
	param0->FreeEmissionProbabilities(0);  // the 0 stands for wmindex of wm
	if (opt->revcompW) {
	  param0->SetRevComp(); // let param0 know that it has a revcomp matrix 
	}
	if (opt->numSites > 0) {
	  DTYPE motifprob = DTYPE(opt->numSites)/DTYPE(totalLen);
	  if (!opt->revcompW) {
	    DTYPE prob[2]; prob[0] = motifprob; prob[1] = 1-prob[0];
	    param0->SetParameters(prob);
	    param0->FixTransitionProbabilities();
	  }
	  else {
	    DTYPE prob[3]; prob[0] = prob[1] = motifprob/2; prob[2] = 1-prob[0]-prob[1];
	    param0->SetParameters(prob);
	    param0->FixTransitionProbabilities();
	  }
	}
	if (opt->maxSites > 0) {
	  param0->SetMaxSites(opt->maxSites);
	  DTYPE motifprob = DTYPE(opt->maxSites)/DTYPE(totalLen);
	  if (!opt->revcompW) {
	    DTYPE prob[2]; prob[0] = motifprob; prob[1] = 1-prob[0];
	    param0->SetParameters(prob);
	  }
	  else {
	    DTYPE prob[3]; prob[0] = prob[1] = motifprob/2; prob[2] = 1-prob[0]-prob[1];
	    param0->SetParameters(prob);
	  }
	}
	if (opt->SeedTrainingIterations > 0) 
	  param0->SetTrainingIterations(opt->SeedTrainingIterations);
	param0->Train();   
	DTYPE score = param0->Free_Energy_Differential();
	if (score > bestscore) {
	  bestscore = score;
	  strcpy(bestseed,shakenseed);
	  fprintf(stderr,"Found better seed %s with score %.2f\n",bestseed, bestscore);
	  wm->Print(stderr);
	  fprintf(stderr,"Consensus: "); wm->PrintConsensus(stderr);
	}
	else {
	  fprintf(stderr,"Seed %s scored %.2f ... Trained to\n",shakenseed,score);
	  wm->Print(stderr);
	  fprintf(stderr,"Consensus: "); wm->PrintConsensus(stderr);
	}
	delete param0;
	delete [] shakenseed;
      }
    }
    
    WtMx *bestwm = new WtMx(bestseed); 
    char wname[1024];
    sprintf(wname,"MOTIF_%d",nmotif+1);
    bestwm->SetName(wname);
    WtMxCollection wmc;
    wmc.Add(bestwm);
    // if revcompW, also add reverse
    if (opt->revcompW) {
      WtMx *bestwmrc = new WtMx(bestwm, true); 
      bestwmrc->SetName(wname);
      wmc.Add(bestwmrc);
    }
    Parameters_H0 *param0 = new Parameters_H0;
    param0->SetNumSpecies(opt->numSpecies);
    int bkgIndex = param0->BackgroundIndex(&wmc);
    param0->Initialize(wl,&wmc,bkgIndex);
    param0->FreeEmissionProbabilities(0);  // the 0 stands for wmindex of wm
    if (opt->revcompW) {
      param0->SetRevComp(); // let param0 know that it has a revcomp matrix too
    }
    if (opt->numSites > 0) {
      DTYPE motifprob = DTYPE(opt->numSites)/DTYPE(totalLen);
      if (!opt->revcompW) {
	DTYPE prob[2]; prob[0] = motifprob; prob[1] = 1-prob[0];
	param0->SetParameters(prob);
	param0->FixTransitionProbabilities();
     }
      else {
	DTYPE prob[3]; prob[0] = prob[1] = motifprob/2; prob[2] = 1-prob[0]-prob[1];
	param0->SetParameters(prob);
	param0->FixTransitionProbabilities();
      }
    }
    if (opt->maxSites > 0) {
      param0->SetMaxSites(opt->maxSites);
      DTYPE motifprob = DTYPE(opt->maxSites)/DTYPE(totalLen);
      if (!opt->revcompW) {
	DTYPE prob[2]; prob[0] = motifprob; prob[1] = 1-prob[0];
	param0->SetParameters(prob);
      }
      else {
	DTYPE prob[3]; prob[0] = prob[1] = motifprob/2; prob[2] = 1-prob[0]-prob[1];
	param0->SetParameters(prob);
      }
    }
    param0->Train();   
    DTYPE score = param0->Free_Energy_Differential();

    // print stuff
    char suffix[10]; sprintf(suffix,"%d",nmotif+1);
    FILE *prof = OpenProfile(suffix,opt->output_dir);
    FILE *dict = OpenDictionary(suffix,opt->output_dir);
    FILE *ener = OpenOutput (suffix,opt->output_dir);
    param0->Print(ener);
    param0->PrintProfile(prof,dict,opt->motif_occurrence_threshold);    
    fclose(ener);
    fclose(dict);
    fclose(prof);
#ifndef _PRINTTRAINING
    printf("#*******************************\n");
    DTYPE re_score = bestwm->ComputeRE();
    printf("#Motif %d: Score %.2f\t%.2f\n",nmotif+1,re_score,score);
    bestwm->Print();
    printf("#Consensus: "); bestwm->PrintConsensus();
    printf("#Sites above threshold %.2f\n",opt->motif_occurrence_threshold);
    if (!opt->revcompW && opt->revcompO) bestwm->SetForwardBias(0.5);
    param0->PrintOccurrences(stdout, 0, opt->motif_occurrence_threshold);
    printf("#*******************************\n");
#endif
    
    // mask this motif and clean up
    param0->MaskOccurrences(0, MASK_THRESHOLD); // opt->motif_occurrence_threshold);
    delete param0;
    delete [] bestseed;
  }
  
  // clean up
  for (int windex=0; windex<wl->size(); windex++) {
    Window *win =  (*wl)[windex];
    delete win;
  }
  delete wl;

  for (int i=0; i<opt->numSequences; i++) {
    for (int j=0; j<numSequencesReadArray[i]; j++) {
      delete seqs[i][j];
    }
    delete [] seqs[i];
  }
  delete [] seqs;
  
  fclose(algn);
  delete opt;
}

