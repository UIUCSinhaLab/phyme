/*****************************************************************
        Copyright by Rockefeller University,
can not be reproduced or distributed without written permission of
copyright holder.  

Written by Saurabh Sinha, Mathieu Blanchette, and Martin Tompa.

The PhyME program implements an algorithm to find
motifs in sets of orthologous sequences, as described in the
following paper:
"PhyME: A probabilistic algorithm for finding motifs in sets of 
orthologous sequences"
by Saurabh Sinha , Mathieu Blanchette  and Martin Tompa.
BMC Bioinformatics 2004, 5:170     doi:10.1186/1471-2105-5-170
Published 28 October 2004.

******************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fastafile.h"

FastaFile::FastaFile()
{
  for (int i=0; i<MAX_NUM_SEQUENCES; i++)
    _sequences[i] = NULL;
  _numSequences = 0;
}

void FastaFile::ReadFasta(char *filename)
{
  FILE *fp = fopen(filename,"r");
  if (fp == NULL) {
    printf("Error reading file %s\n",filename);
    exit(1);
  }

  int numSequences = -1; int ptr;
  char *sequence = new char[Sequence::MAX_SEQ_LENGTH+1];
  char name[1024];
  char prevname[1024];

  int ch = 0;
  while ((ch = fgetc(fp)) != EOF){
    if (ch == '>') {	
				// skip to end of line and copy as name
      int nptr = 0;
      while ((ch = fgetc(fp)) != EOF && ch != '\n' && ch != '\r') name[nptr++] = ch;
      if (ch == EOF) break;
      name[nptr] = 0; 
				// get ready for a new region
      if (numSequences > -1) {  // already seen a sequence ...
	sequence[ptr] = 0;
	_sequences[numSequences++] = new Sequence(sequence,ptr,prevname);
	ptr = 0;
      }
      else {                    // this is the first sequence
	numSequences = 0;
	ptr = 0;
      }
      strcpy(prevname,name);
    }
    if (ch != '\n' && ch != '\r') {
      if (ptr==Sequence::MAX_SEQ_LENGTH) continue;
      sequence[ptr++] = ch;
    }
  }

  if (numSequences > -1) {
    sequence[ptr] = 0;
    _sequences[numSequences++] = new Sequence(sequence,ptr,name);
  }

  _numSequences = numSequences;

  fclose(fp);
  delete [] sequence;
}

FastaFile::~FastaFile()
{
  for (int i=0; i<_numSequences; i++) delete _sequences[i];
}

int FastaFile::Size()
{
  return _numSequences;
}

Sequence *FastaFile::operator[] (int index)
{
  return _sequences[index];
}
